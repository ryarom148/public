export function getChartData() {
    const epochs = Array.from({ length: 10 }, (_, i) => (i + 1) * 5);
    



    const attentionOnB = [-0.5, 0.2, 0.8, 1.5, 2.1, 2.6, 3.0, 3.3, 3.5, 3.6];
    const attentionOnA = [0.4, 0.1, -0.3, -0.7, -1.2, -1.6, -1.9, -2.1, -2.2, -2.3];

    return {
        labels: epochs.map(e => `Epoch ${e}`),
        datasets: [
            {
                label: "Modulation on Token 'B'",
                data: attentionOnB.map(d => d + (Math.random() - 0.5) * 0.2), // Add some noise
                borderColor: 'rgb(37, 99, 235)',
                backgroundColor: 'rgba(37, 99, 235, 0.1)',
                tension: 0.4,
                fill: true,
                pointRadius: 4,
                pointHoverRadius: 7,
                borderWidth: 2.5,
            },
            {
                label: "Modulation on Token 'A'",
                data: attentionOnA.map(d => d + (Math.random() - 0.5) * 0.2), // Add some noise
                borderColor: 'rgb(220, 38, 38)',
                backgroundColor: 'rgba(220, 38, 38, 0.1)',
                tension: 0.4,
                fill: true,
                pointRadius: 4,
                pointHoverRadius: 7,
                borderWidth: 2,
                borderDash: [5, 5],
            }
        ]
    };
}
