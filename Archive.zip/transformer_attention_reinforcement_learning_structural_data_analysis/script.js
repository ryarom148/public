import { getChartData } from './data.js';

document.addEventListener('DOMContentLoaded', () => {

    lucide.createIcons();
    

    hljs.highlightAll();


    const ctx = document.getElementById('attentionChart');
    if (!ctx) return;
    
    const chartData = getChartData();

    new Chart(ctx, {
        type: 'line',
        data: chartData,
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: false,
                    title: {
                        display: true,
                        text: 'Attention Modulation Strength (Logits)',
                        font: {
                            size: 14
                        }
                    }
                },
                x: {
                     title: {
                        display: true,
                        text: 'Training Epochs',
                        font: {
                            size: 14
                        }
                    }
                }
            },
            plugins: {
                legend: {
                    position: 'top',
                },
                tooltip: {
                    mode: 'index',
                    intersect: false,
                },
            },
            interaction: {
                mode: 'index',
                intersect: false,
            }
        }
    });
});
