export function getChartData() {
    const labels = ['Price-Sensitive Shopper', 'Brand-Loyal Customer'];
    




    const policyHead1Data = [25, 5]; // 25% for sensitive, 5% for loyal
    const policyHead2Data = [25, 5]; // Let's assume for simplicity they converge to the same distinct policies



    const policyHead3Data_hypothetical = [15, 15];


    return {
        labels: labels,
        datasets: [
            {
                label: 'Policy from Head 1',
                data: policyHead1Data,
                backgroundColor: 'rgba(59, 130, 246, 0.6)',
                borderColor: 'rgb(59, 130, 246)',
                borderWidth: 2,
            },
            {
                label: 'Policy from Head 2',
                data: policyHead2Data,
                backgroundColor: 'rgba(34, 197, 94, 0.6)',
                borderColor: 'rgb(34, 197, 94)',
                borderWidth: 2,
            }
        ]
    };
}
