import { getChartData } from './data.js';

document.addEventListener('DOMContentLoaded', () => {
    const ctx = document.getElementById('policyChart');
    if (!ctx) return;
    
    const chartData = getChartData();

    new Chart(ctx, {
        type: 'bar',
        data: chartData,
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    max: 30,
                    title: {
                        display: true,
                        text: 'Recommended Discount (%)',
                        font: {
                            size: 14
                        }
                    },
                    ticks: {
                        callback: function(value) {
                            return value + '%';
                        }
                    }
                },
                x: {
                     title: {
                        display: true,
                        text: 'Customer Segment',
                        font: {
                            size: 14
                        }
                    }
                }
            },
            plugins: {
                legend: {
                    position: 'top',
                },
                title: {
                    display: true,
                    text: 'Comparison of Discovered Policies by Customer Segment',
                    padding: {
                        bottom: 20
                    },
                    font: {
                        size: 16,
                        weight: 'bold'
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            let label = context.dataset.label || '';
                            if (label) {
                                label += ': ';
                            }
                            if (context.parsed.y !== null) {
                                label += context.parsed.y + '% Discount';
                            }
                            return label;
                        }
                    }
                },
            },
        }
    });
});
