export const getChartData = () => {
    const labels = Array.from({ length: 50 }, (_, i) => `Day ${i + 1}`);
    const actualA = [];
    const forecastA = [];
    const actualB = [];
    const forecastB = [];

    let valA = 50;
    let valB = 35;

    for (let i = 0; i < 50; i++) {

        valA = 50 + 15 * Math.sin(i / 5) + (Math.random() - 0.5) * 8;
        valB = 35 + 12 * Math.cos(i / 5) + (Math.random() - 0.5) * 6;
        actualA.push(valA);
        actualB.push(valB);


        const forecastNoiseA = (Math.random() - 0.5) * 4;
        const forecastNoiseB = (Math.random() - 0.5) * 3;
        const forecastValA = 50 + 15 * Math.sin((i - 1) / 5) + forecastNoiseA;
        const forecastValB = 35 + 12 * Math.cos((i-1) / 5) + forecastNoiseB;
        forecastA.push(forecastValA);
        forecastB.push(forecastValB);
    }

    return {
        labels,
        datasets: [
            {
                label: 'Actual Sales - Product A',
                data: actualA,
                borderColor: 'rgb(239, 68, 68)',
                backgroundColor: 'rgba(239, 68, 68, 0.2)',
                borderWidth: 2,
                tension: 0.3,
                pointRadius: 1,
                fill: false,
            },
            {
                label: 'Forecasted Sales - Product A',
                data: forecastA,
                borderColor: 'rgb(251, 146, 60)',
                backgroundColor: 'rgba(251, 146, 60, 0.2)',
                borderWidth: 2,
                borderDash: [5, 5],
                tension: 0.3,
                pointRadius: 1,
                fill: false,
            },
            {
                label: 'Actual Sales - Product B',
                data: actualB,
                borderColor: 'rgb(37, 99, 235)',
                backgroundColor: 'rgba(37, 99, 235, 0.2)',
                borderWidth: 2,
                tension: 0.3,
                pointRadius: 1,
                fill: false,
            },
            {
                label: 'Forecasted Sales - Product B',
                data: forecastB,
                borderColor: 'rgb(56, 189, 248)',
                backgroundColor: 'rgba(56, 189, 248, 0.2)',
                borderWidth: 2,
                borderDash: [5, 5],
                tension: 0.3,
                pointRadius: 1,
                fill: false,
            },
        ],
    };
};
