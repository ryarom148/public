import { getChartData } from './data.js';

document.addEventListener('DOMContentLoaded', () => {
    const ctx = document.getElementById('forecastChart');
    if (!ctx) return;

    const chartData = getChartData();

    new Chart(ctx, {
        type: 'line',
        data: chartData,
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: {
                    position: 'top',
                },
                title: {
                    display: true,
                    text: 'Actual vs. Forecasted Sales for Multiple Products',
                    font: {
                        size: 18,
                        family: 'Inter',
                    }
                }
            },
            scales: {
                x: {
                    title: {
                        display: true,
                        text: 'Time (Days)'
                    }
                },
                y: {
                    title: {
                        display: true,
                        text: 'Units Sold'
                    }
                }
            }
        }
    });
});
