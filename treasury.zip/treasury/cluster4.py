import numpy as np
import pandas as pd
from joblib import Parallel, delayed
from sklearn.base import BaseEstimator, ClusterMixin
import time
from sklearn.metrics import pairwise_distances, silhouette_score, calinski_harabasz_score, davies_bouldin_score
from tslearn.metrics import cdist_dtw, cdist_soft_dtw
from aeon.distances import (dtw_distance, lcss_distance, erp_distance, 
                            edr_distance, msm_distance, twe_distance)
from aeon.clustering import TimeSeriesKMeans, TimeSeriesKMedoids
from sklearn.cluster import AgglomerativeClustering, DBSCAN, AffinityPropagation
from chinese_whispers import chinese_whispers, aggregate_clusters
import networkx as nx
from typing import Dict, List, Union, Optional, Callable
from scipy.sparse import csr_matrix
from sklearn.neighbors import NearestNeighbors
from sklearn.model_selection import BaseCrossValidator, KFold
from sklearn.base import clone
from skopt import BayesSearchCV
from skopt.space import Real, Categorical, Integer
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA

class TimeSeriesClusterPredictor(BaseEstimator, ClusterMixin):
    def __init__(
        self,
        distance: Union[str, Callable] = 'dtw',
        distance_params: Optional[Dict] = None,
        algorithm: str = 'kmeans',
        algo_params: Optional[Dict] = None,
        memory_efficient: bool = False,
        n_jobs: int = -1,
        random_state: Optional[int] = None,
        optimization_metric: str = 'combined'
    ):
        self.distance = distance
        self.distance_params = distance_params if distance_params is not None else {}
        self.algorithm = algorithm
        self.algo_params = algo_params if algo_params is not None else {}
        self.memory_efficient = memory_efficient
        self.n_jobs = n_jobs
        self.random_state = random_state
        self.optimization_metric = optimization_metric
        
        self.distance_metrics = {
            'dtw': dtw_distance,
            'softdtw': cdist_soft_dtw,
            'euclidean': 'euclidean',
            'lcss': lcss_distance,
            'erp': erp_distance,
            'edr': edr_distance,
            'msm': msm_distance,
            'twe': twe_distance,
        }
        
        if isinstance(self.distance, str) and self.distance not in self.distance_metrics:
            raise ValueError(f"Unsupported distance metric: {self.distance}")
        
        self.clustering_algorithms = {
            'kmeans': TimeSeriesKMeans,
            'kmedoids': TimeSeriesKMedoids,
            'agglomerative': AgglomerativeClustering,
            'dbscan': DBSCAN,
            'affinity_propagation': AffinityPropagation,
            'chinese_whispers': self.chinese_whispers_clustering
        }
        
        if self.algorithm not in self.clustering_algorithms:
            raise ValueError(f"Unsupported clustering algorithm: {self.algorithm}")
        
        self.best_model = None
        self.cluster_centers = None
        self.outlier_threshold = None
        self.labels_ = None
        self.distance_matrix_cache = {}
        self.best_score = None
        self.evaluation_metrics = {}
        self.X_ = None
        self.G = None
        self.best_params_ = None
        self.best_score_ = None

    def compute_distance_matrix(self, X: np.ndarray) -> Union[np.ndarray, Callable]:
        if self.memory_efficient:
            return self.create_distance_function(X)
        else:
            return self._compute_full_distance_matrix(X)

    def create_distance_function(self, X: np.ndarray) -> Callable:
        def distance_function(i, j):
            if isinstance(self.distance, str):
                metric = self.distance_metrics[self.distance]
                if callable(metric):
                    return metric(X[i], X[j], **self.distance_params)
                elif self.distance == 'euclidean':
                    return np.linalg.norm(X[i] - X[j])
            elif callable(self.distance):
                return self.distance(X[i], X[j], **self.distance_params)
            else:
                raise ValueError("Invalid distance metric")
        return distance_function

    def _compute_full_distance_matrix(self, X: np.ndarray) -> np.ndarray:
        start_time = time.time()
        print(f"[{time.strftime('%H:%M:%S')}] Computing full distance matrix...")
        
        n_samples = len(X)
        distances = np.zeros((n_samples, n_samples))

        if isinstance(self.distance, str):
            metric = self.distance_metrics[self.distance]
            if self.distance == 'dtw':
                distances = cdist_dtw(X, n_jobs=self.n_jobs, **self.distance_params)
            elif self.distance == 'softdtw':
                distances = cdist_soft_dtw(X, **self.distance_params)
            elif self.distance == 'euclidean':
                X_flat = X.reshape((len(X), -1))
                distances = pairwise_distances(X_flat, metric='euclidean', n_jobs=self.n_jobs)
            elif callable(metric):
                distances = self._parallel_distance_computation(X, metric)
        elif callable(self.distance):
            distances = self._parallel_distance_computation(X, self.distance)
        else:
            raise ValueError("Distance must be either a string or a callable")
        
        end_time = time.time()
        print(f"[{time.strftime('%H:%M:%S')}] Distance matrix computed in {end_time - start_time:.2f} seconds.")
        return distances

    def _parallel_distance_computation(self, X: np.ndarray, metric: Callable) -> np.ndarray:
        n_samples = len(X)
        
        def compute_distances(start, end):
            sub_matrix = np.zeros((end - start, n_samples))
            for i in range(start, end):
                for j in range(i, n_samples):
                    dist = metric(X[i], X[j], **self.distance_params)
                    sub_matrix[i - start, j] = dist
                    if i != j:
                        sub_matrix[j - start, i] = dist
            return sub_matrix

        # Splitting the work
        chunk_size = max(1, n_samples // (4 * self.n_jobs))
        chunks = [(i, min(i + chunk_size, n_samples)) for i in range(0, n_samples, chunk_size)]
        
        results = Parallel(n_jobs=self.n_jobs)(
            delayed(compute_distances)(start, end) for start, end in chunks
        )
        
        # Combining results
        distances = np.vstack(results)
        
        return distances

    def chinese_whispers_clustering(self, X: np.ndarray, distance_matrix: np.ndarray) -> np.ndarray:
        start_time = time.time()
        print(f"[{time.strftime('%H:%M:%S')}] Performing Chinese Whispers clustering...")
        n_samples = distance_matrix.shape[0]
        
        # Convert distances to similarities
        sigma = np.std(distance_matrix)
        similarity_matrix = np.exp(-distance_matrix ** 2 / (2 * sigma ** 2))

        # Build graph
        G = nx.Graph()
        for i in range(n_samples):
            for j in range(i + 1, n_samples):
                weight = similarity_matrix[i, j]
                if weight > 0:
                    G.add_edge(i, j, weight=weight)

        # Apply Chinese Whispers clustering
        iterations = self.algo_params.get('iterations', 20)
        weighting = self.algo_params.get('weighting', 'top')
        chinese_whispers(G, weighting=weighting, iterations=iterations)
        self.G = G  # Store the graph for visualization

        # Extract labels
        labels = np.array([G.nodes[node]['label'] for node in G.nodes()])
        unique_labels = np.unique(labels)
        label_mapping = {label: idx for idx, label in enumerate(unique_labels)}
        labels_mapped = np.array([label_mapping[label] for label in labels])

        # Compute cluster centers as medoids
        self.cluster_centers = np.array([
            X[labels_mapped == label][
                np.argmin(distance_matrix[np.ix_(labels_mapped == label, labels_mapped == label)].sum(axis=1))
            ] for label in unique_labels
        ])

        end_time = time.time()
        print(f"[{time.strftime('%H:%M:%S')}] Chinese Whispers clustering completed in {end_time - start_time:.2f} seconds.")
        return labels_mapped

    def fit(self, X: np.ndarray, y=None):
        self.X_ = X
        distance_matrix = self.compute_distance_matrix(X)

        if self.algorithm == 'kmeans':
            self._fit_kmeans(X, distance_matrix)
        elif self.algorithm == 'kmedoids':
            self._fit_kmedoids(X, distance_matrix)
        elif self.algorithm == 'agglomerative':
            self._fit_agglomerative(distance_matrix)
        elif self.algorithm == 'dbscan':
            self._fit_dbscan(distance_matrix)
        elif self.algorithm == 'affinity_propagation':
            self._fit_affinity_propagation(distance_matrix)
        elif self.algorithm == 'chinese_whispers':
            self._fit_chinese_whispers(X, distance_matrix)
        else:
            raise ValueError(f"Unsupported clustering algorithm: {self.algorithm}")

        self._compute_cluster_centers(X)
        self._compute_outlier_threshold(X)

        # Compute evaluation metrics after fitting
        self.evaluation_metrics = self.evaluate(X)

        return self

    def _fit_kmeans(self, X: np.ndarray, distance_matrix: Union[np.ndarray, Callable]):
        self.best_model = TimeSeriesKMeans(
            n_clusters=self.algo_params.get('n_clusters', 8),
            metric=self.distance if isinstance(self.distance, str) else 'precomputed',
            metric_params=self.distance_params,
            n_jobs=self.n_jobs,
            random_state=self.random_state,
            **{k: v for k, v in self.algo_params.items() if k != 'n_clusters'}
        )
        if self.memory_efficient:
            self.best_model.fit(X)
        else:
            self.best_model.fit(distance_matrix)
        self.labels_ = self.best_model.labels_

    def _fit_kmedoids(self, X: np.ndarray, distance_matrix: Union[np.ndarray, Callable]):
        self.best_model = TimeSeriesKMedoids(
            n_clusters=self.algo_params.get('n_clusters', 8),
            metric=self.distance if isinstance(self.distance, str) else 'precomputed',
            metric_params=self.distance_params,
            n_jobs=self.n_jobs,
            random_state=self.random_state,
            **{k: v for k, v in self.algo_params.items() if k != 'n_clusters'}
        )
        if self.memory_efficient:
            self.best_model.fit(X)
        else:
            self.best_model.fit(distance_matrix)
        self.labels_ = self.best_model.labels_

    def _fit_agglomerative(self, distance_matrix: Union[np.ndarray, Callable]):
        self.best_model = AgglomerativeClustering(
            n_clusters=self.algo_params.get('n_clusters', 8),
            affinity='precomputed',
            linkage=self.algo_params.get('linkage', 'average'),
            **{k: v for k, v in self.algo_params.items() if k not in ['n_clusters', 'linkage']}
        )
        self.best_model.fit(distance_matrix)
        self.labels_ = self.best_model.labels_

    def _fit_dbscan(self, distance_matrix: Union[np.ndarray, Callable]):
        self.best_model = DBSCAN(
            metric='precomputed',
            n_jobs=self.n_jobs,
            **self.algo_params
        )
        self.best_model.fit(distance_matrix)
        self.labels_ = self.best_model.labels_

    def _fit_affinity_propagation(self, distance_matrix: Union[np.ndarray, Callable]):
        self.best_model = AffinityPropagation(
            affinity='precomputed',
            random_state=self.random_state,
            **self.algo_params
        )
        self.best_model.fit(-distance_matrix)  # AffinityPropagation expects similarities, not distances
        self.labels_ = self.best_model.labels_

    def _fit_chinese_whispers(self, X: np.ndarray, distance_matrix: Union[np.ndarray, Callable]):
        self.labels_ = self.chinese_whispers_clustering(X, distance_matrix)

    def _compute_cluster_centers(self, X: np.ndarray):
        if hasattr(self.best_model, 'cluster_centers_'):
            self.cluster_centers = self.best_model.cluster_centers_
        else:
            unique_labels = np.unique(self.labels_)
            self.cluster_centers = np.array([
                X[self.labels_ == label].mean(axis=0) for label in unique_labels if label != -1
            ])

    def _compute_outlier_threshold(self, X: np.ndarray):
        if self.cluster_centers is not None:
            distances = self._compute_distances_to_centers(X)
            self.outlier_threshold = np.percentile(distances.min(axis=1), 95)

    def _compute_distances_to_centers(self, X: np.ndarray) -> np.ndarray:
        if self.memory_efficient:
            distance_func = self.create_distance_function(X)
            return np.array([[distance_func(i, j) for j in range(len(self.cluster_centers))] 
                             for i in range(len(X))])
        else:
            return pairwise_distances(X, self.cluster_centers, metric=self.distance, 
                                      n_jobs=self.n_jobs, **self.distance_params)

    def predict(self, X: np.ndarray) -> np.ndarray:
        if not hasattr(self, 'cluster_centers'):
            raise ValueError("Model is not fitted yet. Call 'fit' before using this method.")

        distances = self._compute_distances_to_centers(X)
        labels = distances.argmin(axis=1)

        # Detect outliers
        outliers = distances.min(axis=1) > self.outlier_threshold
        labels[outliers] = -1

        return labels

    def _compute_optimization_score(self, X: np.ndarray, X_test: Optional[np.ndarray] = None) -> float:
        """
        Compute the optimization score based on the selected metric.
        If a test dataset is provided, include the outlier ratio in the score.

        Args:
            X (np.ndarray): The training time series data.
            X_test (Optional[np.ndarray]): The test time series data, if available.

        Returns:
            float: The computed optimization score.
        """
        # Compute individual scores
        silhouette = silhouette_score(X, self.labels_)
        calinski_harabasz = calinski_harabasz_score(X, self.labels_)
        davies_bouldin = davies_bouldin_score(X, self.labels_)

        # Normalize Davies-Bouldin score (lower is better, so we invert it)
        davies_bouldin_normalized = 1 / (1 + davies_bouldin)

        # Compute combined score
        combined_score = (silhouette + calinski_harabasz / 1000 + davies_bouldin_normalized) / 3

        # If test data is provided, compute outlier ratio and include it in the score
        if X_test is not None:
            test_labels = self.predict(X_test)
            outlier_ratio = np.sum(test_labels == -1) / len(test_labels)
            # Penalize the score based on the outlier ratio (1 - outlier_ratio to make it better when higher)
            combined_score *= (1 - outlier_ratio)

        if self.optimization_metric == 'combined':
            return combined_score
        elif self.optimization_metric == 'silhouette':
            return silhouette
        elif self.optimization_metric == 'calinski_harabasz':
            return calinski_harabasz
        elif self.optimization_metric == 'davies_bouldin':
            return davies_bouldin_normalized
        else:
            raise ValueError(f"Unsupported optimization metric: {self.optimization_metric}")

    def optimize_hyperparameters(self, X: np.ndarray, param_distributions: Dict, 
                                 n_iter: int = 50, cv: Union[int, BaseCrossValidator] = 3,
                                 X_test: Optional[np.ndarray] = None):
        """
        Perform hyperparameter optimization using Bayesian optimization.
        
        Args:
            X (np.ndarray): The input time series data.
            param_distributions (Dict): The hyperparameter search space.
            n_iter (int): Number of iterations for Bayesian optimization.
            cv (Union[int, BaseCrossValidator]): Cross-validation strategy.
            X_test (Optional[np.ndarray]): Test dataset for computing outlier ratio.
        """
        def objective(params):
            self.set_params(**params)
            self.fit(X)
            return -self._compute_optimization_score(X, X_test)  # Negative because BayesSearchCV minimizes

        search_spaces = []
        for param, dist in param_distributions.items():
            if isinstance(dist, list):
                search_spaces.append(Categorical(dist, name=param))
            elif isinstance(dist, tuple) and len(dist) == 3:
                if isinstance(dist[0], int):
                    search_spaces.append(Integer(dist[0], dist[1], name=param))
                else:
                    search_spaces.append(Real(dist[0], dist[1], prior='uniform', name=param))

        opt = BayesSearchCV(
            estimator=clone(self),
            search_spaces=search_spaces,
            n_iter=n_iter,
            cv=cv,
            n_jobs=self.n_jobs,
            random_state=self.random_state
        )

        opt.fit(X)

        self.set_params(**opt.best_params_)
        self.best_params_ = opt.best_params_
        self.best_score_ = -opt.best_score_  # Convert back to positive score
        self.fit(X)

    def evaluate(self, X: np.ndarray, y_true: Optional[np.ndarray] = None, X_test: Optional[np.ndarray] = None) -> Dict[str, float]:
        """
        Evaluate the clustering performance using multiple metrics.

        Args:
            X (np.ndarray): The input time series data.
            y_true (Optional[np.ndarray]): True labels, if available.
            X_test (Optional[np.ndarray]): Test dataset for computing outlier ratio.

        Returns:
            Dict[str, float]: A dictionary of evaluation metrics.
        """
        if not hasattr(self, 'labels_'):
            raise ValueError("Model is not fitted yet. Call 'fit' before using this method.")

        metrics = {
            'silhouette_score': silhouette_score(X, self.labels_),
            'calinski_harabasz_score': calinski_harabasz_score(X, self.labels_),
            'davies_bouldin_score': davies_bouldin_score(X, self.labels_)
        }

        if y_true is not None:
            from sklearn.metrics import adjusted_rand_score, normalized_mutual_info_score
            metrics.update({
                'adjusted_rand_score': adjusted_rand_score(y_true, self.labels_),
                'normalized_mutual_info_score': normalized_mutual_info_score(y_true, self.labels_)
            })

        if X_test is not None:
            test_labels = self.predict(X_test)
            outlier_ratio = np.sum(test_labels == -1) / len(test_labels)
            metrics['test_outlier_ratio'] = outlier_ratio

        # Compute combined score
        metrics['combined_score'] = self._compute_optimization_score(X, X_test)

        return metrics

    def visualize_clusters(self, X: np.ndarray, max_samples: int = 1000):
        """
        Visualize the clustering results using PCA for dimensionality reduction.

        Args:
            X (np.ndarray): The input time series data.
            max_samples (int): Maximum number of samples to plot.
        """
        if not hasattr(self, 'labels_'):
            raise ValueError("Model is not fitted yet. Call 'fit' before using this method.")

        # Subsample data if necessary
        if X.shape[0] > max_samples:
            indices = np.random.choice(X.shape[0], max_samples, replace=False)
            X_sub = X[indices]
            labels_sub = self.labels_[indices]
        else:
            X_sub = X
            labels_sub = self.labels_

        # Apply PCA
        pca = PCA(n_components=2)
        X_pca = pca.fit_transform(X_sub.reshape(X_sub.shape[0], -1))

        # Plot
        plt.figure(figsize=(10, 8))
        scatter = plt.scatter(X_pca[:, 0], X_pca[:, 1], c=labels_sub, cmap='viridis')
        plt.colorbar(scatter)
        plt.title('Clustering Results Visualization (PCA)')
        plt.xlabel('First Principal Component')
        plt.ylabel('Second Principal Component')
        plt.show()

        # Plot cluster centers if available
        if self.cluster_centers is not None:
            centers_pca = pca.transform(self.cluster_centers.reshape(self.cluster_centers.shape[0], -1))
            plt.figure(figsize=(10, 8))
            plt.scatter(X_pca[:, 0], X_pca[:, 1], c=labels_sub, cmap='viridis', alpha=0.5)
            plt.scatter(centers_pca[:, 0], centers_pca[:, 1], c='red', s=200, marker='X')
            plt.title('Clustering Results with Cluster Centers (PCA)')
            plt.xlabel('First Principal Component')
            plt.ylabel('Second Principal Component')
            plt.show()

    def save_model(self, filepath: str):
        """
        Save the model to a file.

        Args:
            filepath (str): Path to save the model.
        """
        import joblib
        joblib.dump(self, filepath)
        print(f"Model saved to {filepath}")

    @classmethod
    def load_model(cls, filepath: str):
        """
        Load the model from a file.

        Args:
            filepath (str): Path to the saved model.

        Returns:
            TimeSeriesClusterPredictor: Loaded model.
        """
        import joblib
        model = joblib.load(filepath)
        print(f"Model loaded from {filepath}")
        return model
    

    # Initialize the predictor
predictor = TimeSeriesClusterPredictor(algorithm='kmeans', optimization_metric='combined')

# Define the hyperparameter search space
param_distributions = {
    'distance': ['dtw', 'euclidean'],
    'algo_params__n_clusters': (2, 10),
    'algo_params__max_iter': (50, 300)
}

# Split your data into train and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Perform hyperparameter optimization
predictor.optimize_hyperparameters(X_train, param_distributions, n_iter=50, cv=3, X_test=X_test)

# Fit the model with the best parameters
predictor.fit(X_train)

# Evaluate the model
evaluation_results = predictor.evaluate(X_train, y_true=y_train, X_test=X_test)
print("Evaluation results:", evaluation_results)

# Visualize the clustering results
predictor.visualize_clusters(X_test)

# Save the model
predictor.save_model('time_series_cluster_predictor.joblib')

# Later, load the model
loaded_predictor = TimeSeriesClusterPredictor.load_model('time_series_cluster_predictor.joblib')