GridSearchCV :
class sklearn.model_selection.GridSearchCV(estimator, param_grid, *, scoring=None, n_jobs=None, refit=True, cv=None, verbose=0, pre_dispatch='2*n_jobs', error_score=nan, return_train_score=False)[source]
Exhaustive search over specified parameter values for an estimator.

Important members are fit, predict.

GridSearchCV implements a “fit” and a “score” method. It also implements “score_samples”, “predict”, “predict_proba”, “decision_function”, “transform” and “inverse_transform” if they are implemented in the estimator used.

The parameters of the estimator used to apply these methods are optimized by cross-validated grid-search over a parameter grid.

Read more in the User Guide.

Parameters:
estimatorestimator object
This is assumed to implement the scikit-learn estimator interface. Either estimator needs to provide a score function, or scoring must be passed.

param_griddict or list of dictionaries
Dictionary with parameters names (str) as keys and lists of parameter settings to try as values, or a list of such dictionaries, in which case the grids spanned by each dictionary in the list are explored. This enables searching over any sequence of parameter settings.

scoringstr, callable, list, tuple or dict, default=None
Strategy to evaluate the performance of the cross-validated model on the test set.

If scoring represents a single score, one can use:

a single string (see The scoring parameter: defining model evaluation rules);

a callable (see Defining your scoring strategy from metric functions) that returns a single value.

If scoring represents multiple scores, one can use:

a list or tuple of unique strings;

a callable returning a dictionary where the keys are the metric names and the values are the metric scores;

a dictionary with metric names as keys and callables a values.

See Specifying multiple metrics for evaluation for an example.

n_jobsint, default=None
Number of jobs to run in parallel. None means 1 unless in a joblib.parallel_backend context. -1 means using all processors. See Glossary for more details.

Changed in version v0.20: n_jobs default changed from 1 to None

refitbool, str, or callable, default=True
Refit an estimator using the best found parameters on the whole dataset.

For multiple metric evaluation, this needs to be a str denoting the scorer that would be used to find the best parameters for refitting the estimator at the end.

Where there are considerations other than maximum score in choosing a best estimator, refit can be set to a function which returns the selected best_index_ given cv_results_. In that case, the best_estimator_ and best_params_ will be set according to the returned best_index_ while the best_score_ attribute will not be available.

The refitted estimator is made available at the best_estimator_ attribute and permits using predict directly on this GridSearchCV instance.

Also for multiple metric evaluation, the attributes best_index_, best_score_ and best_params_ will only be available if refit is set and all of them will be determined w.r.t this specific scorer.

See scoring parameter to know more about multiple metric evaluation.

See Custom refit strategy of a grid search with cross-validation to see how to design a custom selection strategy using a callable via refit.

Changed in version 0.20: Support for callable added.

cvint, cross-validation generator or an iterable, default=None
Determines the cross-validation splitting strategy. Possible inputs for cv are:

None, to use the default 5-fold cross validation,

integer, to specify the number of folds in a (Stratified)KFold,

CV splitter,

An iterable yielding (train, test) splits as arrays of indices.

For integer/None inputs, if the estimator is a classifier and y is either binary or multiclass, StratifiedKFold is used. In all other cases, KFold is used. These splitters are instantiated with shuffle=False so the splits will be the same across calls.

Refer User Guide for the various cross-validation strategies that can be used here.

Changed in version 0.22: cv default value if None changed from 3-fold to 5-fold.

verboseint
Controls the verbosity: the higher, the more messages.

>1 : the computation time for each fold and parameter candidate is displayed;

>2 : the score is also displayed;

>3 : the fold and candidate parameter indexes are also displayed together with the starting time of the computation.

pre_dispatchint, or str, default=’2*n_jobs’
Controls the number of jobs that get dispatched during parallel execution. Reducing this number can be useful to avoid an explosion of memory consumption when more jobs get dispatched than CPUs can process. This parameter can be:

None, in which case all the jobs are immediately created and spawned. Use this for lightweight and fast-running jobs, to avoid delays due to on-demand spawning of the jobs

An int, giving the exact number of total jobs that are spawned

A str, giving an expression as a function of n_jobs, as in ‘2*n_jobs’

error_score‘raise’ or numeric, default=np.nan
Value to assign to the score if an error occurs in estimator fitting. If set to ‘raise’, the error is raised. If a numeric value is given, FitFailedWarning is raised. This parameter does not affect the refit step, which will always raise the error.

return_train_scorebool, default=False
If False, the cv_results_ attribute will not include training scores. Computing training scores is used to get insights on how different parameter settings impact the overfitting/underfitting trade-off. However computing the scores on the training set can be computationally expensive and is not strictly required to select the parameters that yield the best generalization performance.

Added in version 0.19.

Changed in version 0.21: Default value was changed from True to False

Attributes:
cv_results_dict of numpy (masked) ndarrays
A dict with keys as column headers and values as columns, that can be imported into a pandas DataFrame.

For instance the below given table

param_kernel

param_gamma

param_degree

split0_test_score

…

rank_t…

‘poly’

–

2

0.80

…

2

‘poly’

–

3

0.70

…

4

‘rbf’

0.1

–

0.80

…

3

‘rbf’

0.2

–

0.93

…

1

will be represented by a cv_results_ dict of:

{
'param_kernel': masked_array(data = ['poly', 'poly', 'rbf', 'rbf'],
                             mask = [False False False False]...)
'param_gamma': masked_array(data = [-- -- 0.1 0.2],
                            mask = [ True  True False False]...),
'param_degree': masked_array(data = [2.0 3.0 -- --],
                             mask = [False False  True  True]...),
'split0_test_score'  : [0.80, 0.70, 0.80, 0.93],
'split1_test_score'  : [0.82, 0.50, 0.70, 0.78],
'mean_test_score'    : [0.81, 0.60, 0.75, 0.85],
'std_test_score'     : [0.01, 0.10, 0.05, 0.08],
'rank_test_score'    : [2, 4, 3, 1],
'split0_train_score' : [0.80, 0.92, 0.70, 0.93],
'split1_train_score' : [0.82, 0.55, 0.70, 0.87],
'mean_train_score'   : [0.81, 0.74, 0.70, 0.90],
'std_train_score'    : [0.01, 0.19, 0.00, 0.03],
'mean_fit_time'      : [0.73, 0.63, 0.43, 0.49],
'std_fit_time'       : [0.01, 0.02, 0.01, 0.01],
'mean_score_time'    : [0.01, 0.06, 0.04, 0.04],
'std_score_time'     : [0.00, 0.00, 0.00, 0.01],
'params'             : [{'kernel': 'poly', 'degree': 2}, ...],
}
NOTE

The key 'params' is used to store a list of parameter settings dicts for all the parameter candidates.

The mean_fit_time, std_fit_time, mean_score_time and std_score_time are all in seconds.

For multi-metric evaluation, the scores for all the scorers are available in the cv_results_ dict at the keys ending with that scorer’s name ('_<scorer_name>') instead of '_score' shown above. (‘split0_test_precision’, ‘mean_train_precision’ etc.)

best_estimator_estimator
Estimator that was chosen by the search, i.e. estimator which gave highest score (or smallest loss if specified) on the left out data. Not available if refit=False.

See refit parameter for more information on allowed values.

best_score_float
Mean cross-validated score of the best_estimator

For multi-metric evaluation, this is present only if refit is specified.

This attribute is not available if refit is a function.

best_params_dict
Parameter setting that gave the best results on the hold out data.

For multi-metric evaluation, this is present only if refit is specified.

best_index_int
The index (of the cv_results_ arrays) which corresponds to the best candidate parameter setting.

The dict at search.cv_results_['params'][search.best_index_] gives the parameter setting for the best model, that gives the highest mean score (search.best_score_).

For multi-metric evaluation, this is present only if refit is specified.

scorer_function or a dict
Scorer function used on the held out data to choose the best parameters for the model.

For multi-metric evaluation, this attribute holds the validated scoring dict which maps the scorer key to the scorer callable.

n_splits_int
The number of cross-validation splits (folds/iterations).

refit_time_float
Seconds used for refitting the best model on the whole dataset.

This is present only if refit is not False.

Added in version 0.20.

multimetric_bool
Whether or not the scorers compute several metrics.

classes_ndarray of shape (n_classes,)
Class labels.

n_features_in_int
Number of features seen during fit.

feature_names_in_ndarray of shape (n_features_in_,)
Names of features seen during fit. Only defined if best_estimator_ is defined (see the documentation for the refit parameter for more details) and that best_estimator_ exposes feature_names_in_ when fit.

Added in version 1.0.

See also

ParameterGrid
Generates all the combinations of a hyperparameter grid.

train_test_split
Utility function to split the data into a development set usable for fitting a GridSearchCV instance and an evaluation set for its final evaluation.

sklearn.metrics.make_scorer
Make a scorer from a performance metric or loss function.

Notes

The parameters selected are those that maximize the score of the left out data, unless an explicit score is passed in which case it is used instead.

If n_jobs was set to a value higher than one, the data is copied for each point in the grid (and not n_jobs times). This is done for efficiency reasons if individual jobs take very little time, but may raise errors if the dataset is large and not enough memory is available. A workaround in this case is to set pre_dispatch. Then, the memory is copied only pre_dispatch many times. A reasonable value for pre_dispatch is 2 * n_jobs.

Examples

from sklearn import svm, datasets
from sklearn.model_selection import GridSearchCV
iris = datasets.load_iris()
parameters = {'kernel':('linear', 'rbf'), 'C':[1, 10]}
svc = svm.SVC()
clf = GridSearchCV(svc, parameters)
clf.fit(iris.data, iris.target)
GridSearchCV(estimator=SVC(),
             param_grid={'C': [1, 10], 'kernel': ('linear', 'rbf')})
sorted(clf.cv_results_.keys())
['mean_fit_time', 'mean_score_time', 'mean_test_score',...
 'param_C', 'param_kernel', 'params',...
 'rank_test_score', 'split0_test_score',...
 'split2_test_score', ...
 'std_fit_time', 'std_score_time', 'std_test_score']
property classes_
Class labels.

Only available when refit=True and the estimator is a classifier.

decision_function(X)[source]
Call decision_function on the estimator with the best found parameters.

Only available if refit=True and the underlying estimator supports decision_function.

Parameters
:
X
indexable, length n_samples
Must fulfill the input assumptions of the underlying estimator.

Returns
:
y_score
ndarray of shape (n_samples,) or (n_samples, n_classes) or (n_samples, n_classes * (n_classes-1) / 2)
Result of the decision function for X based on the estimator with the best found parameters.

fit(X, y=None, **params)[source]
Run fit with all sets of parameters.

Parameters:
Xarray-like of shape (n_samples, n_features) or (n_samples, n_samples)
Training vectors, where n_samples is the number of samples and n_features is the number of features. For precomputed kernel or distance matrix, the expected shape of X is (n_samples, n_samples).

yarray-like of shape (n_samples, n_output) or (n_samples,), default=None
Target relative to X for classification or regression; None for unsupervised learning.

**paramsdict of str -> object
Parameters passed to the fit method of the estimator, the scorer, and the CV splitter.

If a fit parameter is an array-like whose length is equal to num_samples then it will be split across CV groups along with X and y. For example, the sample_weight parameter is split because len(sample_weights) = len(X).

Returns:
self
object
Instance of fitted estimator.

get_metadata_routing()[source]
Get metadata routing of this object.

Please check User Guide on how the routing mechanism works.

Added in version 1.4.

Returns
:
routing
MetadataRouter
A MetadataRouter encapsulating routing information.

get_params(deep=True)[source]
Get parameters for this estimator.

Parameters
:
deep
bool, default=True
If True, will return the parameters for this estimator and contained subobjects that are estimators.

Returns
:
params
dict
Parameter names mapped to their values.

inverse_transform(X=None, Xt=None)[source]
Call inverse_transform on the estimator with the best found params.

Only available if the underlying estimator implements inverse_transform and refit=True.

Parameters:
Xindexable, length n_samples
Must fulfill the input assumptions of the underlying estimator.

Xtindexable, length n_samples
Must fulfill the input assumptions of the underlying estimator.

Deprecated since version 1.5: Xt was deprecated in 1.5 and will be removed in 1.7. Use X instead.

Returns:
X
{ndarray, sparse matrix} of shape (n_samples, n_features)
Result of the inverse_transform function for Xt based on the estimator with the best found parameters.

property n_features_in_
Number of features seen during fit.

Only available when refit=True.

predict(X)[source]
Call predict on the estimator with the best found parameters.

Only available if refit=True and the underlying estimator supports predict.

Parameters
:
X
indexable, length n_samples
Must fulfill the input assumptions of the underlying estimator.

Returns
:
y_pred
ndarray of shape (n_samples,)
The predicted labels or values for X based on the estimator with the best found parameters.

predict_log_proba(X)[source]
Call predict_log_proba on the estimator with the best found parameters.

Only available if refit=True and the underlying estimator supports predict_log_proba.

Parameters
:
X
indexable, length n_samples
Must fulfill the input assumptions of the underlying estimator.

Returns
:
y_pred
ndarray of shape (n_samples,) or (n_samples, n_classes)
Predicted class log-probabilities for X based on the estimator with the best found parameters. The order of the classes corresponds to that in the fitted attribute classes_.

predict_proba(X)[source]
Call predict_proba on the estimator with the best found parameters.

Only available if refit=True and the underlying estimator supports predict_proba.

Parameters
:
X
indexable, length n_samples
Must fulfill the input assumptions of the underlying estimator.

Returns
:
y_pred
ndarray of shape (n_samples,) or (n_samples, n_classes)
Predicted class probabilities for X based on the estimator with the best found parameters. The order of the classes corresponds to that in the fitted attribute classes_.

score(X, y=None, **params)[source]
Return the score on the given data, if the estimator has been refit.

This uses the score defined by scoring where provided, and the best_estimator_.score method otherwise.

Parameters:
Xarray-like of shape (n_samples, n_features)
Input data, where n_samples is the number of samples and n_features is the number of features.

yarray-like of shape (n_samples, n_output) or (n_samples,), default=None
Target relative to X for classification or regression; None for unsupervised learning.

**paramsdict
Parameters to be passed to the underlying scorer(s).

..versionadded:: 1.4
Only available if enable_metadata_routing=True. See Metadata Routing User Guide for more details.

Returns:
score
float
The score defined by scoring if provided, and the best_estimator_.score method otherwise.

score_samples(X)[source]
Call score_samples on the estimator with the best found parameters.

Only available if refit=True and the underlying estimator supports score_samples.

Added in version 0.24.

Parameters
:
X
iterable
Data to predict on. Must fulfill input requirements of the underlying estimator.

Returns
:
y_score
ndarray of shape (n_samples,)
The best_estimator_.score_samples method.

set_params(**params)[source]
Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects (such as Pipeline). The latter have parameters of the form <component>__<parameter> so that it’s possible to update each component of a nested object.

Parameters
:
**params
dict
Estimator parameters.

Returns
:
self
estimator instance
Estimator instance.

transform(X)[source]
Call transform on the estimator with the best found parameters.

Only available if the underlying estimator supports transform and refit=True.

Parameters
:
X
indexable, length n_samples
Must fulfill the input assumptions of the underlying estimator.

Returns
:
Xt
{ndarray, sparse matrix} of shape (n_samples, n_features)
X transformed in the new space based on the estimator with the best found parameters.


############################################################
HalvingGridSearchCV
class sklearn.model_selection.HalvingGridSearchCV(estimator, param_grid, *, factor=3, resource='n_samples', max_resources='auto', min_resources='exhaust', aggressive_elimination=False, cv=5, scoring=None, refit=True, error_score=nan, return_train_score=True, random_state=None, n_jobs=None, verbose=0)[source]
Search over specified parameter values with successive halving.

The search strategy starts evaluating all the candidates with a small amount of resources and iteratively selects the best candidates, using more and more resources.

Read more in the User guide.

Note

This estimator is still experimental for now: the predictions and the API might change without any deprecation cycle. To use it, you need to explicitly import enable_halving_search_cv:

# explicitly require this experimental feature
from sklearn.experimental import enable_halving_search_cv # noqa
# now you can import normally from model_selection
from sklearn.model_selection import HalvingGridSearchCV
Parameters:
estimatorestimator object
This is assumed to implement the scikit-learn estimator interface. Either estimator needs to provide a score function, or scoring must be passed.

param_griddict or list of dictionaries
Dictionary with parameters names (string) as keys and lists of parameter settings to try as values, or a list of such dictionaries, in which case the grids spanned by each dictionary in the list are explored. This enables searching over any sequence of parameter settings.

factorint or float, default=3
The ‘halving’ parameter, which determines the proportion of candidates that are selected for each subsequent iteration. For example, factor=3 means that only one third of the candidates are selected.

resource'n_samples' or str, default=’n_samples’
Defines the resource that increases with each iteration. By default, the resource is the number of samples. It can also be set to any parameter of the base estimator that accepts positive integer values, e.g. ‘n_iterations’ or ‘n_estimators’ for a gradient boosting estimator. In this case max_resources cannot be ‘auto’ and must be set explicitly.

max_resourcesint, default=’auto’
The maximum amount of resource that any candidate is allowed to use for a given iteration. By default, this is set to n_samples when resource='n_samples' (default), else an error is raised.

min_resources{‘exhaust’, ‘smallest’} or int, default=’exhaust’
The minimum amount of resource that any candidate is allowed to use for a given iteration. Equivalently, this defines the amount of resources r0 that are allocated for each candidate at the first iteration.

‘smallest’ is a heuristic that sets r0 to a small value:

n_splits * 2 when resource='n_samples' for a regression problem

n_classes * n_splits * 2 when resource='n_samples' for a classification problem

1 when resource != 'n_samples'

‘exhaust’ will set r0 such that the last iteration uses as much resources as possible. Namely, the last iteration will use the highest value smaller than max_resources that is a multiple of both min_resources and factor. In general, using ‘exhaust’ leads to a more accurate estimator, but is slightly more time consuming.

Note that the amount of resources used at each iteration is always a multiple of min_resources.

aggressive_eliminationbool, default=False
This is only relevant in cases where there isn’t enough resources to reduce the remaining candidates to at most factor after the last iteration. If True, then the search process will ‘replay’ the first iteration for as long as needed until the number of candidates is small enough. This is False by default, which means that the last iteration may evaluate more than factor candidates. See Aggressive elimination of candidates for more details.

cvint, cross-validation generator or iterable, default=5
Determines the cross-validation splitting strategy. Possible inputs for cv are:

integer, to specify the number of folds in a (Stratified)KFold,

CV splitter,

An iterable yielding (train, test) splits as arrays of indices.

For integer/None inputs, if the estimator is a classifier and y is either binary or multiclass, StratifiedKFold is used. In all other cases, KFold is used. These splitters are instantiated with shuffle=False so the splits will be the same across calls.

Refer User Guide for the various cross-validation strategies that can be used here.

Note

Due to implementation details, the folds produced by cv must be the same across multiple calls to cv.split(). For built-in scikit-learn iterators, this can be achieved by deactivating shuffling (shuffle=False), or by setting the cv’s random_state parameter to an integer.

scoringstr, callable, or None, default=None
A single string (see The scoring parameter: defining model evaluation rules) or a callable (see Defining your scoring strategy from metric functions) to evaluate the predictions on the test set. If None, the estimator’s score method is used.

refitbool, default=True
If True, refit an estimator using the best found parameters on the whole dataset.

The refitted estimator is made available at the best_estimator_ attribute and permits using predict directly on this HalvingGridSearchCV instance.

error_score‘raise’ or numeric
Value to assign to the score if an error occurs in estimator fitting. If set to ‘raise’, the error is raised. If a numeric value is given, FitFailedWarning is raised. This parameter does not affect the refit step, which will always raise the error. Default is np.nan.

return_train_scorebool, default=False
If False, the cv_results_ attribute will not include training scores. Computing training scores is used to get insights on how different parameter settings impact the overfitting/underfitting trade-off. However computing the scores on the training set can be computationally expensive and is not strictly required to select the parameters that yield the best generalization performance.

random_stateint, RandomState instance or None, default=None
Pseudo random number generator state used for subsampling the dataset when resources != 'n_samples'. Ignored otherwise. Pass an int for reproducible output across multiple function calls. See Glossary.

n_jobsint or None, default=None
Number of jobs to run in parallel. None means 1 unless in a joblib.parallel_backend context. -1 means using all processors. See Glossary for more details.

verboseint
Controls the verbosity: the higher, the more messages.

Attributes:
n_resources_list of int
The amount of resources used at each iteration.

n_candidates_list of int
The number of candidate parameters that were evaluated at each iteration.

n_remaining_candidates_int
The number of candidate parameters that are left after the last iteration. It corresponds to ceil(n_candidates[-1] / factor)

max_resources_int
The maximum number of resources that any candidate is allowed to use for a given iteration. Note that since the number of resources used at each iteration must be a multiple of min_resources_, the actual number of resources used at the last iteration may be smaller than max_resources_.

min_resources_int
The amount of resources that are allocated for each candidate at the first iteration.

n_iterations_int
The actual number of iterations that were run. This is equal to n_required_iterations_ if aggressive_elimination is True. Else, this is equal to min(n_possible_iterations_, n_required_iterations_).

n_possible_iterations_int
The number of iterations that are possible starting with min_resources_ resources and without exceeding max_resources_.

n_required_iterations_int
The number of iterations that are required to end up with less than factor candidates at the last iteration, starting with min_resources_ resources. This will be smaller than n_possible_iterations_ when there isn’t enough resources.

cv_results_dict of numpy (masked) ndarrays
A dict with keys as column headers and values as columns, that can be imported into a pandas DataFrame. It contains lots of information for analysing the results of a search. Please refer to the User guide for details.

best_estimator_estimator or dict
Estimator that was chosen by the search, i.e. estimator which gave highest score (or smallest loss if specified) on the left out data. Not available if refit=False.

best_score_float
Mean cross-validated score of the best_estimator.

best_params_dict
Parameter setting that gave the best results on the hold out data.

best_index_int
The index (of the cv_results_ arrays) which corresponds to the best candidate parameter setting.

The dict at search.cv_results_['params'][search.best_index_] gives the parameter setting for the best model, that gives the highest mean score (search.best_score_).

scorer_function or a dict
Scorer function used on the held out data to choose the best parameters for the model.

n_splits_int
The number of cross-validation splits (folds/iterations).

refit_time_float
Seconds used for refitting the best model on the whole dataset.

This is present only if refit is not False.

multimetric_bool
Whether or not the scorers compute several metrics.

classes_ndarray of shape (n_classes,)
Class labels.

n_features_in_int
Number of features seen during fit.

feature_names_in_ndarray of shape (n_features_in_,)
Names of features seen during fit. Only defined if best_estimator_ is defined (see the documentation for the refit parameter for more details) and that best_estimator_ exposes feature_names_in_ when fit.

Added in version 1.0.

See also

HalvingRandomSearchCV
Random search over a set of parameters using successive halving.

Notes

The parameters selected are those that maximize the score of the held-out data, according to the scoring parameter.

All parameter combinations scored with a NaN will share the lowest rank.

Examples

from sklearn.datasets import load_iris
from sklearn.ensemble import RandomForestClassifier
from sklearn.experimental import enable_halving_search_cv  # noqa
from sklearn.model_selection import HalvingGridSearchCV

X, y = load_iris(return_X_y=True)
clf = RandomForestClassifier(random_state=0)

param_grid = {"max_depth": [3, None],
              "min_samples_split": [5, 10]}
search = HalvingGridSearchCV(clf, param_grid, resource='n_estimators',
                             max_resources=10,
                             random_state=0).fit(X, y)
search.best_params_  
{'max_depth': None, 'min_samples_split': 10, 'n_estimators': 9}
property classes_
Class labels.

Only available when refit=True and the estimator is a classifier.

decision_function(X)[source]
Call decision_function on the estimator with the best found parameters.

Only available if refit=True and the underlying estimator supports decision_function.

Parameters
:
X
indexable, length n_samples
Must fulfill the input assumptions of the underlying estimator.

Returns
:
y_score
ndarray of shape (n_samples,) or (n_samples, n_classes) or (n_samples, n_classes * (n_classes-1) / 2)
Result of the decision function for X based on the estimator with the best found parameters.

fit(X, y=None, **params)[source]
Run fit with all sets of parameters.

Parameters
:
X
array-like, shape (n_samples, n_features)
Training vector, where n_samples is the number of samples and n_features is the number of features.

y
array-like, shape (n_samples,) or (n_samples, n_output), optional
Target relative to X for classification or regression; None for unsupervised learning.

**params
dict of string -> object
Parameters passed to the fit method of the estimator.

Returns
:
self
object
Instance of fitted estimator.

get_metadata_routing()[source]
Get metadata routing of this object.

Please check User Guide on how the routing mechanism works.

Added in version 1.4.

Returns
:
routing
MetadataRouter
A MetadataRouter encapsulating routing information.

get_params(deep=True)[source]
Get parameters for this estimator.

Parameters
:
deep
bool, default=True
If True, will return the parameters for this estimator and contained subobjects that are estimators.

Returns
:
params
dict
Parameter names mapped to their values.

inverse_transform(X=None, Xt=None)[source]
Call inverse_transform on the estimator with the best found params.

Only available if the underlying estimator implements inverse_transform and refit=True.

Parameters:
Xindexable, length n_samples
Must fulfill the input assumptions of the underlying estimator.

Xtindexable, length n_samples
Must fulfill the input assumptions of the underlying estimator.

Deprecated since version 1.5: Xt was deprecated in 1.5 and will be removed in 1.7. Use X instead.

Returns:
X
{ndarray, sparse matrix} of shape (n_samples, n_features)
Result of the inverse_transform function for Xt based on the estimator with the best found parameters.

property n_features_in_
Number of features seen during fit.

Only available when refit=True.

predict(X)[source]
Call predict on the estimator with the best found parameters.

Only available if refit=True and the underlying estimator supports predict.

Parameters
:
X
indexable, length n_samples
Must fulfill the input assumptions of the underlying estimator.

Returns
:
y_pred
ndarray of shape (n_samples,)
The predicted labels or values for X based on the estimator with the best found parameters.

predict_log_proba(X)[source]
Call predict_log_proba on the estimator with the best found parameters.

Only available if refit=True and the underlying estimator supports predict_log_proba.

Parameters
:
X
indexable, length n_samples
Must fulfill the input assumptions of the underlying estimator.

Returns
:
y_pred
ndarray of shape (n_samples,) or (n_samples, n_classes)
Predicted class log-probabilities for X based on the estimator with the best found parameters. The order of the classes corresponds to that in the fitted attribute classes_.

predict_proba(X)[source]
Call predict_proba on the estimator with the best found parameters.

Only available if refit=True and the underlying estimator supports predict_proba.

Parameters
:
X
indexable, length n_samples
Must fulfill the input assumptions of the underlying estimator.

Returns
:
y_pred
ndarray of shape (n_samples,) or (n_samples, n_classes)
Predicted class probabilities for X based on the estimator with the best found parameters. The order of the classes corresponds to that in the fitted attribute classes_.

score(X, y=None, **params)[source]
Return the score on the given data, if the estimator has been refit.

This uses the score defined by scoring where provided, and the best_estimator_.score method otherwise.

Parameters:
Xarray-like of shape (n_samples, n_features)
Input data, where n_samples is the number of samples and n_features is the number of features.

yarray-like of shape (n_samples, n_output) or (n_samples,), default=None
Target relative to X for classification or regression; None for unsupervised learning.

**paramsdict
Parameters to be passed to the underlying scorer(s).

..versionadded:: 1.4
Only available if enable_metadata_routing=True. See Metadata Routing User Guide for more details.

Returns:
score
float
The score defined by scoring if provided, and the best_estimator_.score method otherwise.

score_samples(X)[source]
Call score_samples on the estimator with the best found parameters.

Only available if refit=True and the underlying estimator supports score_samples.

Added in version 0.24.

Parameters
:
X
iterable
Data to predict on. Must fulfill input requirements of the underlying estimator.

Returns
:
y_score
ndarray of shape (n_samples,)
The best_estimator_.score_samples method.

set_params(**params)[source]
Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects (such as Pipeline). The latter have parameters of the form <component>__<parameter> so that it’s possible to update each component of a nested object.

Parameters
:
**params
dict
Estimator parameters.

Returns
:
self
estimator instance
Estimator instance.

transform(X)[source]
Call transform on the estimator with the best found parameters.

Only available if the underlying estimator supports transform and refit=True.

Parameters
:
X
indexable, length n_samples
Must fulfill the input assumptions of the underlying estimator.

Returns
:
Xt
{ndarray, sparse matrix} of shape (n_samples, n_features)
X transformed in the new space based on the estimator with the best found parameters.
###################################################################################

AffinityPropagation
class sklearn.cluster.AffinityPropagation(*, damping=0.5, max_iter=200, convergence_iter=15, copy=True, preference=None, affinity='euclidean', verbose=False, random_state=None)[source]
Perform Affinity Propagation Clustering of data.

Read more in the User Guide.

Parameters:
dampingfloat, default=0.5
Damping factor in the range [0.5, 1.0) is the extent to which the current value is maintained relative to incoming values (weighted 1 - damping). This in order to avoid numerical oscillations when updating these values (messages).

max_iterint, default=200
Maximum number of iterations.

convergence_iterint, default=15
Number of iterations with no change in the number of estimated clusters that stops the convergence.

copybool, default=True
Make a copy of input data.

preferencearray-like of shape (n_samples,) or float, default=None
Preferences for each point - points with larger values of preferences are more likely to be chosen as exemplars. The number of exemplars, ie of clusters, is influenced by the input preferences value. If the preferences are not passed as arguments, they will be set to the median of the input similarities.

affinity{‘euclidean’, ‘precomputed’}, default=’euclidean’
Which affinity to use. At the moment ‘precomputed’ and euclidean are supported. ‘euclidean’ uses the negative squared euclidean distance between points.

verbosebool, default=False
Whether to be verbose.

random_stateint, RandomState instance or None, default=None
Pseudo-random number generator to control the starting state. Use an int for reproducible results across function calls. See the Glossary.

Added in version 0.23: this parameter was previously hardcoded as 0.

Attributes:
cluster_centers_indices_ndarray of shape (n_clusters,)
Indices of cluster centers.

cluster_centers_ndarray of shape (n_clusters, n_features)
Cluster centers (if affinity != precomputed).

labels_ndarray of shape (n_samples,)
Labels of each point.

affinity_matrix_ndarray of shape (n_samples, n_samples)
Stores the affinity matrix used in fit.

n_iter_int
Number of iterations taken to converge.

n_features_in_int
Number of features seen during fit.

Added in version 0.24.

feature_names_in_ndarray of shape (n_features_in_,)
Names of features seen during fit. Defined only when X has feature names that are all strings.

Added in version 1.0.

See also

AgglomerativeClustering
Recursively merges the pair of clusters that minimally increases a given linkage distance.

FeatureAgglomeration
Similar to AgglomerativeClustering, but recursively merges features instead of samples.

KMeans
K-Means clustering.

MiniBatchKMeans
Mini-Batch K-Means clustering.

MeanShift
Mean shift clustering using a flat kernel.

SpectralClustering
Apply clustering to a projection of the normalized Laplacian.

Notes

For an example, see examples/cluster/plot_affinity_propagation.py.

The algorithmic complexity of affinity propagation is quadratic in the number of points.

When the algorithm does not converge, it will still return a arrays of cluster_center_indices and labels if there are any exemplars/clusters, however they may be degenerate and should be used with caution.

When fit does not converge, cluster_centers_ is still populated however it may be degenerate. In such a case, proceed with caution. If fit does not converge and fails to produce any cluster_centers_ then predict will label every sample as -1.

When all training samples have equal similarities and equal preferences, the assignment of cluster centers and labels depends on the preference. If the preference is smaller than the similarities, fit will result in a single cluster center and label 0 for every sample. Otherwise, every training sample becomes its own cluster center and is assigned a unique label.

References

Brendan J. Frey and Delbert Dueck, “Clustering by Passing Messages Between Data Points”, Science Feb. 2007

Examples

from sklearn.cluster import AffinityPropagation
import numpy as np
X = np.array([[1, 2], [1, 4], [1, 0],
              [4, 2], [4, 4], [4, 0]])
clustering = AffinityPropagation(random_state=5).fit(X)
clustering
AffinityPropagation(random_state=5)
clustering.labels_
array([0, 0, 0, 1, 1, 1])
clustering.predict([[0, 0], [4, 4]])
array([0, 1])
clustering.cluster_centers_
array([[1, 2],
       [4, 2]])
fit(X, y=None)[source]
Fit the clustering from features, or affinity matrix.

Parameters
:
X
{array-like, sparse matrix} of shape (n_samples, n_features), or array-like of shape (n_samples, n_samples)
Training instances to cluster, or similarities / affinities between instances if affinity='precomputed'. If a sparse feature matrix is provided, it will be converted into a sparse csr_matrix.

y
Ignored
Not used, present here for API consistency by convention.

Returns
:
self
Returns the instance itself.

fit_predict(X, y=None)[source]
Fit clustering from features/affinity matrix; return cluster labels.

Parameters
:
X
{array-like, sparse matrix} of shape (n_samples, n_features), or array-like of shape (n_samples, n_samples)
Training instances to cluster, or similarities / affinities between instances if affinity='precomputed'. If a sparse feature matrix is provided, it will be converted into a sparse csr_matrix.

y
Ignored
Not used, present here for API consistency by convention.

Returns
:
labels
ndarray of shape (n_samples,)
Cluster labels.

get_metadata_routing()[source]
Get metadata routing of this object.

Please check User Guide on how the routing mechanism works.

Returns
:
routing
MetadataRequest
A MetadataRequest encapsulating routing information.

get_params(deep=True)[source]
Get parameters for this estimator.

Parameters
:
deep
bool, default=True
If True, will return the parameters for this estimator and contained subobjects that are estimators.

Returns
:
params
dict
Parameter names mapped to their values.

predict(X)[source]
Predict the closest cluster each sample in X belongs to.

Parameters
:
X
{array-like, sparse matrix} of shape (n_samples, n_features)
New data to predict. If a sparse matrix is provided, it will be converted into a sparse csr_matrix.

Returns
:
labels
ndarray of shape (n_samples,)
Cluster labels.

set_params(**params)[source]
Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects (such as Pipeline). The latter have parameters of the form <component>__<parameter> so that it’s possible to update each component of a nested object.

Parameters
:
**params
dict
Estimator parameters.

Returns
:
self
estimator instance
Estimator instance.

#######################################################################

Clustering of unlabeled data can be performed with the module sklearn.cluster.

Each clustering algorithm comes in two variants: a class, that implements the fit method to learn the clusters on train data, and a function, that, given train data, returns an array of integer labels corresponding to the different clusters. For the class, the labels over the training data can be found in the labels_ attribute.

Input data

One important thing to note is that the algorithms implemented in this module can take different kinds of matrix as input. All the methods accept standard data matrices of shape (n_samples, n_features). These can be obtained from the classes in the sklearn.feature_extraction module. For AffinityPropagation, SpectralClustering and DBSCAN one can also input similarity matrices of shape (n_samples, n_samples). These can be obtained from the functions in the sklearn.metrics.pairwise module.

2.3.1. Overview of clustering methods
../_images/sphx_glr_plot_cluster_comparison_001.png
A comparison of the clustering algorithms in scikit-learn
Method name

Parameters

Scalability

Usecase

Geometry (metric used)

K-Means

number of clusters

Very large n_samples, medium n_clusters with MiniBatch code

General-purpose, even cluster size, flat geometry, not too many clusters, inductive

Distances between points

Affinity propagation

damping, sample preference

Not scalable with n_samples

Many clusters, uneven cluster size, non-flat geometry, inductive

Graph distance (e.g. nearest-neighbor graph)

Mean-shift

bandwidth

Not scalable with n_samples

Many clusters, uneven cluster size, non-flat geometry, inductive

Distances between points

Spectral clustering

number of clusters

Medium n_samples, small n_clusters

Few clusters, even cluster size, non-flat geometry, transductive

Graph distance (e.g. nearest-neighbor graph)

Ward hierarchical clustering

number of clusters or distance threshold

Large n_samples and n_clusters

Many clusters, possibly connectivity constraints, transductive

Distances between points

Agglomerative clustering

number of clusters or distance threshold, linkage type, distance

Large n_samples and n_clusters

Many clusters, possibly connectivity constraints, non Euclidean distances, transductive

Any pairwise distance

DBSCAN

neighborhood size

Very large n_samples, medium n_clusters

Non-flat geometry, uneven cluster sizes, outlier removal, transductive

Distances between nearest points

HDBSCAN

minimum cluster membership, minimum point neighbors

large n_samples, medium n_clusters

Non-flat geometry, uneven cluster sizes, outlier removal, transductive, hierarchical, variable cluster density

Distances between nearest points

OPTICS

minimum cluster membership

Very large n_samples, large n_clusters

Non-flat geometry, uneven cluster sizes, variable cluster density, outlier removal, transductive

Distances between points

Gaussian mixtures

many

Not scalable

Flat geometry, good for density estimation, inductive

Mahalanobis distances to centers

BIRCH

branching factor, threshold, optional global clusterer.

Large n_clusters and n_samples

Large dataset, outlier removal, data reduction, inductive

Euclidean distance between points

Bisecting K-Means

number of clusters

Very large n_samples, medium n_clusters

General-purpose, even cluster size, flat geometry, no empty clusters, inductive, hierarchical

Distances between points

Non-flat geometry clustering is useful when the clusters have a specific shape, i.e. a non-flat manifold, and the standard euclidean distance is not the right metric. This case arises in the two top rows of the figure above.

Gaussian mixture models, useful for clustering, are described in another chapter of the documentation dedicated to mixture models. KMeans can be seen as a special case of Gaussian mixture model with equal covariance per component.

Transductive clustering methods (in contrast to inductive clustering methods) are not designed to be applied to new, unseen data.
###########################################################################

Clustering can be expensive, especially when our dataset contains millions of datapoints. Many clustering algorithms are not inductive and so cannot be directly applied to new data samples without recomputing the clustering, which may be intractable. Instead, we can use clustering to then learn an inductive model with a classifier, which has several benefits:

it allows the clusters to scale and apply to new data

unlike re-fitting the clusters to new samples, it makes sure the labelling procedure is consistent over time

it allows us to use the inferential capabilities of the classifier to describe or explain the clusters

This example illustrates a generic implementation of a meta-estimator which extends clustering by inducing a classifier from the cluster labels.

Ward Linkage, Unknown instances, Classify unknown instances
# Authors: Chirag Nagpal
#          Christos Aridas

import matplotlib.pyplot as plt

from sklearn.base import BaseEstimator, clone
from sklearn.cluster import AgglomerativeClustering
from sklearn.datasets import make_blobs
from sklearn.ensemble import RandomForestClassifier
from sklearn.inspection import DecisionBoundaryDisplay
from sklearn.utils.metaestimators import available_if
from sklearn.utils.validation import check_is_fitted

N_SAMPLES = 5000
RANDOM_STATE = 42


def _classifier_has(attr):
    """Check if we can delegate a method to the underlying classifier.

    First, we check the first fitted classifier if available, otherwise we
    check the unfitted classifier.
    """
    return lambda estimator: (
        hasattr(estimator.classifier_, attr)
        if hasattr(estimator, "classifier_")
        else hasattr(estimator.classifier, attr)
    )


class InductiveClusterer(BaseEstimator):
    def __init__(self, clusterer, classifier):
        self.clusterer = clusterer
        self.classifier = classifier

    def fit(self, X, y=None):
        self.clusterer_ = clone(self.clusterer)
        self.classifier_ = clone(self.classifier)
        y = self.clusterer_.fit_predict(X)
        self.classifier_.fit(X, y)
        return self

    @available_if(_classifier_has("predict"))
    def predict(self, X):
        check_is_fitted(self)
        return self.classifier_.predict(X)

    @available_if(_classifier_has("decision_function"))
    def decision_function(self, X):
        check_is_fitted(self)
        return self.classifier_.decision_function(X)


def plot_scatter(X, color, alpha=0.5):
    return plt.scatter(X[:, 0], X[:, 1], c=color, alpha=alpha, edgecolor="k")


# Generate some training data from clustering
X, y = make_blobs(
    n_samples=N_SAMPLES,
    cluster_std=[1.0, 1.0, 0.5],
    centers=[(-5, -5), (0, 0), (5, 5)],
    random_state=RANDOM_STATE,
)


# Train a clustering algorithm on the training data and get the cluster labels
clusterer = AgglomerativeClustering(n_clusters=3)
cluster_labels = clusterer.fit_predict(X)

plt.figure(figsize=(12, 4))

plt.subplot(131)
plot_scatter(X, cluster_labels)
plt.title("Ward Linkage")


# Generate new samples and plot them along with the original dataset
X_new, y_new = make_blobs(
    n_samples=10, centers=[(-7, -1), (-2, 4), (3, 6)], random_state=RANDOM_STATE
)

plt.subplot(132)
plot_scatter(X, cluster_labels)
plot_scatter(X_new, "black", 1)
plt.title("Unknown instances")


# Declare the inductive learning model that it will be used to
# predict cluster membership for unknown instances
classifier = RandomForestClassifier(random_state=RANDOM_STATE)
inductive_learner = InductiveClusterer(clusterer, classifier).fit(X)

probable_clusters = inductive_learner.predict(X_new)


ax = plt.subplot(133)
plot_scatter(X, cluster_labels)
plot_scatter(X_new, probable_clusters)

# Plotting decision regions
DecisionBoundaryDisplay.from_estimator(
    inductive_learner, X, response_method="predict", alpha=0.4, ax=ax
)
plt.title("Classify unknown instances")

plt.show()

#####################################
OPTICS
class sklearn.cluster.OPTICS(*, min_samples=5, max_eps=inf, metric='minkowski', p=2, metric_params=None, cluster_method='xi', eps=None, xi=0.05, predecessor_correction=True, min_cluster_size=None, algorithm='auto', leaf_size=30, memory=None, n_jobs=None)[source]
Estimate clustering structure from vector array.

OPTICS (Ordering Points To Identify the Clustering Structure), closely related to DBSCAN, finds core sample of high density and expands clusters from them [1]. Unlike DBSCAN, keeps cluster hierarchy for a variable neighborhood radius. Better suited for usage on large datasets than the current sklearn implementation of DBSCAN.

Clusters are then extracted using a DBSCAN-like method (cluster_method = ‘dbscan’) or an automatic technique proposed in [1] (cluster_method = ‘xi’).

This implementation deviates from the original OPTICS by first performing k-nearest-neighborhood searches on all points to identify core sizes, then computing only the distances to unprocessed points when constructing the cluster order. Note that we do not employ a heap to manage the expansion candidates, so the time complexity will be O(n^2).

Read more in the User Guide.

Parameters:
min_samplesint > 1 or float between 0 and 1, default=5
The number of samples in a neighborhood for a point to be considered as a core point. Also, up and down steep regions can’t have more than min_samples consecutive non-steep points. Expressed as an absolute number or a fraction of the number of samples (rounded to be at least 2).

max_epsfloat, default=np.inf
The maximum distance between two samples for one to be considered as in the neighborhood of the other. Default value of np.inf will identify clusters across all scales; reducing max_eps will result in shorter run times.

metricstr or callable, default=’minkowski’
Metric to use for distance computation. Any metric from scikit-learn or scipy.spatial.distance can be used.

If metric is a callable function, it is called on each pair of instances (rows) and the resulting value recorded. The callable should take two arrays as input and return one value indicating the distance between them. This works for Scipy’s metrics, but is less efficient than passing the metric name as a string. If metric is “precomputed”, X is assumed to be a distance matrix and must be square.

Valid values for metric are:

from scikit-learn: [‘cityblock’, ‘cosine’, ‘euclidean’, ‘l1’, ‘l2’, ‘manhattan’]

from scipy.spatial.distance: [‘braycurtis’, ‘canberra’, ‘chebyshev’, ‘correlation’, ‘dice’, ‘hamming’, ‘jaccard’, ‘kulsinski’, ‘mahalanobis’, ‘minkowski’, ‘rogerstanimoto’, ‘russellrao’, ‘seuclidean’, ‘sokalmichener’, ‘sokalsneath’, ‘sqeuclidean’, ‘yule’]

Sparse matrices are only supported by scikit-learn metrics. See the documentation for scipy.spatial.distance for details on these metrics.

Note

'kulsinski' is deprecated from SciPy 1.9 and will removed in SciPy 1.11.

pfloat, default=2
Parameter for the Minkowski metric from pairwise_distances. When p = 1, this is equivalent to using manhattan_distance (l1), and euclidean_distance (l2) for p = 2. For arbitrary p, minkowski_distance (l_p) is used.

metric_paramsdict, default=None
Additional keyword arguments for the metric function.

cluster_methodstr, default=’xi’
The extraction method used to extract clusters using the calculated reachability and ordering. Possible values are “xi” and “dbscan”.

epsfloat, default=None
The maximum distance between two samples for one to be considered as in the neighborhood of the other. By default it assumes the same value as max_eps. Used only when cluster_method='dbscan'.

xifloat between 0 and 1, default=0.05
Determines the minimum steepness on the reachability plot that constitutes a cluster boundary. For example, an upwards point in the reachability plot is defined by the ratio from one point to its successor being at most 1-xi. Used only when cluster_method='xi'.

predecessor_correctionbool, default=True
Correct clusters according to the predecessors calculated by OPTICS [2]. This parameter has minimal effect on most datasets. Used only when cluster_method='xi'.

min_cluster_sizeint > 1 or float between 0 and 1, default=None
Minimum number of samples in an OPTICS cluster, expressed as an absolute number or a fraction of the number of samples (rounded to be at least 2). If None, the value of min_samples is used instead. Used only when cluster_method='xi'.

algorithm{‘auto’, ‘ball_tree’, ‘kd_tree’, ‘brute’}, default=’auto’
Algorithm used to compute the nearest neighbors:

‘ball_tree’ will use BallTree.

‘kd_tree’ will use KDTree.

‘brute’ will use a brute-force search.

‘auto’ (default) will attempt to decide the most appropriate algorithm based on the values passed to fit method.

Note: fitting on sparse input will override the setting of this parameter, using brute force.

leaf_sizeint, default=30
Leaf size passed to BallTree or KDTree. This can affect the speed of the construction and query, as well as the memory required to store the tree. The optimal value depends on the nature of the problem.

memorystr or object with the joblib.Memory interface, default=None
Used to cache the output of the computation of the tree. By default, no caching is done. If a string is given, it is the path to the caching directory.

n_jobsint, default=None
The number of parallel jobs to run for neighbors search. None means 1 unless in a joblib.parallel_backend context. -1 means using all processors. See Glossary for more details.

Attributes:
labels_ndarray of shape (n_samples,)
Cluster labels for each point in the dataset given to fit(). Noisy samples and points which are not included in a leaf cluster of cluster_hierarchy_ are labeled as -1.

reachability_ndarray of shape (n_samples,)
Reachability distances per sample, indexed by object order. Use clust.reachability_[clust.ordering_] to access in cluster order.

ordering_ndarray of shape (n_samples,)
The cluster ordered list of sample indices.

core_distances_ndarray of shape (n_samples,)
Distance at which each sample becomes a core point, indexed by object order. Points which will never be core have a distance of inf. Use clust.core_distances_[clust.ordering_] to access in cluster order.

predecessor_ndarray of shape (n_samples,)
Point that a sample was reached from, indexed by object order. Seed points have a predecessor of -1.

cluster_hierarchy_ndarray of shape (n_clusters, 2)
The list of clusters in the form of [start, end] in each row, with all indices inclusive. The clusters are ordered according to (end, -start) (ascending) so that larger clusters encompassing smaller clusters come after those smaller ones. Since labels_ does not reflect the hierarchy, usually len(cluster_hierarchy_) > np.unique(optics.labels_). Please also note that these indices are of the ordering_, i.e. X[ordering_][start:end + 1] form a cluster. Only available when cluster_method='xi'.

n_features_in_int
Number of features seen during fit.

Added in version 0.24.

feature_names_in_ndarray of shape (n_features_in_,)
Names of features seen during fit. Defined only when X has feature names that are all strings.

Added in version 1.0.

See also

DBSCAN
A similar clustering for a specified neighborhood radius (eps). Our implementation is optimized for runtime.

References

[1](1,2)
Ankerst, Mihael, Markus M. Breunig, Hans-Peter Kriegel, and Jörg Sander. “OPTICS: ordering points to identify the clustering structure.” ACM SIGMOD Record 28, no. 2 (1999): 49-60.

[2]
Schubert, Erich, Michael Gertz. “Improving the Cluster Structure Extracted from OPTICS Plots.” Proc. of the Conference “Lernen, Wissen, Daten, Analysen” (LWDA) (2018): 318-329.

Examples

from sklearn.cluster import OPTICS
import numpy as np
X = np.array([[1, 2], [2, 5], [3, 6],
              [8, 7], [8, 8], [7, 3]])
clustering = OPTICS(min_samples=2).fit(X)
clustering.labels_
array([0, 0, 0, 1, 1, 1])
For a more detailed example see Demo of OPTICS clustering algorithm.

fit(X, y=None)[source]
Perform OPTICS clustering.

Extracts an ordered list of points and reachability distances, and performs initial clustering using max_eps distance specified at OPTICS object instantiation.

Parameters
:
X
{ndarray, sparse matrix} of shape (n_samples, n_features), or (n_samples, n_samples) if metric=’precomputed’
A feature array, or array of distances between samples if metric=’precomputed’. If a sparse matrix is provided, it will be converted into CSR format.

y
Ignored
Not used, present for API consistency by convention.

Returns
:
self
object
Returns a fitted instance of self.

fit_predict(X, y=None, **kwargs)[source]
Perform clustering on X and returns cluster labels.

Parameters:
Xarray-like of shape (n_samples, n_features)
Input data.

yIgnored
Not used, present for API consistency by convention.

**kwargsdict
Arguments to be passed to fit.

Added in version 1.4.

Returns:
labels
ndarray of shape (n_samples,), dtype=np.int64
Cluster labels.

get_metadata_routing()[source]
Get metadata routing of this object.

Please check User Guide on how the routing mechanism works.

Returns
:
routing
MetadataRequest
A MetadataRequest encapsulating routing information.

get_params(deep=True)[source]
Get parameters for this estimator.

Parameters
:
deep
bool, default=True
If True, will return the parameters for this estimator and contained subobjects that are estimators.

Returns
:
params
dict
Parameter names mapped to their values.

set_params(**params)[source]
Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects (such as Pipeline). The latter have parameters of the form <component>__<parameter> so that it’s possible to update each component of a nested object.

Parameters
:
**params
dict
Estimator parameters.

Returns
:
self
estimator instance
Estimator instance.

###############################################
dbscan
sklearn.cluster.dbscan(X, eps=0.5, *, min_samples=5, metric='minkowski', metric_params=None, algorithm='auto', leaf_size=30, p=2, sample_weight=None, n_jobs=None)[source]
Perform DBSCAN clustering from vector array or distance matrix.

Read more in the User Guide.

Parameters:
X{array-like, sparse (CSR) matrix} of shape (n_samples, n_features) or (n_samples, n_samples)
A feature array, or array of distances between samples if metric='precomputed'.

epsfloat, default=0.5
The maximum distance between two samples for one to be considered as in the neighborhood of the other. This is not a maximum bound on the distances of points within a cluster. This is the most important DBSCAN parameter to choose appropriately for your data set and distance function.

min_samplesint, default=5
The number of samples (or total weight) in a neighborhood for a point to be considered as a core point. This includes the point itself.

metricstr or callable, default=’minkowski’
The metric to use when calculating distance between instances in a feature array. If metric is a string or callable, it must be one of the options allowed by sklearn.metrics.pairwise_distances for its metric parameter. If metric is “precomputed”, X is assumed to be a distance matrix and must be square during fit. X may be a sparse graph, in which case only “nonzero” elements may be considered neighbors.

metric_paramsdict, default=None
Additional keyword arguments for the metric function.

Added in version 0.19.

algorithm{‘auto’, ‘ball_tree’, ‘kd_tree’, ‘brute’}, default=’auto’
The algorithm to be used by the NearestNeighbors module to compute pointwise distances and find nearest neighbors. See NearestNeighbors module documentation for details.

leaf_sizeint, default=30
Leaf size passed to BallTree or cKDTree. This can affect the speed of the construction and query, as well as the memory required to store the tree. The optimal value depends on the nature of the problem.

pfloat, default=2
The power of the Minkowski metric to be used to calculate distance between points.

sample_weightarray-like of shape (n_samples,), default=None
Weight of each sample, such that a sample with a weight of at least min_samples is by itself a core sample; a sample with negative weight may inhibit its eps-neighbor from being core. Note that weights are absolute, and default to 1.

n_jobsint, default=None
The number of parallel jobs to run for neighbors search. None means 1 unless in a joblib.parallel_backend context. -1 means using all processors. See Glossary for more details. If precomputed distance are used, parallel execution is not available and thus n_jobs will have no effect.

Returns:
core_samples
ndarray of shape (n_core_samples,)
Indices of core samples.

labels
ndarray of shape (n_samples,)
Cluster labels for each point. Noisy samples are given the label -1.

See also

DBSCAN
An estimator interface for this clustering algorithm.

OPTICS
A similar estimator interface clustering at multiple values of eps. Our implementation is optimized for memory usage.

Notes

For an example, see examples/cluster/plot_dbscan.py.

This implementation bulk-computes all neighborhood queries, which increases the memory complexity to O(n.d) where d is the average number of neighbors, while original DBSCAN had memory complexity O(n). It may attract a higher memory complexity when querying these nearest neighborhoods, depending on the algorithm.

One way to avoid the query complexity is to pre-compute sparse neighborhoods in chunks using NearestNeighbors.radius_neighbors_graph with mode='distance', then using metric='precomputed' here.

Another way to reduce memory and computation time is to remove (near-)duplicate points and use sample_weight instead.

OPTICS provides a similar clustering with lower memory usage.

####################################
OPTICS
class sklearn.cluster.OPTICS(*, min_samples=5, max_eps=inf, metric='minkowski', p=2, metric_params=None, cluster_method='xi', eps=None, xi=0.05, predecessor_correction=True, min_cluster_size=None, algorithm='auto', leaf_size=30, memory=None, n_jobs=None)[source]
Estimate clustering structure from vector array.

OPTICS (Ordering Points To Identify the Clustering Structure), closely related to DBSCAN, finds core sample of high density and expands clusters from them [1]. Unlike DBSCAN, keeps cluster hierarchy for a variable neighborhood radius. Better suited for usage on large datasets than the current sklearn implementation of DBSCAN.

Clusters are then extracted using a DBSCAN-like method (cluster_method = ‘dbscan’) or an automatic technique proposed in [1] (cluster_method = ‘xi’).

This implementation deviates from the original OPTICS by first performing k-nearest-neighborhood searches on all points to identify core sizes, then computing only the distances to unprocessed points when constructing the cluster order. Note that we do not employ a heap to manage the expansion candidates, so the time complexity will be O(n^2).

Read more in the User Guide.

Parameters:
min_samplesint > 1 or float between 0 and 1, default=5
The number of samples in a neighborhood for a point to be considered as a core point. Also, up and down steep regions can’t have more than min_samples consecutive non-steep points. Expressed as an absolute number or a fraction of the number of samples (rounded to be at least 2).

max_epsfloat, default=np.inf
The maximum distance between two samples for one to be considered as in the neighborhood of the other. Default value of np.inf will identify clusters across all scales; reducing max_eps will result in shorter run times.

metricstr or callable, default=’minkowski’
Metric to use for distance computation. Any metric from scikit-learn or scipy.spatial.distance can be used.

If metric is a callable function, it is called on each pair of instances (rows) and the resulting value recorded. The callable should take two arrays as input and return one value indicating the distance between them. This works for Scipy’s metrics, but is less efficient than passing the metric name as a string. If metric is “precomputed”, X is assumed to be a distance matrix and must be square.

Valid values for metric are:

from scikit-learn: [‘cityblock’, ‘cosine’, ‘euclidean’, ‘l1’, ‘l2’, ‘manhattan’]

from scipy.spatial.distance: [‘braycurtis’, ‘canberra’, ‘chebyshev’, ‘correlation’, ‘dice’, ‘hamming’, ‘jaccard’, ‘kulsinski’, ‘mahalanobis’, ‘minkowski’, ‘rogerstanimoto’, ‘russellrao’, ‘seuclidean’, ‘sokalmichener’, ‘sokalsneath’, ‘sqeuclidean’, ‘yule’]

Sparse matrices are only supported by scikit-learn metrics. See the documentation for scipy.spatial.distance for details on these metrics.

Note

'kulsinski' is deprecated from SciPy 1.9 and will removed in SciPy 1.11.

pfloat, default=2
Parameter for the Minkowski metric from pairwise_distances. When p = 1, this is equivalent to using manhattan_distance (l1), and euclidean_distance (l2) for p = 2. For arbitrary p, minkowski_distance (l_p) is used.

metric_paramsdict, default=None
Additional keyword arguments for the metric function.

cluster_methodstr, default=’xi’
The extraction method used to extract clusters using the calculated reachability and ordering. Possible values are “xi” and “dbscan”.

epsfloat, default=None
The maximum distance between two samples for one to be considered as in the neighborhood of the other. By default it assumes the same value as max_eps. Used only when cluster_method='dbscan'.

xifloat between 0 and 1, default=0.05
Determines the minimum steepness on the reachability plot that constitutes a cluster boundary. For example, an upwards point in the reachability plot is defined by the ratio from one point to its successor being at most 1-xi. Used only when cluster_method='xi'.

predecessor_correctionbool, default=True
Correct clusters according to the predecessors calculated by OPTICS [2]. This parameter has minimal effect on most datasets. Used only when cluster_method='xi'.

min_cluster_sizeint > 1 or float between 0 and 1, default=None
Minimum number of samples in an OPTICS cluster, expressed as an absolute number or a fraction of the number of samples (rounded to be at least 2). If None, the value of min_samples is used instead. Used only when cluster_method='xi'.

algorithm{‘auto’, ‘ball_tree’, ‘kd_tree’, ‘brute’}, default=’auto’
Algorithm used to compute the nearest neighbors:

‘ball_tree’ will use BallTree.

‘kd_tree’ will use KDTree.

‘brute’ will use a brute-force search.

‘auto’ (default) will attempt to decide the most appropriate algorithm based on the values passed to fit method.

Note: fitting on sparse input will override the setting of this parameter, using brute force.

leaf_sizeint, default=30
Leaf size passed to BallTree or KDTree. This can affect the speed of the construction and query, as well as the memory required to store the tree. The optimal value depends on the nature of the problem.

memorystr or object with the joblib.Memory interface, default=None
Used to cache the output of the computation of the tree. By default, no caching is done. If a string is given, it is the path to the caching directory.

n_jobsint, default=None
The number of parallel jobs to run for neighbors search. None means 1 unless in a joblib.parallel_backend context. -1 means using all processors. See Glossary for more details.

Attributes:
labels_ndarray of shape (n_samples,)
Cluster labels for each point in the dataset given to fit(). Noisy samples and points which are not included in a leaf cluster of cluster_hierarchy_ are labeled as -1.

reachability_ndarray of shape (n_samples,)
Reachability distances per sample, indexed by object order. Use clust.reachability_[clust.ordering_] to access in cluster order.

ordering_ndarray of shape (n_samples,)
The cluster ordered list of sample indices.

core_distances_ndarray of shape (n_samples,)
Distance at which each sample becomes a core point, indexed by object order. Points which will never be core have a distance of inf. Use clust.core_distances_[clust.ordering_] to access in cluster order.

predecessor_ndarray of shape (n_samples,)
Point that a sample was reached from, indexed by object order. Seed points have a predecessor of -1.

cluster_hierarchy_ndarray of shape (n_clusters, 2)
The list of clusters in the form of [start, end] in each row, with all indices inclusive. The clusters are ordered according to (end, -start) (ascending) so that larger clusters encompassing smaller clusters come after those smaller ones. Since labels_ does not reflect the hierarchy, usually len(cluster_hierarchy_) > np.unique(optics.labels_). Please also note that these indices are of the ordering_, i.e. X[ordering_][start:end + 1] form a cluster. Only available when cluster_method='xi'.

n_features_in_int
Number of features seen during fit.

Added in version 0.24.

feature_names_in_ndarray of shape (n_features_in_,)
Names of features seen during fit. Defined only when X has feature names that are all strings.

Added in version 1.0.

See also

DBSCAN
A similar clustering for a specified neighborhood radius (eps). Our implementation is optimized for runtime.

References

[1](1,2)
Ankerst, Mihael, Markus M. Breunig, Hans-Peter Kriegel, and Jörg Sander. “OPTICS: ordering points to identify the clustering structure.” ACM SIGMOD Record 28, no. 2 (1999): 49-60.

[2]
Schubert, Erich, Michael Gertz. “Improving the Cluster Structure Extracted from OPTICS Plots.” Proc. of the Conference “Lernen, Wissen, Daten, Analysen” (LWDA) (2018): 318-329.

Examples

from sklearn.cluster import OPTICS
import numpy as np
X = np.array([[1, 2], [2, 5], [3, 6],
              [8, 7], [8, 8], [7, 3]])
clustering = OPTICS(min_samples=2).fit(X)
clustering.labels_
array([0, 0, 0, 1, 1, 1])
For a more detailed example see Demo of OPTICS clustering algorithm.

fit(X, y=None)[source]
Perform OPTICS clustering.

Extracts an ordered list of points and reachability distances, and performs initial clustering using max_eps distance specified at OPTICS object instantiation.

Parameters
:
X
{ndarray, sparse matrix} of shape (n_samples, n_features), or (n_samples, n_samples) if metric=’precomputed’
A feature array, or array of distances between samples if metric=’precomputed’. If a sparse matrix is provided, it will be converted into CSR format.

y
Ignored
Not used, present for API consistency by convention.

Returns
:
self
object
Returns a fitted instance of self.

fit_predict(X, y=None, **kwargs)[source]
Perform clustering on X and returns cluster labels.

Parameters:
Xarray-like of shape (n_samples, n_features)
Input data.

yIgnored
Not used, present for API consistency by convention.

**kwargsdict
Arguments to be passed to fit.

Added in version 1.4.

Returns:
labels
ndarray of shape (n_samples,), dtype=np.int64
Cluster labels.

get_metadata_routing()[source]
Get metadata routing of this object.

Please check User Guide on how the routing mechanism works.

Returns
:
routing
MetadataRequest
A MetadataRequest encapsulating routing information.

get_params(deep=True)[source]
Get parameters for this estimator.

Parameters
:
deep
bool, default=True
If True, will return the parameters for this estimator and contained subobjects that are estimators.

Returns
:
params
dict
Parameter names mapped to their values.

set_params(**params)[source]
Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects (such as Pipeline). The latter have parameters of the form <component>__<parameter> so that it’s possible to update each component of a nested object.

Parameters
:
**params
dict
Estimator parameters.

Returns
:
self
estimator instance
Estimator instance.

###############################################

sklearn.cluster
Agglomerativ...
AgglomerativeClustering
class sklearn.cluster.AgglomerativeClustering(n_clusters=2, *, metric='euclidean', memory=None, connectivity=None, compute_full_tree='auto', linkage='ward', distance_threshold=None, compute_distances=False)[source]
Agglomerative Clustering.

Recursively merges pair of clusters of sample data; uses linkage distance.

Read more in the User Guide.

Parameters:
n_clustersint or None, default=2
The number of clusters to find. It must be None if distance_threshold is not None.

metricstr or callable, default=”euclidean”
Metric used to compute the linkage. Can be “euclidean”, “l1”, “l2”, “manhattan”, “cosine”, or “precomputed”. If linkage is “ward”, only “euclidean” is accepted. If “precomputed”, a distance matrix is needed as input for the fit method.

Added in version 1.2.

Deprecated since version 1.4: metric=None is deprecated in 1.4 and will be removed in 1.6. Let metric be the default value (i.e. "euclidean") instead.

memorystr or object with the joblib.Memory interface, default=None
Used to cache the output of the computation of the tree. By default, no caching is done. If a string is given, it is the path to the caching directory.

connectivityarray-like, sparse matrix, or callable, default=None
Connectivity matrix. Defines for each sample the neighboring samples following a given structure of the data. This can be a connectivity matrix itself or a callable that transforms the data into a connectivity matrix, such as derived from kneighbors_graph. Default is None, i.e, the hierarchical clustering algorithm is unstructured.

For an example of connectivity matrix using kneighbors_graph, see Agglomerative clustering with and without structure.

compute_full_tree‘auto’ or bool, default=’auto’
Stop early the construction of the tree at n_clusters. This is useful to decrease computation time if the number of clusters is not small compared to the number of samples. This option is useful only when specifying a connectivity matrix. Note also that when varying the number of clusters and using caching, it may be advantageous to compute the full tree. It must be True if distance_threshold is not None. By default compute_full_tree is “auto”, which is equivalent to True when distance_threshold is not None or that n_clusters is inferior to the maximum between 100 or 0.02 * n_samples. Otherwise, “auto” is equivalent to False.

linkage{‘ward’, ‘complete’, ‘average’, ‘single’}, default=’ward’
Which linkage criterion to use. The linkage criterion determines which distance to use between sets of observation. The algorithm will merge the pairs of cluster that minimize this criterion.

‘ward’ minimizes the variance of the clusters being merged.

‘average’ uses the average of the distances of each observation of the two sets.

‘complete’ or ‘maximum’ linkage uses the maximum distances between all observations of the two sets.

‘single’ uses the minimum of the distances between all observations of the two sets.

Added in version 0.20: Added the ‘single’ option

For examples comparing different linkage criteria, see Comparing different hierarchical linkage methods on toy datasets.

distance_thresholdfloat, default=None
The linkage distance threshold at or above which clusters will not be merged. If not None, n_clusters must be None and compute_full_tree must be True.

Added in version 0.21.

compute_distancesbool, default=False
Computes distances between clusters even if distance_threshold is not used. This can be used to make dendrogram visualization, but introduces a computational and memory overhead.

Added in version 0.24.

For an example of dendrogram visualization, see Plot Hierarchical Clustering Dendrogram.

Attributes:
n_clusters_int
The number of clusters found by the algorithm. If distance_threshold=None, it will be equal to the given n_clusters.

labels_ndarray of shape (n_samples)
Cluster labels for each point.

n_leaves_int
Number of leaves in the hierarchical tree.

n_connected_components_int
The estimated number of connected components in the graph.

Added in version 0.21: n_connected_components_ was added to replace n_components_.

n_features_in_int
Number of features seen during fit.

Added in version 0.24.

feature_names_in_ndarray of shape (n_features_in_,)
Names of features seen during fit. Defined only when X has feature names that are all strings.

Added in version 1.0.

children_array-like of shape (n_samples-1, 2)
The children of each non-leaf node. Values less than n_samples correspond to leaves of the tree which are the original samples. A node i greater than or equal to n_samples is a non-leaf node and has children children_[i - n_samples]. Alternatively at the i-th iteration, children[i][0] and children[i][1] are merged to form node n_samples + i.

distances_array-like of shape (n_nodes-1,)
Distances between nodes in the corresponding place in children_. Only computed if distance_threshold is used or compute_distances is set to True.

See also

FeatureAgglomeration
Agglomerative clustering but for features instead of samples.

ward_tree
Hierarchical clustering with ward linkage.

Examples

from sklearn.cluster import AgglomerativeClustering
import numpy as np
X = np.array([[1, 2], [1, 4], [1, 0],
              [4, 2], [4, 4], [4, 0]])
clustering = AgglomerativeClustering().fit(X)
clustering
AgglomerativeClustering()
clustering.labels_
array([1, 1, 1, 0, 0, 0])
fit(X, y=None)[source]
Fit the hierarchical clustering from features, or distance matrix.

Parameters
:
X
array-like, shape (n_samples, n_features) or (n_samples, n_samples)
Training instances to cluster, or distances between instances if metric='precomputed'.

y
Ignored
Not used, present here for API consistency by convention.

Returns
:
self
object
Returns the fitted instance.

fit_predict(X, y=None)[source]
Fit and return the result of each sample’s clustering assignment.

In addition to fitting, this method also return the result of the clustering assignment for each sample in the training set.

Parameters
:
X
array-like of shape (n_samples, n_features) or (n_samples, n_samples)
Training instances to cluster, or distances between instances if affinity='precomputed'.

y
Ignored
Not used, present here for API consistency by convention.

Returns
:
labels
ndarray of shape (n_samples,)
Cluster labels.

get_metadata_routing()[source]
Get metadata routing of this object.

Please check User Guide on how the routing mechanism works.

Returns
:
routing
MetadataRequest
A MetadataRequest encapsulating routing information.

get_params(deep=True)[source]
Get parameters for this estimator.

Parameters
:
deep
bool, default=True
If True, will return the parameters for this estimator and contained subobjects that are estimators.

Returns
:
params
dict
Parameter names mapped to their values.

set_params(**params)[source]
Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects (such as Pipeline). The latter have parameters of the form <component>__<parameter> so that it’s possible to update each component of a nested object.

Parameters
:
**params
dict
Estimator parameters.

Returns
:
self
estimator instance
Estimator instance.

######################################################################

