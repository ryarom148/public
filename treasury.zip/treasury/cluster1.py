import numpy as np
import logging
import time
from tslearn.clustering import TimeSeriesKMeans, TimeSeriesKMedoids
from tslearn.metrics import (
    cdist_dtw, cdist_lcss, cdist_erp
)
from aeon.distances import (
    edr_distance, msm_distance, twe_distance
)
from sklearn.cluster import AgglomerativeClustering, DBSCAN
from sklearn.metrics import silhouette_score, davies_bouldin_score, calinski_harabasz_score
from sklearn.model_selection import ParameterGrid
from joblib import Parallel, delayed
import warnings
from typing import Dict, Tuple, Any
import pickle

warnings.filterwarnings('ignore')

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class TimeSeriesClusterPredictor:
    def __init__(self):
        # Map distance metric names to functions or strings
        self.distance_metrics = {
            'dtw': 'dtw',
            'euclidean': 'euclidean',
            'lcss': 'lcss',
            'erp': 'erp',
            'edr': edr_distance,
            'msm': msm_distance,
            'twe': twe_distance,
        }
        self.clustering_algorithms = {
            'kmeans': TimeSeriesKMeans,
            'kmedoids': TimeSeriesKMedoids,
            'agglomerative': AgglomerativeClustering,
            'dbscan': DBSCAN,
        }
        self.best_model = None
        self.best_distance = None
        self.best_distance_params = None
        self.best_algorithm = None
        self.best_algo_params = None
        self.cluster_centers = None
        self.outlier_threshold = None
        self.labels_ = None
        self.distance_matrix_cache = {}

    def compute_distance_matrix(self, X: np.ndarray, Y: np.ndarray, distance: str, distance_params: Dict, n_jobs: int = -1) -> np.ndarray:
        """
        Compute the pairwise distance matrix using appropriate functions.
        """
        start_time = time.time()
        logger.info(f"Computing distance matrix using {distance}...")
        metric = self.distance_metrics[distance]
        if metric == 'dtw':
            distances = cdist_dtw(X, Y, n_jobs=n_jobs, **distance_params)
        elif metric == 'lcss':
            distances = cdist_lcss(X, Y, n_jobs=n_jobs, **distance_params)
        elif metric == 'erp':
            distances = cdist_erp(X, Y, n_jobs=n_jobs, **distance_params)
        elif callable(metric):
            # For metrics from aeon that are callable functions
            distances = self.cdist_aeon_metric(X, Y, metric, n_jobs=n_jobs, **distance_params)
        elif metric == 'euclidean':
            # For Euclidean distances, flatten the time series
            from sklearn.metrics import pairwise_distances
            X_flat = X.reshape((len(X), -1))
            Y_flat = Y.reshape((len(Y), -1))
            distances = pairwise_distances(X_flat, Y_flat, metric=metric)
        else:
            raise ValueError(f"Unsupported distance metric: {distance}")
        end_time = time.time()
        logger.info(f"Distance matrix computed in {end_time - start_time:.2f} seconds.")
        return distances

    def cdist_aeon_metric(self, X, Y, metric_func, n_jobs=-1, **metric_params):
        """
        Compute pairwise distance matrix using aeon metrics with parallelization.
        """
        n_x = len(X)
        n_y = len(Y)
        distances = np.zeros((n_x, n_y))

        def compute_row(i):
            return [metric_func(X[i], Y[j], **metric_params) for j in range(n_y)]

        results = Parallel(n_jobs=n_jobs)(
            delayed(compute_row)(i) for i in range(n_x)
        )
        distances = np.array(results)
        return distances

    def fit(self, X: np.ndarray, distance: str = None, distance_params: Dict = None, algorithm: str = None, algo_params: Dict = None, precomputed_distance_matrix: np.ndarray = None):
        """
        Fit the clustering model to the data.
        """
        if distance is None:
            distance = self.best_distance
        if distance_params is None:
            distance_params = self.best_distance_params
        if algorithm is None:
            algorithm = self.best_algorithm
        if algo_params is None:
            algo_params = self.best_algo_params

        if distance is None or algorithm is None:
            raise ValueError("Distance and algorithm must be specified.")

        self.best_distance = distance
        self.best_distance_params = distance_params
        self.best_algorithm = algorithm
        self.best_algo_params = algo_params

        # Use the precomputed distance matrix if provided
        if precomputed_distance_matrix is not None:
            distance_matrix = precomputed_distance_matrix
        else:
            distance_matrix = self.compute_distance_matrix(X, X, distance, distance_params)

        start_time = time.time()
        logger.info(f"Fitting {algorithm} clustering...")

        if algorithm in ['kmeans', 'kmedoids']:
            # Use tslearn's clustering algorithms
            tslearn_algo = self.clustering_algorithms[algorithm]
            n_clusters = algo_params.get('n_clusters', 3)
            max_iter = algo_params.get('max_iter', 50)
            random_state = algo_params.get('random_state', 42)

            self.best_model = tslearn_algo(
                n_clusters=n_clusters,
                metric=distance,
                metric_params=distance_params,
                max_iter=max_iter,
                random_state=random_state,
                n_jobs=-1
            )
            self.best_model.fit(X)
            self.labels_ = self.best_model.labels_
            self.cluster_centers = self.best_model.cluster_centers_
        elif algorithm == 'agglomerative':
            linkage = algo_params.get('linkage', 'average')
            distance_threshold = algo_params.get('distance_threshold', None)
            if distance_threshold is None:
                raise ValueError("distance_threshold must be provided for agglomerative clustering when n_clusters is None.")
            self.best_model = AgglomerativeClustering(
                affinity='precomputed',
                linkage=linkage,
                distance_threshold=distance_threshold,
                n_clusters=None
            )
            self.best_model.fit(distance_matrix)
            self.labels_ = self.best_model.labels_
            unique_labels = np.unique(self.labels_)
            # Compute cluster centers as medoids
            self.cluster_centers = np.array([
                X[self.labels_ == label][
                    np.argmin(np.sum(distance_matrix[np.ix_(self.labels_ == label, self.labels_ == label)], axis=1))
                ] for label in unique_labels
            ])
        elif algorithm == 'dbscan':
            eps = algo_params.get('eps', 0.5)
            min_samples = algo_params.get('min_samples', 5)
            self.best_model = DBSCAN(
                eps=eps,
                min_samples=min_samples,
                metric='precomputed',
                n_jobs=-1
            )
            self.best_model.fit(distance_matrix)
            self.labels_ = self.best_model.labels_
            unique_labels = np.unique(self.labels_)
            # Compute cluster centers as medoids
            self.cluster_centers = np.array([
                X[self.labels_ == label][
                    np.argmin(np.sum(distance_matrix[np.ix_(self.labels_ == label, self.labels_ == label)], axis=1))
                ] for label in unique_labels if label != -1
            ])
        else:
            raise ValueError(f"Unsupported clustering algorithm: {algorithm}")

        # Calculate outlier threshold using IQR
        if self.cluster_centers is not None and len(self.cluster_centers) > 0:
            cluster_distances = self.compute_distance_matrix(X, self.cluster_centers, distance, distance_params)
            min_distances = cluster_distances.min(axis=1)
            q1, q3 = np.percentile(min_distances, [25, 75])
            iqr = q3 - q1
            self.outlier_threshold = q3 + 1.5 * iqr  # Outlier threshold

        end_time = time.time()
        logger.info(f"Model fitted in {end_time - start_time:.2f} seconds.")

    def predict(self, X: np.ndarray) -> np.ndarray:
        """
        Predict cluster labels for new data.
        """
        if self.best_model is None or self.cluster_centers is None:
            raise ValueError("Model is not fitted yet. Call 'fit' before using this method.")

        start_time = time.time()
        logger.info(f"Predicting cluster labels using {self.best_algorithm}...")

        if self.best_algorithm in ['kmeans', 'kmedoids']:
            labels = self.best_model.predict(X)
        else:
            # For other algorithms, compute labels based on distances to cluster centers
            distances_to_centers = self.compute_distance_matrix(X, self.cluster_centers, self.best_distance, self.best_distance_params)
            labels = distances_to_centers.argmin(axis=1)

        # Detect outliers for all algorithms
        distances_to_centers = self.compute_distance_matrix(X, self.cluster_centers, self.best_distance, self.best_distance_params)
        min_distances = distances_to_centers.min(axis=1)
        outliers = min_distances > self.outlier_threshold
        labels[outliers] = -1  # Mark outliers

        end_time = time.time()
        logger.info(f"Prediction completed in {end_time - start_time:.2f} seconds.")
        return labels

    def estimate_eps_range(self, distance_matrix: np.ndarray, min_samples: int, num_values: int = 5) -> np.ndarray:
        """
        Estimate a range of eps values for DBSCAN using the k-distance method.
        """
        distances = np.sort(distance_matrix, axis=1)
        k_distances = distances[:, min_samples]  # min_samples-th neighbor
        k_distances.sort()

        percentiles = np.linspace(70, 90, num=num_values)
        eps_values = np.percentile(k_distances, percentiles)
        return eps_values

    def estimate_distance_thresholds(self, distance_matrix: np.ndarray, num_values: int = 5) -> np.ndarray:
        """
        Estimate a range of distance_threshold values for AgglomerativeClustering.
        """
        distances = distance_matrix[np.triu_indices_from(distance_matrix, k=1)]
        distances.sort()
        percentiles = np.linspace(10, 90, num=num_values)
        thresholds = np.percentile(distances, percentiles)
        return thresholds

    def find_best_params(self, X: np.ndarray, param_grid: Dict, X_test: np.ndarray = None, n_jobs: int = -1) -> Tuple[Any, Any, Any, Any]:
        """
        Find the best parameters using grid search.
        """
        best_score = float('-inf')
        best_distance = None
        best_distance_params = None
        best_algorithm = None
        best_algo_params = None

        param_list = list(ParameterGrid(param_grid))

        # Cache for distance matrices
        if not hasattr(self, 'distance_matrix_cache'):
            self.distance_matrix_cache = {}

        def evaluate_params(params):
            nonlocal best_score, best_distance, best_distance_params, best_algorithm, best_algo_params

            distance = params['distance']
            algorithm = params['algorithm']

            # Extract distance parameters
            distance_param_names = ['epsilon', 'window', 'g', 'c', 'nu', 'lmbda']
            distance_params = {k: params[k] for k in distance_param_names if k in params}

            # Extract algorithm parameters
            algo_param_names = set(params.keys()) - set(['distance', 'algorithm']) - set(distance_param_names)
            algo_params = {k: params[k] for k in algo_param_names}

            # Create a key for caching
            distance_key = (distance, tuple(sorted(distance_params.items())))

            # Compute or retrieve the distance matrix
            if distance_key in self.distance_matrix_cache:
                distance_matrix = self.distance_matrix_cache[distance_key]
            else:
                try:
                    distance_matrix = self.compute_distance_matrix(X, X, distance, distance_params, n_jobs=n_jobs)
                    self.distance_matrix_cache[distance_key] = distance_matrix
                except Exception as e:
                    logger.error(f"Failed to compute distance matrix with distance '{distance}' and params {distance_params}: {e}")
                    return

            # Estimate parameters if necessary
            if algorithm == 'dbscan' and 'eps' not in algo_params:
                eps_values = self.estimate_eps_range(distance_matrix, algo_params.get('min_samples', 5))
                algo_params_list = [dict(algo_params, eps=eps) for eps in eps_values]
            elif algorithm == 'agglomerative' and 'distance_threshold' not in algo_params:
                thresholds = self.estimate_distance_thresholds(distance_matrix)
                algo_params_list = [dict(algo_params, distance_threshold=thresh) for thresh in thresholds]
            else:
                algo_params_list = [algo_params]

            for algo_params_variant in algo_params_list:
                try:
                    # Fit the model
                    self.fit(X, distance, distance_params, algorithm, algo_params_variant, precomputed_distance_matrix=distance_matrix)
                    labels = self.predict(X)

                    # Compute clustering scores
                    X_flat = X.reshape((len(X), -1))
                    labels_unique = np.unique(labels)
                    if len(labels_unique) < 2:
                        # Can't compute clustering scores with less than 2 clusters
                        continue

                    silhouette = silhouette_score(X_flat, labels, metric='euclidean')
                    db_score = davies_bouldin_score(X_flat, labels)
                    ch_score = calinski_harabasz_score(X_flat, labels)

                    # Normalize scores
                    silhouette_norm = (silhouette + 1) / 2  # Silhouette score ranges from -1 to 1
                    db_score_norm = 1 / (db_score + 1)  # Lower is better for DB score
                    ch_score_norm = (ch_score - np.min(ch_score)) / (np.ptp(ch_score) + 1e-10)

                    clustering_score = (silhouette_norm + db_score_norm + ch_score_norm) / 3

                    if X_test is not None:
                        test_labels = self.predict(X_test)
                        outlier_ratio = np.sum(test_labels == -1) / len(X_test)
                        outlier_score = 1 - outlier_ratio  # Higher is better
                        combined_score = (clustering_score + outlier_score) / 2
                    else:
                        combined_score = clustering_score

                    logger.info(f"Evaluated params {params}, algo_params {algo_params_variant}, score {combined_score:.4f}")

                    if combined_score > best_score:
                        best_score = combined_score
                        best_distance = distance
                        best_distance_params = distance_params
                        best_algorithm = algorithm
                        best_algo_params = algo_params_variant
                        # Save the best model and related attributes
                        self.best_model_ = self.best_model
                        self.cluster_centers_ = self.cluster_centers.copy()
                        self.outlier_threshold_ = self.outlier_threshold
                except Exception as e:
                    logger.error(f"Failed with params {params}, algo_params {algo_params_variant}: {e}")

        # Parallel grid search
        Parallel(n_jobs=n_jobs)(delayed(evaluate_params)(params) for params in param_list)

        # Restore the best model
        self.best_model = self.best_model_
        self.cluster_centers = self.cluster_centers_
        self.outlier_threshold = self.outlier_threshold_

        # Set the best parameters
        self.best_distance = best_distance
        self.best_distance_params = best_distance_params
        self.best_algorithm = best_algorithm
        self.best_algo_params = best_algo_params

        return best_distance, best_distance_params, best_algorithm, best_algo_params

    def save_model(self, filepath: str):
        """
        Save the model to a file.
        """
        with open(filepath, 'wb') as f:
            pickle.dump({
                'best_model': self.best_model,
                'best_distance': self.best_distance,
                'best_distance_params': self.best_distance_params,
                'best_algorithm': self.best_algorithm,
                'best_algo_params': self.best_algo_params,
                'cluster_centers': self.cluster_centers,
                'outlier_threshold': self.outlier_threshold,
            }, f)

    def load_model(self, filepath: str):
        """
        Load the model from a file.
        """
        with open(filepath, 'rb') as f:
            data = pickle.load(f)
            self.best_model = data['best_model']
            self.best_distance = data['best_distance']
            self.best_distance_params = data['best_distance_params']
            self.best_algorithm = data['best_algorithm']
            self.best_algo_params = data['best_algo_params']
            self.cluster_centers = data['cluster_centers']
            self.outlier_threshold = data['outlier_threshold']

    # Additional methods (e.g., for evaluation) can be added here
