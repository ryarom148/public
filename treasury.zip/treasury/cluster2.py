import numpy as np
import time
from tslearn.clustering import TimeSeriesKMeans
from tslearn.metrics import cdist_dtw, cdist_soft_dtw
from sklearn.metrics import pairwise_distances
from aeon.distances import (
    lcss_distance, erp_distance, edr_distance, msm_distance, twe_distance
)
from aeon.clustering.k_medoids import TimeSeriesKMedoids
from sklearn.cluster import AgglomerativeClustering, DBSCAN
from sklearn.metrics import (
    silhouette_score, davies_bouldin_score, calinski_harabasz_score
)
from sklearn.model_selection import ParameterGrid
from joblib import Parallel, delayed
import warnings
import networkx as nx
import pickle

warnings.filterwarnings('ignore')

class TimeSeriesClusterPredictor:
    def __init__(self):
        self.distance_metrics = {
            'dtw': 'dtw',            # tslearn metric
            'softdtw': 'softdtw',    # tslearn metric
            'euclidean': 'euclidean',# tslearn metric
            # aeon metrics
            'lcss': lcss_distance,
            'erp': erp_distance,
            'edr': edr_distance,
            'msm': msm_distance,
            'twe': twe_distance,
        }
        self.clustering_algorithms = {
            'kmeans': TimeSeriesKMeans,
            'kmedoids': TimeSeriesKMedoids,
            'agglomerative': AgglomerativeClustering,
            'dbscan': DBSCAN,
            'chinese_whispers': self.chinese_whispers_clustering
        }
        self.best_model = None
        self.best_distance = None
        self.best_distance_params = {}
        self.best_algorithm = None
        self.best_algo_params = {}
        self.cluster_centers = None
        self.outlier_threshold = None
        self.labels_ = None
        self.distance_matrix_cache = {}

    def compute_distance_matrix(self, X: np.ndarray, distance: str, distance_params: dict, n_jobs: int = -1) -> np.ndarray:
        start_time = time.time()
        print(f"[{time.strftime('%H:%M:%S')}] Computing distance matrix using '{distance}' distance...")
        metric = self.distance_metrics[distance]
        if distance == 'dtw':
            distances = cdist_dtw(X, X, n_jobs=n_jobs, **distance_params)
        elif distance == 'softdtw':
            distances = cdist_soft_dtw(X, X, gamma=distance_params.get('gamma', 1.0))
        elif distance == 'euclidean':
            X_flat = X.reshape((len(X), -1))
            distances = pairwise_distances(X_flat, metric='euclidean', n_jobs=n_jobs)
        elif callable(metric):
            distances = self.cdist_aeon_metric(X, metric, n_jobs=n_jobs, **distance_params)
        else:
            raise ValueError(f"Unsupported distance metric: {distance}")
        end_time = time.time()
        print(f"[{time.strftime('%H:%M:%S')}] Distance matrix computed in {end_time - start_time:.2f} seconds.")
        return distances

    def cdist_aeon_metric(self, X, metric_func, n_jobs=-1, **metric_params):
        n_samples = len(X)
        distances = np.zeros((n_samples, n_samples))

        def compute_row(i):
            return [metric_func(X[i], X[j], **metric_params) for j in range(n_samples)]

        start_time = time.time()
        print(f"[{time.strftime('%H:%M:%S')}] Computing distance matrix with aeon metric '{metric_func.__name__}'...")
        results = Parallel(n_jobs=n_jobs)(
            delayed(compute_row)(i) for i in range(n_samples)
        )
        distances = np.array(results)
        end_time = time.time()
        print(f"[{time.strftime('%H:%M:%S')}] Aeon distance matrix computed in {end_time - start_time:.2f} seconds.")
        return distances

    def chinese_whispers_clustering(self, distance_matrix: np.ndarray, iterations: int = 20):
        start_time = time.time()
        print(f"[{time.strftime('%H:%M:%S')}] Performing Chinese Whispers clustering...")
        n_samples = distance_matrix.shape[0]
        # Convert distances to similarities
        sigma = np.std(distance_matrix)
        similarity_matrix = np.exp(-distance_matrix ** 2 / (2 * sigma ** 2))

        G = nx.Graph()
        for i in range(n_samples):
            for j in range(i + 1, n_samples):
                weight = similarity_matrix[i, j]
                if weight > 0:
                    G.add_edge(i, j, weight=weight)

        # Initialize labels
        for node in G.nodes():
            G.nodes[node]['label'] = node

        for _ in range(iterations):
            nodes = list(G.nodes())
            np.random.shuffle(nodes)
            for node in nodes:
                labels = [G.nodes[neighbor]['label'] for neighbor in G.neighbors(node)]
                if labels:
                    most_common_label = max(set(labels), key=labels.count)
                    G.nodes[node]['label'] = most_common_label

        # Extract labels
        labels = np.array([G.nodes[node]['label'] for node in G.nodes()])
        unique_labels = np.unique(labels)
        label_mapping = {label: idx for idx, label in enumerate(unique_labels)}
        labels_mapped = np.array([label_mapping[label] for label in labels])

        end_time = time.time()
        print(f"[{time.strftime('%H:%M:%S')}] Chinese Whispers clustering completed in {end_time - start_time:.2f} seconds.")
        return labels_mapped

    def fit(self, X: np.ndarray, distance: str = None, distance_params: dict = None, algorithm: str = None, algo_params: dict = None):
        start_time_total = time.time()
        if distance is not None:
            self.best_distance = distance
        if distance_params is not None:
            self.best_distance_params = distance_params
        if algorithm is not None:
            self.best_algorithm = algorithm
        if algo_params is not None:
            self.best_algo_params = algo_params

        distance = self.best_distance
        distance_params = self.best_distance_params
        algorithm = self.best_algorithm
        algo_params = self.best_algo_params

        print(f"[{time.strftime('%H:%M:%S')}] Starting fit with algorithm '{algorithm}' and distance '{distance}'.")

        # Compute or retrieve the distance matrix
        distance_key = (distance, tuple(sorted(distance_params.items())))
        if distance_key in self.distance_matrix_cache:
            distance_matrix = self.distance_matrix_cache[distance_key]
            print(f"[{time.strftime('%H:%M:%S')}] Retrieved cached distance matrix.")
        else:
            distance_matrix = self.compute_distance_matrix(X, distance, distance_params)
            self.distance_matrix_cache[distance_key] = distance_matrix

        print(f"[{time.strftime('%H:%M:%S')}] Fitting {algorithm} clustering...")
        start_time = time.time()
        if algorithm == 'kmeans':
            tslearn_algo = self.clustering_algorithms[algorithm]
            valid_algo_params = {k: algo_params[k] for k in algo_params if k in ['n_clusters', 'random_state']}
            self.best_model = tslearn_algo(
                metric=distance,
                metric_params=distance_params if distance != 'euclidean' else None,
                n_jobs=-1,
                **valid_algo_params
            )
            self.best_model.fit(X)
            self.labels_ = self.best_model.labels_
            self.cluster_centers = self.best_model.cluster_centers_
        elif algorithm == 'kmedoids':
            valid_algo_params = {k: algo_params[k] for k in algo_params if k in ['n_clusters', 'random_state']}
            self.best_model = TimeSeriesKMedoids(
                n_clusters=valid_algo_params.get('n_clusters', 3),
                metric=self.distance_metrics[distance],
                distance_params=distance_params,
                init_algorithm='random',
                max_iter=100,
                random_state=valid_algo_params.get('random_state', 42),
            )
            self.best_model.fit(X)
            self.labels_ = self.best_model.labels_
            self.cluster_centers = self.best_model.cluster_centers_
        elif algorithm == 'agglomerative':
            valid_algo_params = {k: algo_params[k] for k in algo_params if k in ['n_clusters', 'linkage']}
            self.best_model = AgglomerativeClustering(
                affinity='precomputed',
                compute_full_tree=True,
                **valid_algo_params
            )
            self.best_model.fit(distance_matrix)
            self.labels_ = self.best_model.labels_
            unique_labels = np.unique(self.labels_)
            # Compute cluster centers as medoids
            self.cluster_centers = np.array([
                X[self.labels_ == label][
                    np.argmin(distance_matrix[np.ix_(self.labels_ == label, self.labels_ == label)].sum(axis=1))
                ] for label in unique_labels
            ])
        elif algorithm == 'dbscan':
            valid_algo_params = {k: algo_params[k] for k in algo_params if k in ['eps', 'min_samples']}
            self.best_model = DBSCAN(
                metric='precomputed',
                n_jobs=-1,
                **valid_algo_params
            )
            self.best_model.fit(distance_matrix)
            self.labels_ = self.best_model.labels_
            unique_labels = np.unique(self.labels_)
            # Compute cluster centers as medoids
            self.cluster_centers = np.array([
                X[self.labels_ == label][
                    np.argmin(distance_matrix[np.ix_(self.labels_ == label, self.labels_ == label)].sum(axis=1))
                ] for label in unique_labels if label != -1
            ])
        elif algorithm == 'chinese_whispers':
            iterations = algo_params.get('iterations', 20)
            self.labels_ = self.chinese_whispers_clustering(distance_matrix, iterations)
            unique_labels = np.unique(self.labels_)
            # Compute cluster centers as medoids
            self.cluster_centers = np.array([
                X[self.labels_ == label][
                    np.argmin(distance_matrix[np.ix_(self.labels_ == label, self.labels_ == label)].sum(axis=1))
                ] for label in unique_labels
            ])
        else:
            raise ValueError(f"Unsupported clustering algorithm: {algorithm}")
        end_time = time.time()
        print(f"[{time.strftime('%H:%M:%S')}] Model fitted in {end_time - start_time:.2f} seconds.")

        # Calculate outlier threshold using IQR
        if self.cluster_centers is not None and len(self.cluster_centers) > 0:
            distances_to_centers = np.min(
                [self.compute_distance_matrix(X, self.best_distance, self.best_distance_params, n_jobs=-1)[:, i]
                 for i in range(len(self.cluster_centers))], axis=0)
            q1, q3 = np.percentile(distances_to_centers, [25, 75])
            iqr = q3 - q1
            self.outlier_threshold = q3 + 1.5 * iqr
            print(f"[{time.strftime('%H:%M:%S')}] Outlier threshold calculated: {self.outlier_threshold:.4f}")
        total_time = time.time() - start_time_total
        print(f"[{time.strftime('%H:%M:%S')}] Total fitting time: {total_time:.2f} seconds.")

    def predict(self, X: np.ndarray) -> np.ndarray:
        if self.best_model is None or self.cluster_centers is None:
            raise ValueError("Model is not fitted yet. Call 'fit' before using this method.")

        print(f"[{time.strftime('%H:%M:%S')}] Predicting labels for new data...")
        start_time = time.time()
        if self.best_algorithm in ['kmeans', 'kmedoids']:
            labels = self.best_model.predict(X)
        else:
            distances_to_centers = np.array([
                self.compute_distance_matrix(X, self.best_distance, self.best_distance_params, n_jobs=-1)[:, idx]
                for idx in range(len(self.cluster_centers))
            ]).T
            labels = distances_to_centers.argmin(axis=1)

        # Detect outliers
        min_distances = distances_to_centers.min(axis=1)
        outliers = min_distances > self.outlier_threshold
        labels[outliers] = -1
        end_time = time.time()
        print(f"[{time.strftime('%H:%M:%S')}] Prediction completed in {end_time - start_time:.2f} seconds.")
        return labels

    def save_model(self, filepath: str):
        with open(filepath, 'wb') as f:
            pickle.dump(self, f)
        print(f"[{time.strftime('%H:%M:%S')}] Model saved to '{filepath}'.")

    @staticmethod
    def load_model(filepath: str):
        with open(filepath, 'rb') as f:
            model = pickle.load(f)
        print(f"[{time.strftime('%H:%M:%S')}] Model loaded from '{filepath}'.")
        return model

import numpy as np
from tslearn.preprocessing import TimeSeriesScalerMeanVariance
import matplotlib.pyplot as plt
import time

# Assume TimeSeriesClusterPredictor class is already defined and imported

# -------------------------------
# Step 1: Data Preparation
# -------------------------------

def generate_synthetic_data(n_series=150, series_length=60, n_clusters=3, random_state=42):
    np.random.seed(random_state)
    X = []
    for i in range(n_clusters):
        center = np.sin(np.linspace(0, 2 * np.pi, series_length) + np.random.rand())
        for _ in range(n_series // n_clusters):
            noise = np.random.normal(scale=0.1, size=series_length)
            ts = center + noise
            X.append(ts)
    X = np.array(X)
    return X

print(f"[{time.strftime('%H:%M:%S')}] Generating synthetic data...")
X = generate_synthetic_data(n_series=150, series_length=60, n_clusters=3)
print(f"[{time.strftime('%H:%M:%S')}] Data generation completed.")

print(f"[{time.strftime('%H:%M:%S')}] Scaling time series data...")
scaler = TimeSeriesScalerMeanVariance()
X_scaled = scaler.fit_transform(X)
print(f"[{time.strftime('%H:%M:%S')}] Data scaling completed.")

# -------------------------------
# Step 2: Parameter Grid Definition
# -------------------------------

# Define valid parameters for each algorithm and distance
param_grid = []

# Define distances and their valid parameters
distance_params_dict = {
    'dtw': ['window'],
    'softdtw': ['gamma'],
    'euclidean': [],
    'lcss': ['epsilon', 'window'],
    'erp': ['epsilon']
}

# Define algorithms and their valid parameters
algorithm_params_dict = {
    'kmeans': ['n_clusters', 'random_state'],
    'kmedoids': ['n_clusters', 'random_state'],
    'agglomerative': ['n_clusters', 'linkage'],
    'dbscan': ['eps', 'min_samples'],
    'chinese_whispers': ['iterations']
}

# Define parameter values
distance_values = ['dtw', 'euclidean', 'softdtw', 'lcss', 'erp']
algorithm_values = ['kmeans', 'kmedoids', 'agglomerative', 'dbscan', 'chinese_whispers']

for distance in distance_values:
    for algorithm in algorithm_values:
        params = {
            'distance': distance,
            'algorithm': algorithm,
            'n_clusters': 3,
            'random_state': 42,
            'linkage': 'average',
            'eps': 0.5,
            'min_samples': 5,
            'iterations': 10,
            'gamma': 1.0,
            'window': 5,
            'epsilon': 0.5
        }

        # Keep only valid distance parameters
        valid_distance_params = {k: params[k] for k in distance_params_dict[distance]}
        params['distance_params'] = valid_distance_params

        # Keep only valid algorithm parameters
        valid_algo_params = {k: params[k] for k in algorithm_params_dict[algorithm]}
        params['algo_params'] = valid_algo_params

        param_grid.append(params)

# -------------------------------
# Step 3: Model Initialization
# -------------------------------

print(f"[{time.strftime('%H:%M:%S')}] Initializing TimeSeriesClusterPredictor...")
clusterer = TimeSeriesClusterPredictor()
print(f"[{time.strftime('%H:%M:%S')}] Initialization completed.")

# -------------------------------
# Step 4: Finding the Best Parameters
# -------------------------------

print(f"[{time.strftime('%H:%M:%S')}] Starting parameter search...")
start_time = time.time()
best_score = -np.inf
best_params = None  # Initialize best_params

for params in param_grid:
    try:
        distance = params['distance']
        algorithm = params['algorithm']
        distance_params = params['distance_params']
        algo_params = params['algo_params']

        clusterer.fit(X_scaled, distance=distance, distance_params=distance_params, algorithm=algorithm, algo_params=algo_params)
        labels = clusterer.predict(X_scaled)

        if len(np.unique(labels)) < 2:
            continue

        X_flat = X_scaled.reshape((len(X_scaled), -1))
        silhouette = silhouette_score(X_flat, labels, metric='euclidean')
        db_score = davies_bouldin_score(X_flat, labels)
        ch_score = calinski_harabasz_score(X_flat, labels)

        clustering_score = silhouette - db_score + ch_score  # Simplified scoring

        if clustering_score > best_score:
            best_score = clustering_score
            best_params = params.copy()
            best_labels = labels.copy()
            print(f"[{time.strftime('%H:%M:%S')}] New best score: {best_score:.4f} with params: {best_params}")
    except Exception as e:
        print(f"[{time.strftime('%H:%M:%S')}] Error with params {params}: {e}")

end_time = time.time()
print(f"[{time.strftime('%H:%M:%S')}] Parameter search completed in {end_time - start_time:.2f} seconds.")

# Check if best_params is defined
if best_params is None:
    raise ValueError("No valid clustering parameters were found during the parameter search.")

# Set the clusterer to the best parameters
clusterer.fit(
    X_scaled,
    distance=best_params['distance'],
    distance_params=best_params['distance_params'],
    algorithm=best_params['algorithm'],
    algo_params=best_params['algo_params']
)

# -------------------------------
# Step 5: Predicting and Evaluating
# -------------------------------

print(f"[{time.strftime('%H:%M:%S')}] Predicting cluster labels...")
labels = clusterer.predict(X_scaled)
print(f"[{time.strftime('%H:%M:%S')}] Prediction completed.")

print(f"[{time.strftime('%H:%M:%S')}] Evaluating clustering performance...")
X_flat = X_scaled.reshape((len(X_scaled), -1))
sil_score = silhouette_score(X_flat, labels, metric='euclidean')
print(f"[{time.strftime('%H:%M:%S')}] Silhouette Score of the clustering: {sil_score:.4f}")

# -------------------------------
# Step 6: Visualizing the Clusters
# -------------------------------

print(f"[{time.strftime('%H:%M:%S')}] Visualizing the clusters...")
plt.figure(figsize=(12, 8))
unique_labels = np.unique(labels)
colors = plt.cm.get_cmap('tab10', len(unique_labels))

for k in unique_labels:
    class_member_mask = (labels == k)
    xy = X_scaled[class_member_mask]
    for ts in xy:
        plt.plot(ts.ravel(), color=colors(k), alpha=0.5)
    plt.title(f"Cluster {k}" if k != -1 else "Outliers")
    plt.xlabel("Time")
    plt.ylabel("Value")
    plt.show()
print(f"[{time.strftime('%H:%M:%S')}] Visualization completed.")

# -------------------------------
# Step 7: Saving the Model
# -------------------------------

print(f"[{time.strftime('%H:%M:%S')}] Saving the model...")
clusterer.save_model('best_time_series_clusterer.pkl')

# -------------------------------
# Step 8: Loading the Model
# -------------------------------

print(f"[{time.strftime('%H:%M:%S')}] Loading the model...")
loaded_clusterer = TimeSeriesClusterPredictor.load_model('best_time_series_clusterer.pkl')

print(f"[{time.strftime('%H:%M:%S')}] Predicting with the loaded model...")
loaded_labels = loaded_clusterer.predict(X_scaled)
print(f"[{time.strftime('%H:%M:%S')}] Prediction completed.")

print(f"[{time.strftime('%H:%M:%S')}] Verifying that predictions match...")
match = np.array_equal(labels, loaded_labels)
print(f"[{time.strftime('%H:%M:%S')}] Predictions match: {match}")
