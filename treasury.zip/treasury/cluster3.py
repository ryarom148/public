import numpy as np
import time
import matplotlib.pyplot as plt
from tslearn.preprocessing import TimeSeriesScalerMeanVariance
from tslearn.clustering import TimeSeriesKMeans
from tslearn.metrics import cdist_dtw, cdist_soft_dtw
from sklearn.metrics import (
    pairwise_distances, silhouette_score, davies_bouldin_score, calinski_harabasz_score
)
from aeon.distances import (
    dtw_distance, lcss_distance, erp_distance, edr_distance,
    msm_distance, twe_distance
)
from aeon.clustering import TimeSeriesKMedoids
from sklearn.cluster import AgglomerativeClustering, DBSCAN, AffinityPropagation
from sklearn.base import BaseEstimator, ClusterMixin
from joblib import Parallel, delayed
import warnings
import networkx as nx
import pickle
from sklearn.metrics import make_scorer
from sklearn.experimental import enable_halving_search_cv
from sklearn.model_selection import GridSearchCV, HalvingGridSearchCV
from sklearn.experimental import enable_halving_search_cv


# Chinese Whispers library
from chinese_whispers import chinese_whispers, aggregate_clusters

warnings.filterwarnings('ignore')

class TimeSeriesClusterPredictor(BaseEstimator, ClusterMixin):
    def __init__(self,
                 distance='dtw',
                 distance_params=None,
                 algorithm='kmeans',
                 algo_params=None):
        self.distance = distance
        self.distance_params = distance_params if distance_params is not None else {}
        self.algorithm = algorithm
        self.algo_params = algo_params if algo_params is not None else {}
        self.distance_metrics = {
            'dtw': 'dtw',            # tslearn metric
            'softdtw': 'softdtw',    # tslearn metric
            'euclidean': 'euclidean',# tslearn metric
            # aeon metrics
            'lcss': lcss_distance,
            'erp': erp_distance,
            'edr': edr_distance,
            'msm': msm_distance,
            'twe': twe_distance,
        }
        self.distance_params_allowed = {
            'dtw': ['window'],
            'softdtw': ['gamma'],
            'lcss': ['epsilon', 'window'],
            'erp': ['g'],
            'edr': ['epsilon'],
            'msm': ['c'],
            'twe': ['lambda_', 'nu']
        }
        self.clustering_algorithms = {
            'kmeans': TimeSeriesKMeans,
            'kmedoids': TimeSeriesKMedoids,
            'agglomerative': AgglomerativeClustering,
            'dbscan': DBSCAN,
            'affinity_propagation': AffinityPropagation,
            'chinese_whispers': self.chinese_whispers_clustering
        }
        self.algorithm_params_allowed = {
            'kmeans': ['n_clusters', 'random_state', 'max_iter', 'tol', 'n_init', 'metric_params', 'max_iter_barycenter', 'verbose', 'init'],
            'kmedoids': ['n_clusters', 'random_state', 'init_algorithm', 'max_iter', 'method', 'distance_params', 'verbose'],
            'agglomerative': ['n_clusters', 'linkage', 'distance_threshold'],
            'dbscan': ['eps', 'min_samples', 'metric', 'algorithm', 'leaf_size', 'p', 'n_jobs'],
            'affinity_propagation': ['damping', 'max_iter', 'convergence_iter', 'preference', 'affinity', 'verbose'],
            'chinese_whispers': ['iterations', 'weighting', 'seed']
        }
        self.best_model = None
        self.cluster_centers = None
        self.outlier_threshold = None
        self.labels_ = None
        self.distance_matrix_cache = {}
        self.best_score = None
        self.evaluation_metrics = {}
        self.X_ = None  # Store the data during fit
        self.G = None   # Store the graph for Chinese Whispers visualization

    def compute_distance_matrix(self, X: np.ndarray, n_jobs: int = -1) -> np.ndarray:
        start_time = time.time()
        distance = self.distance
        distance_params = self.distance_params
        print(f"[{time.strftime('%H:%M:%S')}] Computing distance matrix using '{distance}' distance...")
        metric = self.distance_metrics[distance]
        if distance in ['dtw', 'softdtw', 'euclidean']:
            # tslearn metrics
            if distance == 'dtw':
                distances = cdist_dtw(X, n_jobs=n_jobs, **distance_params)
            elif distance == 'softdtw':
                distances = cdist_soft_dtw(X, gamma=distance_params.get('gamma', 1.0))
            elif distance == 'euclidean':
                X_flat = X.reshape((len(X), -1))
                distances = pairwise_distances(X_flat, metric='euclidean', n_jobs=n_jobs)
        elif callable(metric):
            distances = self.cdist_aeon_metric(X, metric, n_jobs=n_jobs, **distance_params)
        else:
            raise ValueError(f"Unsupported distance metric: {distance}")
        end_time = time.time()
        print(f"[{time.strftime('%H:%M:%S')}] Distance matrix computed in {end_time - start_time:.2f} seconds.")
        return distances

    def cdist_aeon_metric(self, X, metric_func, n_jobs=-1, **metric_params):
        n_samples = len(X)
        distances = np.zeros((n_samples, n_samples))

        def compute_upper_triangle(i):
            dist_row = np.zeros(n_samples)
            for j in range(i + 1, n_samples):
                dist = metric_func(X[i].ravel(), X[j].ravel(), **metric_params)
                dist_row[j] = dist
            return dist_row

        start_time = time.time()
        print(f"[{time.strftime('%H:%M:%S')}] Computing distance matrix with aeon metric '{metric_func.__name__}'...")
        results = Parallel(n_jobs=n_jobs)(
            delayed(compute_upper_triangle)(i) for i in range(n_samples)
        )
        for i, row in enumerate(results):
            distances[i, :] = row
        distances = distances + distances.T
        end_time = time.time()
        print(f"[{time.strftime('%H:%M:%S')}] Aeon distance matrix computed in {end_time - start_time:.2f} seconds.")
        return distances

    def chinese_whispers_clustering(self, X, distance_matrix: np.ndarray, iterations: int = 20, weighting='weighted', seed=None):
        start_time = time.time()
        print(f"[{time.strftime('%H:%M:%S')}] Performing Chinese Whispers clustering...")
        n_samples = distance_matrix.shape[0]
        # Convert distances to similarities
        sigma = np.std(distance_matrix)
        similarity_matrix = np.exp(-distance_matrix ** 2 / (2 * sigma ** 2))

        # Build graph
        G = nx.Graph()
        for i in range(n_samples):
            for j in range(i + 1, n_samples):
                weight = similarity_matrix[i, j]
                if weight > 0:
                    G.add_edge(i, j, weight=weight)

        # Apply Chinese Whispers clustering using the library
        chinese_whispers(G, weighting=weighting, iterations=iterations, seed=seed)
        self.G = G  # Store the graph for visualization

        # Extract labels
        labels = np.array([G.nodes[node]['label'] for node in G.nodes()])
        unique_labels = np.unique(labels)
        label_mapping = {label: idx for idx, label in enumerate(unique_labels)}
        labels_mapped = np.array([label_mapping[label] for label in labels])

        # Compute cluster centers as medoids
        self.cluster_centers = np.array([
            X[labels_mapped == label][
                np.argmin(distance_matrix[np.ix_(labels_mapped == label, labels_mapped == label)].sum(axis=1))
            ] for label in unique_labels
        ])

        end_time = time.time()
        print(f"[{time.strftime('%H:%M:%S')}] Chinese Whispers clustering completed in {end_time - start_time:.2f} seconds.")
        return labels_mapped

    def fit(self, X, y=None):
        self.X_ = X
        X = np.array(X)
        start_time_total = time.time()
        distance = self.distance
        distance_params = self.distance_params
        algorithm = self.algorithm
        algo_params = self.algo_params

        print(f"[{time.strftime('%H:%M:%S')}] Starting fit with algorithm '{algorithm}' and distance '{distance}'.")

        # Compute or retrieve the distance matrix
        distance_key = (distance, tuple(sorted(distance_params.items())))
        if distance_key in self.distance_matrix_cache:
            distance_matrix = self.distance_matrix_cache[distance_key]
            print(f"[{time.strftime('%H:%M:%S')}] Retrieved cached distance matrix.")
        else:
            distance_matrix = self.compute_distance_matrix(X)
            self.distance_matrix_cache[distance_key] = distance_matrix

        print(f"[{time.strftime('%H:%M:%S')}] Fitting {algorithm} clustering...")
        start_time = time.time()
        if algorithm == 'kmeans':
            if distance in ['dtw', 'softdtw', 'euclidean']:
                tslearn_algo = self.clustering_algorithms[algorithm]
                valid_algo_params = {k: algo_params.get(k) for k in self.algorithm_params_allowed[algorithm] if k in algo_params}
                metric_params = distance_params if distance_params else None
                self.best_model = tslearn_algo(
                    metric=distance,
                    metric_params=metric_params,
                    n_jobs=-1,
                    **valid_algo_params
                )
                self.best_model.fit(X)
                self.labels_ = self.best_model.labels_
                self.cluster_centers = self.best_model.cluster_centers_
            else:
                raise ValueError(f"Incorrect metric: {distance} (should be one of 'dtw', 'softdtw', 'euclidean')")
        elif algorithm == 'kmedoids':
            valid_algo_params = {k: algo_params.get(k) for k in self.algorithm_params_allowed[algorithm] if k in algo_params}
            distance_params = distance_params if distance_params else {}
            self.best_model = TimeSeriesKMedoids(
                n_clusters=valid_algo_params.get('n_clusters', 3),
                init_algorithm=valid_algo_params.get('init_algorithm', 'random'),
                distance=self.distance_metrics[distance],
                method=valid_algo_params.get('method', 'pam'),
                max_iter=valid_algo_params.get('max_iter', 300),
                random_state=valid_algo_params.get('random_state', None),
                distance_params=distance_params,
                verbose=valid_algo_params.get('verbose', False)
            )
            self.best_model.fit(X)
            self.labels_ = self.best_model.labels_
            self.cluster_centers = self.best_model.cluster_centers_
        elif algorithm == 'agglomerative':
            valid_algo_params = {k: algo_params.get(k) for k in self.algorithm_params_allowed[algorithm] if k in algo_params}
            self.best_model = AgglomerativeClustering(
                affinity='precomputed',
                linkage=valid_algo_params.get('linkage', 'average'),
                n_clusters=valid_algo_params.get('n_clusters', None),
                distance_threshold=valid_algo_params.get('distance_threshold', None)
            )
            self.best_model.fit(distance_matrix)
            self.labels_ = self.best_model.labels_
            unique_labels = np.unique(self.labels_)
            # Compute cluster centers as medoids
            self.cluster_centers = np.array([
                X[self.labels_ == label][
                    np.argmin(distance_matrix[np.ix_(self.labels_ == label, self.labels_ == label)].sum(axis=1))
                ] for label in unique_labels
            ])
        elif algorithm == 'dbscan':
            valid_algo_params = {k: algo_params.get(k) for k in self.algorithm_params_allowed[algorithm] if k in algo_params}
            self.best_model = DBSCAN(
                metric='precomputed',
                n_jobs=-1,
                **valid_algo_params
            )
            self.best_model.fit(distance_matrix)
            self.labels_ = self.best_model.labels_
            unique_labels = np.unique(self.labels_)
            # Exclude noise points (-1)
            unique_labels = unique_labels[unique_labels != -1]
            # Compute cluster centers as medoids
            if len(unique_labels) > 0:
                self.cluster_centers = np.array([
                    X[self.labels_ == label][
                        np.argmin(distance_matrix[np.ix_(self.labels_ == label, self.labels_ == label)].sum(axis=1))
                    ] for label in unique_labels
                ])
            else:
                self.cluster_centers = None
        elif algorithm == 'affinity_propagation':
            # Affinity Propagation requires a similarity matrix
            # Using negative distances as similarities
            similarity_matrix = -distance_matrix
            valid_algo_params = {k: algo_params.get(k) for k in self.algorithm_params_allowed[algorithm] if k in algo_params}
            self.best_model = AffinityPropagation(
                affinity='precomputed',
                **valid_algo_params
            )
            self.best_model.fit(similarity_matrix)
            self.labels_ = self.best_model.labels_
            cluster_centers_indices = self.best_model.cluster_centers_indices_
            self.cluster_centers = X[cluster_centers_indices]
        elif algorithm == 'chinese_whispers':
            iterations = algo_params.get('iterations', 20)
            weighting = algo_params.get('weighting', 'weighted')
            seed = algo_params.get('seed', None)
            self.labels_ = self.chinese_whispers_clustering(X, distance_matrix, iterations, weighting, seed)
        else:
            raise ValueError(f"Unsupported clustering algorithm: {algorithm}")
        end_time = time.time()
        print(f"[{time.strftime('%H:%M:%S')}] Model fitted in {end_time - start_time:.2f} seconds.")

        # Calculate outlier threshold using IQR
        if self.cluster_centers is not None and len(self.cluster_centers) > 0:
            distances_to_centers = self.compute_distances_to_centers(X)
            min_distances = distances_to_centers.min(axis=1)
            q1, q3 = np.percentile(min_distances, [25, 75])
            iqr = q3 - q1
            self.outlier_threshold = q3 + 1.5 * iqr
            print(f"[{time.strftime('%H:%M:%S')}] Outlier threshold calculated: {self.outlier_threshold:.4f}")
        total_time = time.time() - start_time_total
        print(f"[{time.strftime('%H:%M:%S')}] Total fitting time: {total_time:.2f} seconds.")
        return self  # Return self as per scikit-learn convention

    def compute_distances_to_centers(self, X):
        distances = np.array([
            [self.distance_metrics[self.distance](X[i].ravel(), self.cluster_centers[idx].ravel(), **self.distance_params)
             for idx in range(len(self.cluster_centers))]
            for i in range(len(X))
        ])
        return distances

    def compute_similarities_to_centers(self, X):
        # Consistent with the similarity measure used in 'fit'
        distances = self.compute_distances_to_centers(X)
        similarities = -distances  # Assuming negative distances as similarities
        return similarities

    def predict(self, X):
        if self.best_model is None:
            raise ValueError("Model is not fitted yet. Call 'fit' before using this method.")

        print(f"[{time.strftime('%H:%M:%S')}] Predicting labels for new data using algorithm '{self.algorithm}'...")
        start_time = time.time()

        if self.algorithm == 'kmeans':
            labels = self.best_model.predict(X)
        elif self.algorithm == 'kmedoids':
            distances_to_centers = self.compute_distances_to_centers(X)
            labels = distances_to_centers.argmin(axis=1)
        elif self.algorithm == 'affinity_propagation':
            similarities_to_centers = self.compute_similarities_to_centers(X)
            labels = similarities_to_centers.argmax(axis=1)
        elif self.algorithm == 'agglomerative':
            distances_to_centers = self.compute_distances_to_centers(X)
            labels = distances_to_centers.argmin(axis=1)
        elif self.algorithm == 'dbscan':
            # Assign new data points to the nearest core point's cluster
            # Note: This is an approximation since DBSCAN doesn't natively support prediction
            if hasattr(self.best_model, 'core_sample_indices_'):
                core_sample_indices = self.best_model.core_sample_indices_
                core_samples = self.X_[core_sample_indices]
                core_labels = self.labels_[core_sample_indices]
                distances = np.array([
                    [self.distance_metrics[self.distance](X[i].ravel(), core_samples[j].ravel(), **self.distance_params)
                     for j in range(len(core_samples))]
                    for i in range(len(X))
                ])
                nearest_core_indices = distances.argmin(axis=1)
                labels = core_labels[nearest_core_indices]
                # Mark as noise if distance is greater than eps
                min_distances = distances.min(axis=1)
                eps = self.best_model.eps
                labels[min_distances > eps] = -1
            else:
                # If no core samples, mark all as noise
                labels = np.full(len(X), -1)
        elif self.algorithm == 'chinese_whispers':
            # Since Chinese Whispers operates on graphs, we need to assign labels based on similarity to existing nodes
            # This is an approximation
            if self.G is not None:
                existing_nodes = list(self.G.nodes())
                existing_embeddings = self.X_[existing_nodes]
                distances = np.array([
                    [self.distance_metrics[self.distance](X[i].ravel(), existing_embeddings[j].ravel(), **self.distance_params)
                     for j in range(len(existing_embeddings))]
                    for i in range(len(X))
                ])
                nearest_indices = distances.argmin(axis=1)
                labels = np.array([self.G.nodes[existing_nodes[idx]]['label'] for idx in nearest_indices])
                # Map labels to consistent indices
                unique_labels = np.unique(labels)
                label_mapping = {label: idx for idx, label in enumerate(unique_labels)}
                labels = np.array([label_mapping[label] for label in labels])
            else:
                raise ValueError("Graph G is not available for prediction.")
        else:
            raise ValueError(f"Unsupported algorithm: {self.algorithm}")

        # Detect outliers if threshold is defined
        if hasattr(self, 'outlier_threshold') and self.outlier_threshold is not None:
            min_distances = self.compute_distances_to_centers(X).min(axis=1)
            outliers = min_distances > self.outlier_threshold
            labels[outliers] = -1

        end_time = time.time()
        print(f"[{time.strftime('%H:%M:%S')}] Prediction completed in {end_time - start_time:.2f} seconds.")
        return labels

    def fit_predict(self, X, y=None):
        self.fit(X)
        return self.labels_

    def save_model(self, filepath: str):
        with open(filepath, 'wb') as f:
            pickle.dump(self, f)
        print(f"[{time.strftime('%H:%M:%S')}] Model saved to '{filepath}'.")

    @staticmethod
    def load_model(filepath: str):
        with open(filepath, 'rb') as f:
            model = pickle.load(f)
        print(f"[{time.strftime('%H:%M:%S')}] Model loaded from '{filepath}'.")
        return model

    def plot_clusters(self, X):
        unique_labels = np.unique(self.labels_)
        n_clusters = len(unique_labels)

        if self.algorithm == 'chinese_whispers':
            # Visualization for Chinese Whispers using networkx
            if self.G is None:
                print("Graph G is not available for visualization.")
                return

            plt.figure(figsize=(12, 8))
            colors = [1. / self.G.nodes[node]["label"] for node in self.G.nodes()]
            nx.draw_networkx(self.G, cmap=plt.get_cmap("jet"), node_color=colors, font_color="white")
            plt.title("Chinese Whispers Clustering")
            plt.show()
        else:
            # Plot clusters as per the original specification
            fig, axes = plt.subplots(n_clusters, 5, figsize=(20, 4 * n_clusters))
            if n_clusters == 1:
                axes = [axes]

            for idx, label in enumerate(unique_labels):
                cluster_indices = np.where(self.labels_ == label)[0]
                if len(cluster_indices) == 0:
                    continue
                cluster_center = self.cluster_centers[idx]
                sample_indices = np.random.choice(cluster_indices, min(20, len(cluster_indices)), replace=False)
                samples = X[cluster_indices]

                # First column: cluster center overlaid with 20 time series in the cluster
                ax = axes[idx][0]
                for ts in samples[:20]:
                    ax.plot(ts.ravel(), color='blue', alpha=0.3)
                ax.plot(cluster_center.ravel(), color='red', linewidth=2)
                ax.set_title(f'Cluster {label}: Center with 20 Time Series')

                # Next 4 columns: random time series from the cluster
                for i in range(1, 5):
                    if i - 1 < len(samples):
                        ax = axes[idx][i]
                        ax.plot(samples[i - 1].ravel(), color='blue')
                        ax.set_title(f'Cluster {label}: Sample {i}')
                    else:
                        axes[idx][i].axis('off')
            plt.tight_layout()
            plt.show()

    def find_best_params(self, X, param_grid, scoring='silhouette'):
        print(f"[{time.strftime('%H:%M:%S')}] Starting parameter search...")

        def clustering_scorer(estimator, X):
            labels = estimator.fit_predict(X)
            if len(np.unique(labels)) == 1:
                return -1  # Cannot compute score with only one cluster
            X_flat = X.reshape((len(X), -1))
            sil_score = silhouette_score(X_flat, labels, metric='euclidean')
            davies_bouldin = davies_bouldin_score(X_flat, labels)
            calinski_harabasz = calinski_harabasz_score(X_flat, labels)
            # Combine metrics (you can adjust weights as needed)
            score = sil_score - davies_bouldin + calinski_harabasz / 1000
            return score

        # Create a custom scorer
        scorer = make_scorer(clustering_scorer, greater_is_better=True, needs_proba=False, needs_threshold=False)

        # Use GridSearchCV or HalvingGridSearchCV
        grid_search = GridSearchCV(
            estimator=self,
            param_grid=param_grid,
            scoring=scorer,
            n_jobs=-1,
            cv=[(slice(None), slice(None))],  # Use the full dataset as both train and test
            verbose=2
        )

        grid_search.fit(X)

        self.best_params_ = grid_search.best_params_
        self.best_score_ = grid_search.best_score_
        self.best_estimator_ = grid_search.best_estimator_
        self.labels_ = self.best_estimator_.labels_
        self.cluster_centers = self.best_estimator_.cluster_centers

        print(f"[{time.strftime('%H:%M:%S')}] Parameter search completed.")
        print(f"[{time.strftime('%H:%M:%S')}] Best Parameters: {self.best_params_}")
        print(f"[{time.strftime('%H:%M:%S')}] Best Score: {self.best_score_:.4f}")

        return self.best_params_, self.best_score_



import numpy as np
from tslearn.preprocessing import TimeSeriesScalerMeanVariance
from sklearn.pipeline import Pipeline
import time
from itertools import product

# Assume TimeSeriesClusterPredictor class is already defined and imported

# -------------------------------
# Step 1: Data Preparation
# -------------------------------

def generate_synthetic_data(n_series=150, series_length=60, n_clusters=3, random_state=42):
    np.random.seed(random_state)
    X = []
    for i in range(n_clusters):
        center = np.sin(np.linspace(0, 2 * np.pi, series_length) + np.random.rand())
        for _ in range(n_series // n_clusters):
            noise = np.random.normal(scale=0.1, size=series_length)
            ts = center + noise
            X.append(ts)
    X = np.array(X)
    return X

print(f"[{time.strftime('%H:%M:%S')}] Generating synthetic data...")
X = generate_synthetic_data(n_series=150, series_length=60, n_clusters=3)
print(f"[{time.strftime('%H:%M:%S')}] Data generation completed.")

print(f"[{time.strftime('%H:%M:%S')}] Scaling time series data...")
scaler = TimeSeriesScalerMeanVariance()
X_scaled = scaler.fit_transform(X)
print(f"[{time.strftime('%H:%M:%S')}] Data scaling completed.")

# -------------------------------
# Step 2: Parameter Grid Definition
# -------------------------------

param_grid = {
    'distance': ['dtw', 'lcss', 'erp', 'edr', 'msm', 'twe', 'euclidean'],
    'distance_params': [
        {},  # default parameters
        {'window': 10}, {'window': 20},  # for dtw and lcss
        {'epsilon': 0.5}, {'epsilon': 1.0}, {'epsilon': 1.5},  # for lcss, edr
        {'g': 0.0}, {'g': 0.5}, {'g': 1.0},  # for erp
        {'c': 0.5}, {'c': 1.0}, {'c': 1.5},  # for msm
        {'nu': 0.5}, {'nu': 1.0}, {'nu': 1.5},  # for twe
        {'lambda_': 0.5}, {'lambda_': 1.0}, {'lambda_': 1.5},  # for twe
    ],
    'algorithm': ['kmeans', 'kmedoids', 'agglomerative', 'affinity_propagation', 'dbscan', 'chinese_whispers'],
    'algo_params': [
        {},  # default parameters
        {'n_clusters': 3}, {'n_clusters': 5}, {'n_clusters': 7},  # for kmeans, kmedoids, agglomerative
        {'eps': 0.5}, {'eps': 1.0}, {'eps': 1.5},  # for dbscan
        {'min_samples': 5}, {'min_samples': 10}, {'min_samples': 15},  # for dbscan
        {'damping': 0.5}, {'damping': 0.9},  # for affinity_propagation
        {'iterations': 10}, {'iterations': 20},  # for chinese_whispers
    ]
}

# -------------------------------
# Step 3: Creating the Pipeline
# -------------------------------

pipeline = Pipeline([
    ('clusterer', TimeSeriesClusterPredictor())
])

# -------------------------------
# Step 4: Custom Parameter Grid for GridSearchCV
# -------------------------------

param_grid_combined_unique = []

for dist, dist_params, algo, algo_params in product(param_grid['distance'], param_grid['distance_params'], param_grid['algorithm'], param_grid['algo_params']):
    # Filter distance parameters
    allowed_dist_params = {}
    for param in dist_params:
        if param in TimeSeriesClusterPredictor().distance_params_allowed.get(dist, []):
            allowed_dist_params[param] = dist_params[param]
    # Filter algorithm parameters
    allowed_algo_params = {}
    for param in algo_params:
        if param in TimeSeriesClusterPredictor().algorithm_params_allowed.get(algo, []):
            allowed_algo_params[param] = algo_params[param]
    # Create parameter combination
    param_combination = {
        'clusterer__distance': [dist],  # Wrap in list
        'clusterer__distance_params': [allowed_dist_params],  # Wrap in list
        'clusterer__algorithm': [algo],  # Wrap in list
        'clusterer__algo_params': [allowed_algo_params],  # Wrap in list
    }
    # Avoid duplicates
    if param_combination not in param_grid_combined_unique:
        param_grid_combined_unique.append(param_combination)

# -------------------------------
# Step 5: Custom Scoring Function
# -------------------------------

from sklearn.metrics import make_scorer

def clustering_scorer(estimator, X, y_true=None):
    labels = estimator.fit_predict(X)
    if len(np.unique(labels)) == 1:
        return -1  # Cannot compute score with only one cluster
    X_flat = X.reshape((len(X), -1))
    sil_score = silhouette_score(X_flat, labels, metric='euclidean')
    davies_bouldin = davies_bouldin_score(X_flat, labels)
    calinski_harabasz = calinski_harabasz_score(X_flat, labels)
    # Combine metrics (you can adjust weights as needed)
    score = sil_score - davies_bouldin + calinski_harabasz / 1000
    return score

scorer = make_scorer(clustering_scorer, greater_is_better=True)

# -------------------------------
# Step 6: Running GridSearchCV
# -------------------------------

print(f"[{time.strftime('%H:%M:%S')}] Starting Grid Search...")

grid_search = GridSearchCV(
    estimator=pipeline,
    param_grid=param_grid_combined_unique,
    scoring=scorer,
    n_jobs=-1,
    cv=[(slice(None), slice(None))],  # Use the full dataset as both train and test
    verbose=2
)

grid_search.fit(X_scaled)

print(f"[{time.strftime('%H:%M:%S')}] Grid Search completed.")


# -------------------------------
# Step 7: Best Model and Parameters
# -------------------------------

best_params = grid_search.best_params_
best_score = grid_search.best_score_

print(f"[{time.strftime('%H:%M:%S')}] Best Parameters: {best_params}")
print(f"[{time.strftime('%H:%M:%S')}] Best Score: {best_score:.4f}")

# Extract the best model
best_clusterer = grid_search.best_estimator_.named_steps['clusterer']

# -------------------------------
# Step 8: Predicting and Evaluating
# -------------------------------

print(f"[{time.strftime('%H:%M:%S')}] Predicting cluster labels...")
labels = best_clusterer.labels_
print(f"[{time.strftime('%H:%M:%S')}] Prediction completed.")

print(f"[{time.strftime('%H:%M:%S')}] Evaluating clustering performance...")
X_flat = X_scaled.reshape((len(X_scaled), -1))
sil_score = silhouette_score(X_flat, labels, metric='euclidean')
davies_bouldin = davies_bouldin_score(X_flat, labels)
calinski_harabasz = calinski_harabasz_score(X_flat, labels)
print(f"[{time.strftime('%H:%M:%S')}] Silhouette Score: {sil_score:.4f}")
print(f"[{time.strftime('%H:%M:%S')}] Davies-Bouldin Score: {davies_bouldin:.4f}")
print(f"[{time.strftime('%H:%M:%S')}] Calinski-Harabasz Score: {calinski_harabasz:.4f}")

# -------------------------------
# Step 9: Visualizing the Clusters
# -------------------------------

print(f"[{time.strftime('%H:%M:%S')}] Visualizing the clusters...")
best_clusterer.plot_clusters(X_scaled)
print(f"[{time.strftime('%H:%M:%S')}] Visualization completed.")

# -------------------------------
# Step 10: Saving the Model
# -------------------------------

print(f"[{time.strftime('%H:%M:%S')}] Saving the model...")
best_clusterer.save_model('best_time_series_clusterer.pkl')

# -------------------------------
# Step 11: Loading the Model
# -------------------------------

print(f"[{time.strftime('%H:%M:%S')}] Loading the model...")
loaded_clusterer = TimeSeriesClusterPredictor.load_model('best_time_series_clusterer.pkl')

print(f"[{time.strftime('%H:%M:%S')}] Predicting with the loaded model...")
loaded_labels = loaded_clusterer.predict(X_scaled)
print(f"[{time.strftime('%H:%M:%S')}] Prediction completed.")

print(f"[{time.strftime('%H:%M:%S')}] Verifying that predictions match...")
match = np.array_equal(labels, loaded_labels)
print(f"[{time.strftime('%H:%M:%S')}] Predictions match: {match}")
