import pickle
import os

def save_model_locally(model, path):
    """
    Save the model locally.

    Args:
        model: The model to be saved
        path (str): The directory path where the model will be saved
    """
    os.makedirs(path, exist_ok=True)
    file_path = os.path.join(path, 'balance_predictor_model.pkl')
    with open(file_path, 'wb') as f:
        pickle.dump(model, f)
    print(f"Model saved locally to {file_path}")

def load_model_locally(path):
    """
    Load the model from a local file.

    Args:
        path (str): The directory path where the model is saved

    Returns:
        The loaded model
    """
    file_path = os.path.join(path, 'balance_predictor_model.pkl')
    with open(file_path, 'rb') as f:
        model = pickle.load(f)
    print(f"Model loaded from {file_path}")
    return model