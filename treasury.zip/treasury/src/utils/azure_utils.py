from azure.identity import DefaultAzureCredential
from azure.ai.ml import MLClient
from azure.ai.ml.entities import AmlCompute
from azure.mgmt.storage import StorageManagementClient
from azure.storage.blob import BlobServiceClient
from azure.core.exceptions import ResourceNotFoundError
from azure.mgmt.resource import ResourceManagementClient

def init_azure_resources(config):
    """
    Initialize Azure resources (Resource Group, Storage Account, Container, MLClient).
    Create resources if they don't exist.

    Args:
        config (dict): Azure configuration

    Returns:
        tuple: (storage_account_name, container_name, ml_client)
    """
    credential = DefaultAzureCredential()
    
    # Initialize Resource Management Client
    resource_client = ResourceManagementClient(credential, config['subscription_id'])
    
    # Ensure resource group exists
    resource_client.resource_groups.create_or_update(
        config['resource_group'],
        {"location": config['location']}
    )

    # Initialize Storage Management Client
    storage_client = StorageManagementClient(credential, config['subscription_id'])
    
    # Ensure storage account exists
    storage_account_name = config['storage_account_name']
    try:
        storage_client.storage_accounts.get_properties(config['resource_group'], storage_account_name)
    except ResourceNotFoundError:
        storage_client.storage_accounts.begin_create(
            config['resource_group'],
            storage_account_name,
            {
                "location": config['location'],
                "kind": "StorageV2",
                "sku": {"name": "Standard_LRS"}
            }
        ).result()

    # Ensure container exists
    blob_service_client = BlobServiceClient(
        account_url=f"https://{storage_account_name}.blob.core.windows.net",
        credential=credential
    )
    container_name = config['data_container']
    try:
        blob_service_client.get_container_client(container_name).get_container_properties()
    except ResourceNotFoundError:
        blob_service_client.create_container(container_name)

    # Initialize and return MLClient
    ml_client = MLClient(
        credential=credential,
        subscription_id=config['subscription_id'],
        resource_group_name=config['resource_group'],
        workspace_name=config['workspace_name']
    )
    
    return storage_account_name, container_name, ml_client

def setup_compute(ml_client, config):
    """
    Set up compute resources in Azure ML workspace.
    Create compute if it doesn't exist.

    Args:
        ml_client (MLClient): Azure ML client
        config (dict): Compute configuration

    Returns:
        str: Name of the compute target
    """
    compute_name = config['compute_name']
    
    try:
        compute = ml_client.compute.get(compute_name)
        print(f"Using existing compute target: {compute_name}")
    except ResourceNotFoundError:
        print(f"Creating a new compute target: {compute_name}")
        
        compute = AmlCompute(
            name=compute_name,
            size=config['vm_size'],
            min_instances=config['min_instances'],
            max_instances=config['max_instances'],
            idle_time_before_scale_down=config['idle_time_before_scale_down']
        )
        ml_client.compute.begin_create_or_update(compute).result()
    
    return compute_name

def log_metrics(ml_client, run_id, metrics):
    """
    Log metrics to Azure ML workspace.

    Args:
        ml_client (MLClient): Azure ML workspace client
        run_id (str): ID of the current run
        metrics (dict): Dictionary of metrics to log
    """
    try:
        run = ml_client.runs.get(run_id)
        for metric_name, metric_value in metrics.items():
            run.log(metric_name, metric_value)
        print("Metrics logged successfully.")
    except Exception as e:
        print(f"Error logging metrics: {str(e)}")
        raise