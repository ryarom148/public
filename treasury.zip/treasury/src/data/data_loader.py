import pandas as pd
from azure.identity import DefaultAzureCredential
from azure.storage.blob import BlobServiceClient
import os

def load_data(config):
    """
    Load data from local file system or Azure Blob Storage.
    Supports Parquet, Excel, and CSV formats for local files.

    Args:
        config (dict or str): If str, it's the local file path. If dict, it contains Azure configuration.

    Returns:
        pd.DataFrame: Loaded data as a pandas DataFrame
    """
    if isinstance(config, str):
        # Local file loading
        file_extension = os.path.splitext(config)[1].lower()
        
        if file_extension == '.parquet':
            return pd.read_parquet(config)
        elif file_extension in ['.xlsx', '.xls']:
            return pd.read_excel(config)
        elif file_extension == '.csv':
            return pd.read_csv(config)
        else:
            raise ValueError(f"Unsupported file format: {file_extension}")
    else:
        # Azure Blob Storage loading
        credential = DefaultAzureCredential()
        blob_service_client = BlobServiceClient(
            account_url=f"https://{config['storage_account_name']}.blob.core.windows.net",
            credential=credential
        )
        blob_client = blob_service_client.get_blob_client(container=config['data_container'], blob=config['data_blob'])
        download_stream = blob_client.download_blob()
        
        # Determine file format based on blob name
        file_extension = os.path.splitext(config['data_blob'])[1].lower()
        
        if file_extension == '.parquet':
            return pd.read_parquet(download_stream)
        elif file_extension in ['.xlsx', '.xls']:
            return pd.read_excel(download_stream)
        elif file_extension == '.csv':
            return pd.read_csv(download_stream)
        else:
            raise ValueError(f"Unsupported file format: {file_extension}")

def save_data(data, config):
    """
    Save data to local file system or Azure Blob Storage.
    Supports Parquet, Excel, and CSV formats for local files.

    Args:
        data (pd.DataFrame): Data to be saved
        config (dict or str): If str, it's the local file path. If dict, it contains Azure configuration.
    """
    if isinstance(config, str):
        # Local file saving
        file_extension = os.path.splitext(config)[1].lower()
        
        if file_extension == '.parquet':
            data.to_parquet(config, index=False)
        elif file_extension in ['.xlsx', '.xls']:
            data.to_excel(config, index=False)
        elif file_extension == '.csv':
            data.to_csv(config, index=False)
        else:
            raise ValueError(f"Unsupported file format: {file_extension}")
        
        print(f"Data saved locally to {config}")
    else:
        # Azure Blob Storage saving
        credential = DefaultAzureCredential()
        blob_service_client = BlobServiceClient(
            account_url=f"https://{config['storage_account_name']}.blob.core.windows.net",
            credential=credential
        )
        blob_client = blob_service_client.get_blob_client(container=config['data_container'], blob=config['data_blob'])
        
        # Determine file format based on blob name
        file_extension = os.path.splitext(config['data_blob'])[1].lower()
        
        if file_extension == '.parquet':
            blob_client.upload_blob(data.to_parquet(), overwrite=True)
        elif file_extension in ['.xlsx', '.xls']:
            blob_client.upload_blob(data.to_excel(), overwrite=True)
        elif file_extension == '.csv':
            blob_client.upload_blob(data.to_csv(index=False), overwrite=True)
        else:
            raise ValueError(f"Unsupported file format: {file_extension}")
        
        print(f"Data saved to Azure: {config['data_container']}/{config['data_blob']}")