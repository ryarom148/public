import numpy as np
from typing import List, Optional, Dict, Any
from sklearn.base import BaseEstimator, ClusterMixin
from sklearn.utils.validation import check_is_fitted
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import make_scorer, silhouette_score, calinski_harabasz_score, davies_bouldin_score
from joblib import Parallel, delayed
import hashlib
import os
import time
import joblib
import logging
from clustering.customAgglomerativeClustering import CustomAgglomerativeClustering
from clustering.customAffinityPropagation import CustomAffinityPropagation
from clustering.customDBSCAN import CustomDBSCAN
from clustering.customChineseWhispers import CustomChineseWhispers
from clustering.customOptics import CustomOPTICS
# from skopt import BayesSearchCV
# from skopt.space import Real, Integer, Categorical
from functools import partial
from tslearn.metrics import cdist_dtw, cdist_soft_dtw
import aeon
from aeon.distances import (
    dtw_distance, lcss_distance, erp_distance,
    edr_distance, msm_distance, twe_distance
)
from scipy.cluster.hierarchy import linkage
from kneed import KneeLocator
from scipy.spatial.distance import squareform
from sklearn.neighbors import NearestNeighbors
from concurrent import futures

aeon.AEON_DEPRECATION_WARNING = False
os.environ['AEON_DEPRECATION_WARNING'] = 'False'
from sklearn.model_selection import BaseCrossValidator
import numpy as np

import numpy as np
import matplotlib.pyplot as plt
from scipy.cluster.hierarchy import linkage
from kneed import KneeLocator
from scipy.spatial.distance import squareform
import nevergrad as ng
def convert_param_grid_to_nevergrad(param_grid):
    """
    Converts a parameter grid to a Nevergrad-compatible search space.

    Parameters:
    - param_grid (dict): Dictionary of parameter ranges similar to sklearn's GridSearchCV.

    Returns:
    - ng.p.Instrumentation: The Nevergrad search space.
    """
    ng_params = {}
#
    for param, values in param_grid.items():
        # if all(isinstance(v, (int, float)) for v in values):
        #     # Use Choice to limit to discrete numeric values
            ng_params[param] = ng.p.Choice(values)
        # elif all(isinstance(v, str) for v in values):
        #     # Use Choice for string-based categorical values
        #     ng_params[param] = ng.p.Choice(values)
        # else:
        #     raise ValueError(f"Unsupported parameter type for {param}: {values}")
    param = ng.p.Dict (**ng_params)
    print(param.value)
    return ng.p.Dict (**ng_params) #ng.p.Instrumentation(**ng_params)


def calculate_sigma_from_distances(distance_matrix, percentiles=[50], show_plot=False):
    """
    Calculate sigma for Gaussian kernel to convert distance to similarity.
    
    Parameters:
    - distance_matrix (np.ndarray): Distance matrix (n x n).
    - percentiles (list): Percentiles to calculate sigma, typically around 50th.
    - show_plot (bool): If True, plot sorted distances.
    
    Returns:
    - sigma (float): Calculated sigma for Gaussian kernel.
    """
    # Extract the upper triangle to avoid redundant values
    upper_tri_indices = np.triu_indices_from(distance_matrix, k=1)
    upper_tri_distances = distance_matrix[upper_tri_indices]
    
    # Sort distances
    sorted_distances = np.sort(upper_tri_distances)
    
    # Calculate sigma as the median or a chosen percentile
    sigma = np.percentile(sorted_distances, percentiles[0])
    
   
    return sigma


def distance_to_similarity_matrix(distance_matrix):
    """
    Convert a distance matrix to a similarity matrix using Gaussian kernel.
    
    Parameters:
    - distance_matrix (np.ndarray): Distance matrix (n x n).
    - sigma (float): Gaussian kernel sigma.
    - show_plot (bool): If True, display histogram of similarities.
    
    Returns:
    - similarity_matrix (np.ndarray): Converted similarity matrix.
    """
    sigma = calculate_sigma_from_distances(distance_matrix)
    similarity_matrix = np.exp(-np.square(distance_matrix) / (2 * sigma ** 2))
    
    similarity_matrix = np.exp(-np.square(distance_matrix) / (2 * sigma ** 2))
   

    return similarity_matrix
def find_knee_point(sorted_values, curve='convex', direction='increasing'):
    x = np.arange(1, len(sorted_values) + 1)
    y = sorted_values
    knee_locator = KneeLocator(x, y, curve=curve, direction=direction)
    knee_value = knee_locator.knee_y
    return knee_value if knee_value is not None else np.percentile(y, 95)

def generate_dbscan_param_grid(distance_matrix, min_samples_list=[3,5,7], percentiles=[75,85,90,95], show_plot=False):
    param_grid = []
    eps_lst =[]
    for min_samples in min_samples_list:
        # Compute the distance to the k-th nearest neighbor
        sorted_distances = np.sort(distance_matrix, axis=1)[:, 1:min_samples+1]
        k_distances = sorted_distances[:, -1]
        sorted_k_distances = np.sort(k_distances)
        
        # Find the knee point for eps
        knee_eps = find_knee_point(sorted_k_distances, curve='convex', direction='increasing')
        
        # Define eps values around the knee
        eps_values = [knee_eps * 0.9, knee_eps, knee_eps * 1.1] + [np.percentile(sorted_k_distances, p) for p in percentiles]
        eps_values = sorted(list(set(eps_values)))
        
        # Plotting (only once for the first min_samples)
        if show_plot and min_samples == min_samples_list[0]:
            plt.figure(figsize=(10,6))
            plt.plot(np.arange(1, len(sorted_k_distances)+1), sorted_k_distances, marker='.', linestyle='none')
            plt.axhline(y=knee_eps, color='r', linestyle='--', label=f'Knee Point (eps={knee_eps:.2f})')
            plt.xlabel('Points sorted by distance')
            plt.ylabel(f'Distance to {min_samples}-th nearest neighbor')
            plt.title('DBSCAN k-Distance Graph')
            plt.legend()
            plt.grid(True)
            plt.show()
        
        # Append parameters to the grid
        eps_lst.extend(eps_values)

    eps_values =   sorted(list(set(eps_values)))

    param_grid = {'eps': eps_values, 'min_samples': min_samples_list}

    return param_grid

def generate_affinity_propagation_param_grid(similarity_matrix, percentiles=[10,25,50,75,90], show_plot=False):
    # Extract upper triangle to avoid redundant values
    upper_tri_indices = np.triu_indices_from(similarity_matrix, k=1)
    upper_tri_similarities = similarity_matrix[upper_tri_indices]
    log_similarities = np.log1p(upper_tri_similarities)

    # Sort the transformed similarities in ascending order
    #sorted_log_similarities = np.sort(log_similarities)
    # Sort the similarities in ascending order
    sorted_similarities = np.sort(upper_tri_similarities)

    # Find the knee point for preferences
    knee_pref1 = find_knee_point(sorted_similarities, curve='concave', direction='increasing')
    knee_pref = knee_pref1 if knee_pref1 is not None else np.percentile(sorted_similarities, 90)

    # Define preference values
    preference_values = [knee_pref * 0.9, knee_pref, knee_pref * 1.1] + [np.percentile(sorted_similarities, p) for p in percentiles]
    preference_values = sorted(list(set(preference_values)))

    # Plotting
    if show_plot:
        plt.figure(figsize=(10,6))
        plt.hist(upper_tri_similarities, bins=50, alpha=0.7, label='Similarity Scores')
        #for pref in preference_values:
        plt.axvline(x=knee_pref1, linestyle='--', label=f'Preference {knee_pref1:.2f}')
        plt.xlabel('Similarity')
        plt.ylabel('Frequency')
        plt.title('Affinity Propagation Preferences')
        plt.legend()
        plt.grid(True)
        plt.show()

    return preference_values

def generate_agglo_param_grid(distance_matrix, linkage_methods=['average', 'complete', 'single'], percentiles=[75,85,90,95], show_plot=False): #,
    # Convert distance matrix to condensed form
    condensed_distance = squareform(distance_matrix)

    # Perform hierarchical clustering using 'average' linkage
    distance_thresholds =[]
    for method in linkage_methods:
        Z = linkage(condensed_distance, method = method)
        linkage_distances = np.sort(Z[:, 2])

        # Find the knee point for distance_threshold
        knee_distance = find_knee_point(linkage_distances, curve='convex', direction='increasing')
        knee_distance = knee_distance if knee_distance is not None else np.percentile(linkage_distances, 95)

        # Define distance_threshold values around the knee
        distance_thresholds = distance_thresholds+ [knee_distance * 0.9, knee_distance, knee_distance * 1.1] 
    distance_thresholds += [np.percentile(linkage_distances, p) for p in percentiles]
    distance_thresholds = sorted(list(set(distance_thresholds)))

    # Plotting
    if show_plot:
        plt.figure(figsize=(10,6))
        plt.plot(np.arange(1, len(linkage_distances)+1), linkage_distances, marker='.', linestyle='none')
        plt.axhline(y=knee_distance, color='r', linestyle='--', label=f'Knee Point (distance_threshold={knee_distance:.2f})')
        plt.xlabel('Merge Step')
        plt.ylabel('Linkage Distance')
        plt.title('Agglomerative Clustering Linkage Distances')
        plt.legend()
        plt.grid(True)
        plt.show()

    return {'distance_threshold': distance_thresholds, 'linkage': linkage_methods}




class FullDataCV(BaseCrossValidator):
    """
    A custom cross-validator that returns the entire dataset as both training and validation sets.
    This allows GridSearchCV and HalvingGridSearchCV to perform multiple evaluations
    without splitting the distance matrix.
    """
    def __init__(self, n_splits=3):
        self.n_splits = n_splits

    def get_n_splits(self, X=None, y=None, groups=None):
        return self.n_splits

    def split(self, X, y=None, groups=None):
        for _ in range(self.n_splits):
            yield np.arange(len(X)), np.arange(len(X))

class TimeSeriesClusterOptimizer():
    def __init__(
        self,
        X_train: List[np.ndarray],
        clustering_algorithms: Optional[Dict[str, Any]] = None,
        distance: str = 'dtw',
        distance_params: Dict[str, Any] = {},
        X_test: Optional[List[np.ndarray]] = None,
        n_jobs: int = -1,
        optimization_metric: str = 'combined',  # Options: 'combined', 'silhouette', 'calinski_harabasz', 'davies_bouldin'
        verbose: int = 1
    ):
        """
        Initialize the TimeSeriesClusterPredictor.
        
        Parameters:
        - clustering_algorithms (dict): Dictionary mapping algorithm names to their classes.
        - distance (str): Distance metric to use.
        - distance_params (dict): Additional parameters for distance functions.
        - grid_search_method (str): Grid search method to use ('GridSearchCV', 'HalvingGridSearchCV', 'BayesSearchCV').
        - n_jobs (int): Number of parallel jobs.
        - optimization_metric (str): Metric to optimize ('combined', 'silhouette', 'calinski_harabasz', 'davies_bouldin').
        - verbose (int): Verbosity level.
        """
        self.clustering_algorithms = clustering_algorithms or {
            'AgglomerativeClustering': CustomAgglomerativeClustering,
            'AffinityPropagation': CustomAffinityPropagation,
            'DBSCAN': CustomDBSCAN,
            'OPTICS': CustomOPTICS,
            'ChineseWhispers': CustomChineseWhispers
        }
        self.distance = distance
        self.distance_params = distance_params
        self.X_train = X_train
        self.X_test = X_test
        #self.grid_search_method = grid_search_method
        self.n_jobs = n_jobs
        self.optimization_metric = optimization_metric
        self.verbose = verbose
        
        # Define distance metrics
        self.distance_metrics = {
            'dtw': dtw_distance,
            'softdtw': cdist_soft_dtw,
            'euclidean': 'euclidean',
            'lcss': lcss_distance,
            'erp': erp_distance,
            'edr': edr_distance,
            'msm': msm_distance,
            'twe': twe_distance,
        }
        
        # Initialize logger
        self.logger = logging.getLogger(self.__class__.__name__)
        if not self.logger.handlers:
            # Prevent adding multiple handlers in interactive environments
            handler = logging.StreamHandler()
            formatter = logging.Formatter('%(asctime)s -  %(message)s') #%(name)s - %(levelname)s -
            handler.setFormatter(formatter)
            self.logger.addHandler(handler)
            self.logger.setLevel(logging.INFO)
        
        # Initialize dictionaries to store best estimators and scores
        self.best_estimators_ = {}
        self.best_scores_ = {}
    
    def _cdist_generic(self, dist_fun, dataset1, dataset2=None) -> np.ndarray:
        """Generic parallel distance computation."""
        if dataset2 is None:
            matrix = np.zeros((len(dataset1), len(dataset1)))
            indices = np.triu_indices(len(dataset1), k=0)
            
            matrix[indices] = Parallel(n_jobs=self.n_jobs, prefer="threads")(
                delayed(dist_fun)(dataset1[i], dataset1[j], **self.distance_params)
                for i in range(len(dataset1))
                for j in range(i, len(dataset1))
            )
            
            indices_lower = np.tril_indices(len(dataset1), k=-1)
            matrix[indices_lower] = matrix.T[indices_lower]
            return matrix
        else:
            distances = Parallel(n_jobs=self.n_jobs, prefer="threads")(
                delayed(dist_fun)(dataset1[i], dataset2[j], **self.distance_params)
                for i in range(len(dataset1))
                for j in range(len(dataset2))
            )
            return np.reshape(distances, (len(dataset1), len(dataset2)))
    
    def compute_distance_matrix(self, X: List[np.ndarray]) -> np.ndarray:
        """Compute distance matrix with caching."""
        params_str = '_'.join(f"{k}:{v}" for k, v in sorted(self.distance_params.items()))
        params_hash = hashlib.md5(params_str.encode()).hexdigest()
        cache_dir = 'distance_matrices'
        cache_path = os.path.join(cache_dir, f"{self.distance}_{params_hash}.pkl")
        os.makedirs(cache_dir, exist_ok=True)
    
        if os.path.exists(cache_path):
            self.logger.info("Loading cached distance matrix")
            distance_matrix = joblib.load(cache_path)
        else:
            self.logger.info(f"Computing distance matrix using {self.distance}")
            start_time = time.time()
    
            if self.distance == 'dtw':
                distance_matrix = cdist_dtw(X, n_jobs=self.n_jobs, **self.distance_params)
            elif self.distance == 'softdtw':
                distance_matrix = cdist_soft_dtw(X, **self.distance_params)
            else:
                dist_func = self.distance_metrics.get(self.distance)
                if dist_func is None:
                    raise ValueError(f"Unsupported distance metric: {self.distance}")
                distance_matrix = self._cdist_generic(dist_func, X)
    
            elapsed_time = time.time() - start_time
            self.logger.info(f"Distance matrix computed in {elapsed_time:.2f} seconds")
            joblib.dump(distance_matrix, cache_path)
        
        self.distance_matrix_ = distance_matrix
        return distance_matrix
    
    def _compute_distances_to_centers(self, X: List[np.ndarray], centers: List[np.ndarray]) -> np.ndarray:
        """Compute distances between samples and given cluster centers."""
        if self.distance == 'dtw':
            return cdist_dtw(X, centers, n_jobs=self.n_jobs, **self.distance_params)
        elif self.distance == 'softdtw':
            return cdist_soft_dtw(X, centers, **self.distance_params)
        else:
            dist_func = self.distance_metrics.get(self.distance)
            if dist_func is None:
                raise ValueError(f"Unsupported distance metric: {self.distance}")
            return self._cdist_generic(dist_func, X, centers)
    
    def _get_param_grid(self, algorithm_name: str, distance_matrix: np.ndarray, similarity_matrix: Optional[np.ndarray] = None) -> Dict[str, List[Any]]:
        """
        Generate parameter grid based on the clustering algorithm.
        
        Parameters:
        - algorithm_name (str): Name of the clustering algorithm.
        - distance_matrix (np.ndarray): Distance matrix for training data.
        - similarity_matrix (Optional[np.ndarray]): Similarity matrix if needed.
        
        Returns:
        - param_grid (dict): Parameter grid for grid search.
        """
        if algorithm_name == 'AgglomerativeClustering':
            # Compute distance thresholds using quantiles
            #thresholds = np.percentile(distance_matrix[np.triu_indices_from(distance_matrix, k=1)], [25,50,65,75, 85, 90, 95])
            # agglo_param_grid = {
            #     'distance_threshold': thresholds.tolist(),
            #     'linkage': ['average', 'complete', 'single']
            # }
            quantiles = [25,50,65,75, 85, 90, 95]
            agglo_param_grid = generate_agglo_param_grid(distance_matrix, percentiles=quantiles,show_plot=False)
            return agglo_param_grid
        
        elif algorithm_name == 'AffinityPropagation':
            # Compute preferences using quantiles of similarity matrix
            # if similarity_matrix is None:
            #     similarity_matrix = 1 / (distance_matrix + 1e-8)  # Convert distance to similarity
            #preferences = np.percentile(similarity_matrix, [10,25,30,40,55,70,85])
            similarity_matrix = distance_to_similarity_matrix(distance_matrix)
            percentiles = [10,25,30,40,55,70,85]
            preferences = generate_affinity_propagation_param_grid(similarity_matrix,percentiles=percentiles,show_plot=False)
            affinity_param_grid = {
                'damping': [0.7, 0.75, 0.8, 0.85, 0.9, 0.95],
                'preference': preferences
            }
            quantiles = [10,25,30,40,55,70,85]

            return affinity_param_grid
        
        elif algorithm_name == 'DBSCAN':
            # Estimate eps using k-distance graph
            min_samples = [3, 5, 7]
            # eps_values = self.estimate_eps(distance_matrix,min_samples_values=min_samples)

            # dbscan_param_grid = {
            #     'eps': eps_values.tolist(),
            #     'min_samples': [3, 5, 7]
            # }
            dbscan_param_grid = generate_dbscan_param_grid(distance_matrix,min_samples_list=min_samples,show_plot =False)
            return dbscan_param_grid
        
        elif algorithm_name == 'OPTICS':
            optics_param_grid = {
                'min_samples': [3, 5, 7,10],
                'xi': [0.05, 0.1, 0.15, 0.2, 0.25,0.3]
            }
            return optics_param_grid
        
        elif algorithm_name == 'ChineseWhispers':
            cw_param_grid = {
                'iterations': [10, 20, 50, 100],
                'weighting': ['top', 'lin', 'log'],
                'k': [5, 10, 15, None]
            }
            return cw_param_grid
        
        else:
            raise ValueError(f"No parameter grid defined for algorithm: {algorithm_name}")
        
    
    def find_best_parameters(
        self,
        grid_search_method: str = 'GridSearchCV',  # Options: 'GridSearchCV', 'HalvingGridSearchCV', 'BayesSearchCV',
        algorithms: Optional[List[str]] = None,
        cv: int =5
    ) -> Dict[str, Any]:
        """
        Find the best hyperparameters for each clustering algorithm using grid search.
        
        Parameters:
        - algorithms (List[str], optional): List of algorithm names to tune. If None, tune all.
        - grid_search_method (str, optional): Grid search method to use ('GridSearchCV', 'HalvingGridSearchCV', 'BayesSearchCV').
                                              If None, use the instance's grid_search_method.
        - cv (int): Number of cross-validation folds.
        
        Returns:
        - best_estimators (dict): Dictionary of best estimators for each algorithm.
        - best_scores (dict): Dictionary of best scores for each algorithm.
        """
        self.logger.info("Starting hyperparameter tuning for clustering algorithms.")
        
       
        self.grid_search_method = grid_search_method
        
        if algorithms is None:
            algorithms = list(self.clustering_algorithms.keys())

        # Compute distance matrix for training data
        self.distance_matrix_ = self.compute_distance_matrix(self.X_train)
        
        
        # Initialize dictionaries to store best estimators and scores

        best_estimators = {}
        best_scores = {}
        cv_strategy = FullDataCV(n_splits=cv)
        for name in algorithms:
            self.logger.info(f"Starting grid search for {name}.")
            start_time = time.time()
            print(f"[{time.strftime('%H:%M:%S')}] Optimizing {name} clustering...")
            alg_class = self.clustering_algorithms[name]
            
            param_grid = self._get_param_grid(name,self.distance_matrix_)
            print ('##########################')
            print (f'ALgorith{name}')
            print (param_grid)
            if param_grid is None:
                continue
             # Initialize search_spaces for BayesSearchCV
           
            search_spaces = param_grid
            # Define the custom scorer
            def custom_scorer(estimator, X, y=None):
                """
                Custom scorer that computes the combined score based on clustering metrics
                and adjusts it based on the outlier ratio using X_test.
                """
                #print("Custom scorer is called.")
                # Retrieve labels
                if hasattr(estimator, 'labels_'):
                    labels = estimator.labels_
                    indx = labels != -1
                else:
                    raise AttributeError("The clustering algorithm does not have 'labels_' attribute after fitting.")
                
                # Compute clustering metrics
                unique_labels = np.unique(labels)
                if len(unique_labels) >1:
                    try:
                        silhouette = silhouette_score(X[np.ix_(indx, indx)], labels[indx], metric='precomputed')
                    except Exception as e:
                        print(f"silhouette: {e}")
                        raise e
                    calinski_harabasz = calinski_harabasz_score(self.X_train, labels)
                    davies_bouldin = davies_bouldin_score(self.X_train, labels)
                    
                    davies_bouldin_normalized = 1 / (1 + davies_bouldin)
                    calinski_harabasz_normalized = 1-1/calinski_harabasz
                    combined_score = (0.4*silhouette + 0.3* calinski_harabasz_normalized + 0.3* davies_bouldin_normalized)
                    outlier_ratio = np.sum(labels == -1) / len(labels)
                    #print("outlier train:", outlier_ratio)
                        # Adjust combined score
                    combined_score *= (1 - outlier_ratio)
                    # Adjust score based on outlier ratio from X_test if provided
                    if self.X_test is not None:
                        # Compute distances to cluster centers
                        distance_matrix_test = self._compute_distances_to_centers(self.X_test, self.X_train[estimator.cluster_centers_indices_])
                        # Predict labels on test data
                        test_labels = estimator.predict(distance_matrix_test)
                        # Compute outlier ratio
                        outlier_ratio = np.sum(test_labels == -1) / len(test_labels)
                        # Adjust combined score
                        combined_score *= (1 - outlier_ratio)      
                        #print("outlier test:", outlier_ratio)
                else:
                        combined_score = -1
                        silhouette = -1
                        calinski_harabasz = -1
                        davies_bouldin_normalized = 1000
                # Return the appropriate score based on optimization_metric
                if self.optimization_metric == 'combined':
                    return combined_score
                elif self.optimization_metric == 'silhouette':
                    return silhouette
                elif self.optimization_metric == 'calinski_harabasz':
                    return calinski_harabasz
                elif self.optimization_metric == 'davies_bouldin':
                    return davies_bouldin_normalized
                else:
                    raise ValueError(f"Unsupported optimization metric: {self.optimization_metric}")
           
           
            # Select the grid search method
            if grid_search_method == 'GridSearchCV':
                grid_search = GridSearchCV(
                    estimator=alg_class(),
                    param_grid=search_spaces,
                    scoring = custom_scorer,
                    cv=cv_strategy,
                    n_jobs=self.n_jobs,
                    verbose=self.verbose
                )
            elif grid_search_method == 'Nevergrad':
                # Use Nevergrad optimization
                ng_param_space = convert_param_grid_to_nevergrad(param_grid)
                #optimizer = ng.optimizers.NGOpt(parametrization=ng_param_space, num_workers=4, budget=50)  # Adjust budget as needed
                optimizer = ng.optimizers.ScrHammersleySearch(parametrization=ng_param_space,  num_workers=5, budget=50)  # Adjust budget as neededexecutor=executor

                def nevergrad_objective(kwargs,alg_class, name):
                    # Create an instance of the clustering algorithm with given parameters
                    estimator = alg_class(**kwargs)
                    estimator.fit(self.distance_matrix_)  # Fit on the distance matrix
                    # Calculate custom score
                    return -custom_scorer(estimator, self.distance_matrix_)  # Negative for minimization
                objective_func = partial(nevergrad_objective, alg_class= alg_class,name=name)
                # Run optimization with Nevergrad
                #with futures.ThreadPoolExecutor(max_workers=optimizer.num_workers) as executor:

                recommendation = optimizer.minimize(objective_func,  batch_mode=False) #e executor=executor,
                # with ThreadPoolExecutor(max_workers=self.n_jobs) as executor:
                #     recommendation = optimizer.minimize(nevergrad_objective)
                best_params = recommendation.value

                # Fit the best estimator with optimal params
                best_estimator = alg_class(**best_params)
                best_estimator.fit(self.distance_matrix_)
                best_score = -recommendation.loss  # Retrieve best score
                  # Collect best estimator and score
                best_estimators[name] = best_estimator
                best_scores[name] = best_score
                self.logger.info(f"Completed grid search for {name}. Best score: {-recommendation.loss :.4f}")
                end_time = time.time()
                print(f"[{time.strftime('%H:%M:%S')}] Finished {name} in {end_time - start_time:.2f} seconds.")
            else:
                raise ValueError(f"Unsupported grid search method: {grid_search_method}")
            
            if grid_search_method in ['BayesSearchCV','HalvingGridSearchCV','GridSearchCV']: 
                # Perform grid search
                grid_search.fit(self.distance_matrix_)
                
                # Collect best estimator and score
                best_estimators[name] = grid_search.best_estimator_
                best_scores[name] = grid_search.best_score_
            
                self.logger.info(f"Completed grid search for {name}. Best score: {grid_search.best_score_:.4f}")
                end_time = time.time()
                print(f"[{time.strftime('%H:%M:%S')}] Finished {name} in {end_time - start_time:.2f} seconds.")
        # Store the best estimators and scores
        self.best_estimators_ = best_estimators
        self.best_scores_ = best_scores
        
        self.logger.info("Hyperparameter tuning completed for all algorithms.")
        
       
        return {'best_estimators': best_estimators, 'best_scores': best_scores}
    
   
  

import numpy as np
from sklearn.datasets import make_blobs
from sklearn.preprocessing import StandardScaler
import time
import pandas as pd
from sklearn.metrics import adjusted_rand_score, adjusted_mutual_info_score
import matplotlib.pyplot as plt
import seaborn as sns
# Generate synthetic time series data
def generate_synthetic_data(n_samples=90, n_features=100, n_clusters=5, random_state=42):
    np.random.seed(random_state)
    X = []
    labels = []
    t = np.linspace(0, 4 * np.pi, n_features)
    
    # Define distinct patterns for each cluster
    patterns = []
    for i in range(n_clusters):
        phase_shift = i * np.pi / 2  # Phase shift to separate clusters
        amplitude = 1 + i * 0.5      # Different amplitude for each cluster
        frequency = 1 + i * 0.2      # Different frequency for each cluster
        pattern = amplitude * np.sin(frequency * t + phase_shift)
        patterns.append(pattern)
    
    # Generate data for each cluster
    samples_per_cluster = n_samples // n_clusters
    for i in range(n_clusters):
        pattern = patterns[i]
        for _ in range(samples_per_cluster):
            noise = np.random.normal(0, 0.2, n_features)  # Adjusted noise level
            X.append(pattern + noise)
            labels.append(i)
    
    X = np.array(X)
    labels = np.array(labels)
    return X, labels
def main():
    # Generate synthetic dataset with known clusters
    # Step 1: Generate synthetic time series data
    X_train, labels_true = generate_synthetic_data(n_samples=1000, n_features=100, n_clusters=17,random_state=24)
    X_test, y_test_true = generate_synthetic_data(n_samples=100, n_features=100, n_clusters=17, random_state=24)

  
    # Initialize the predictor with all clustering algorithms
# clustering_algorithms={
#         'AgglomerativeClustering': CustomAgglomerativeClustering,
#         'AffinityPropagation': CustomAffinityPropagation,
#         'DBSCAN': CustomDBSCAN,
#         'OPTICS': CustomOPTICS,
#         'ChineseWhispers': CustomChineseWhispers
#     },
    optime = TimeSeriesClusterOptimizer(
                    X_train= X_train,
                    distance='dtw',
                    distance_params={'global_constraint': 'sakoe_chiba', 'sakoe_chiba_radius': 3},
                    X_test= X_test,
                    n_jobs=-1,
                    optimization_metric='combined',
                    verbose=0
                )
    
    best_results = optime.find_best_parameters(
                algorithms = None,# None, ,'DBSCAN' #['AffinityPropagation'],'AgglomerativeClustering''AgglomerativeClustering',  # None implies tuning all supported algorithms
                grid_search_method ='Nevergrad', #'Nevergrad', #'Nevergrad',  # Can also be 'GridSearchCV' or 'BayesSearchCV'
                cv=2
                    )

    best_estimators = best_results['best_estimators']
    
    best_scores = best_results['best_scores']
     # Display the results
    for name, score in best_scores.items():
            print ('#######################')
            print(name)
            print(f"Best Score = {score:.4f}")
            print('Train ari', adjusted_rand_score(labels_true, best_estimators[name].labels_))
            print('Train ami', adjusted_mutual_info_score(labels_true, best_estimators[name].labels_))
            print(f"Best Param = {best_estimators[name].get_params()}")
            print(f"Best # lables = {len(best_estimators[name].cluster_centers_indices_)}")
            print(f"Best # out= { np.sum(best_estimators[name].labels_ == -1) / len(optime.X_train)}")
            if optime.X_test is not None:
             # Compute distances to cluster centers

                        distance_matrix_test = optime._compute_distances_to_centers(optime.X_test, optime.X_train[best_estimators[name].cluster_centers_indices_])
                        # Predict labels on test data
                        test_labels = best_estimators[name].predict(distance_matrix_test)
                        # Compute outlier ratio
                        outlier_ratio = np.sum(test_labels == -1) / len(test_labels)
                        # Adjust combined score
                        print('Test ari', adjusted_rand_score(y_test_true, test_labels))
                        print('Test ami', adjusted_mutual_info_score(y_test_true, test_labels))
                        print(f"{name}: Best Train Outl= {outlier_ratio}")
            print ('#######################')

if __name__ == "__main__":
    main()