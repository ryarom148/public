import numpy as np
from sklearn.base import BaseEstimator, ClusterMixin
from sklearn.cluster import AgglomerativeClustering
from sklearn.utils.validation import check_is_fitted
import warnings

warnings.filterwarnings("ignore")


class CustomAgglomerativeClustering(BaseEstimator, ClusterMixin):
    def __init__(self, distance_threshold=1.5, linkage='average'):
        """
        Custom Agglomerative Clustering estimator.

        Parameters:
        - distance_threshold (float): The linkage distance threshold above which clusters will not be merged.
        - linkage (str): Which linkage criterion to use. Can be 'ward', 'complete', 'average', or 'single'.
        """
        self.distance_threshold = distance_threshold
        self.linkage = linkage

    def fit(self, X, y=None):
        """
        Fit the Agglomerative Clustering model using the precomputed distance matrix.

        Parameters:
        - X (ndarray): Precomputed distance matrix of shape (n_samples, n_samples).
        - y: Ignored.

        Returns:
        - self
        """
        self.distance_matrix_ = X
        self.model_ = AgglomerativeClustering(
            n_clusters=None,
            distance_threshold=self.distance_threshold,
            metric ='precomputed',
            linkage=self.linkage
        )
        self.labels_ = self.model_.fit_predict(X)

        # Identify unique clusters
        unique_labels = set(self.labels_)
        unique_labels.discard(-1)  # AgglomerativeClustering does not label noise as -1, but keeping for consistency

        # Set cluster centers
        self.set_cluster_centers_indices(unique_labels)

        # Set outlier thresholds
        self.set_outlier_thresholds(unique_labels)

        # Compute overall outlier ratio in the training data
        # Since AgglomerativeClustering does not identify outliers, outlier_ratio_ is based on thresholding
        self.outlier_ratio_ = np.sum(self._compute_outlier_mask()) / len(self.labels_)

        return self

    def set_cluster_centers_indices(self, unique_labels):
        """
        Determine and store cluster center indices.

        Parameters:
        - unique_labels (set): Set of unique cluster labels excluding noise.
        """
        cluster_centers_indices_ = {}
        for label in unique_labels:
            cluster_indices = np.where(self.labels_ == label)[0]
            if len(cluster_indices) == 0:
                continue
            # Extract the sub-distance matrix for the cluster
            sub_distance_matrix = self.distance_matrix_[np.ix_(cluster_indices, cluster_indices)]
            # Compute the sum of distances for each point in the cluster
            total_distances = sub_distance_matrix.sum(axis=1)
            # Identify the medoid (point with minimum total distance)
            medoid_idx = cluster_indices[np.argmin(total_distances)]
            cluster_centers_indices_[label] = medoid_idx
        self._cluster_centers_indices_ = cluster_centers_indices_

    def set_outlier_thresholds(self, unique_labels):
        """
        Determine and store outlier thresholds for each cluster.

        Parameters:
        - unique_labels (set): Set of unique cluster labels excluding noise.
        """
        self.outlier_thresholds_ = {}
        for label in unique_labels:
            medoid_idx = self._cluster_centers_indices_[label]
            cluster_mask = self.labels_ == label
            # Distances from points in the cluster to the medoid
            distances_to_medoid = self.distance_matrix_[cluster_mask, medoid_idx]
            # Define the threshold as the 95th percentile of distances
            threshold = np.percentile(distances_to_medoid, 95)
            self.outlier_thresholds_[label] = threshold

    def _compute_outlier_mask(self):
        """
        Compute a boolean mask indicating which samples are outliers based on thresholds.

        Returns:
        - outlier_mask (ndarray): Boolean array where True indicates an outlier.
        """
        outlier_mask = np.zeros(len(self.labels_), dtype=bool)
        for label, medoid_idx in self._cluster_centers_indices_.items():
            cluster_mask = self.labels_ == label
            distances_to_medoid = self.distance_matrix_[cluster_mask, medoid_idx]
            threshold = self.outlier_thresholds_[label]
            outliers = distances_to_medoid > threshold
            outlier_mask[cluster_mask] = outliers
        return outlier_mask

    def predict(self, X, check_outliers=True):
        """
        Predict cluster labels for new data based on the distance to cluster centers.

        Parameters:
        - X (ndarray): Distance matrix of shape (n_samples_new, n_clusters).
                       Each column corresponds to a cluster center.
        - check_outliers (bool): Whether to check for outliers based on thresholds.

        Returns:
        - labels (ndarray): Cluster labels for each sample. Outliers are marked as -1.
        """
        check_is_fitted(self, ['cluster_centers_indices_'])

        # Assign each sample to the nearest cluster center
        labels = np.argmin(X, axis=1)

        if check_outliers:
            # Retrieve the minimal distance for each sample
            min_distances = X[np.arange(X.shape[0]), labels]
            # Retrieve corresponding cluster labels
            cluster_labels = list(self._cluster_centers_indices_.keys())
            assigned_cluster_labels = [cluster_labels[label] for label in labels]
            # Retrieve thresholds for assigned clusters
            thresholds = np.array([self.outlier_thresholds_.get(label, np.inf) for label in assigned_cluster_labels])
            # Identify outliers
            outliers = min_distances > thresholds
            labels[outliers] = -1

        return labels
    @property
    def cluster_centers_indices_(self):
        """
        Get the indices of cluster centers (medoids).

        Returns:
        - centers: dict
            Dictionary mapping cluster labels to medoid indices.
        """
        if not hasattr(self, '_cluster_centers_indices_'):
            raise AttributeError("The cluster_centers_indices_ attribute is not set.")
        return list(self._cluster_centers_indices_.values()) 
    
    @cluster_centers_indices_.setter
    def cluster_centers_indices_(self, value):
        self._cluster_centers_indices_ = value

    def fit_predict(self, X, y=None):
        """
        Fit the model and predict the cluster labels for the training data.

        Parameters:
        - X (ndarray): Precomputed distance matrix of shape (n_samples, n_samples).
        - y: Ignored.

        Returns:
        - labels (ndarray): Cluster labels for each sample.
        """
        self.fit(X)
        # Apply outlier thresholds to training data
        outlier_mask = self._compute_outlier_mask()
        labels = self.labels_.copy()
        labels[outlier_mask] = -1
        self.outlier_ratio_ = np.sum(labels == -1) / len(labels)
        self.labels_ = labels
        return self.labels_

    def get_params(self, deep=True):
        """
        Get parameters for this estimator.

        Parameters:
        - deep (bool): If True, will return the parameters for this estimator and
                       contained subobjects that are estimators.

        Returns:
        - params (dict): Parameter names mapped to their values.
        """
        return {'distance_threshold': self.distance_threshold, 'linkage': self.linkage}

    def set_params(self, **params):
        """
        Set the parameters of this estimator.

        Parameters:
        - **params: dict
            Estimator parameters.

        Returns:
        - self: Estimator instance.
        """
        for key, value in params.items():
            setattr(self, key, value)
        return self