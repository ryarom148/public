import numpy as np
from sklearn.base import BaseEstimator, ClusterMixin
from sklearn.utils.validation import check_is_fitted
import networkx as nx
import warnings
from chinese_whispers import chinese_whispers, aggregate_clusters  # Correct imports

warnings.filterwarnings("ignore")


class CustomChineseWhispers(BaseEstimator, ClusterMixin):
    def __init__(self, iterations=20, weighting='top', k=5):
        """
        Custom Chinese Whispers clustering estimator.

        Parameters:
        - iterations (int): Number of iterations to run the algorithm.
        - weighting (str): Method to assign weights to edges. Options:
                           'top' (default): Topological weighting (top k neighbors).
                           'lin': Linear weighting based on similarity.
                           'log': Logarithmic weighting based on similarity.
        - k (int or None): Number of top similar neighbors to consider. Default is 5.
                           If set to None or greater than the number of possible neighbors, all neighbors are considered.
        """
        self.iterations = iterations
        self.weighting = weighting
        self.k = k

    def fit(self, X, y=None):
        """
        Fit the Chinese Whispers model using the precomputed distance matrix.

        Parameters:
        - X (ndarray): Precomputed distance matrix of shape (n_samples, n_samples).
        - y: Ignored.

        Returns:
        - self
        """
        self.distance_matrix_ = X
        n_samples = self.distance_matrix_.shape[0]
        # Convert distance matrix to similarity weights
        self.similarity_matrix_ = self._convert_distance_to_similarity(X)

        # Build the graph with top k neighbors
        self.graph_ = self._build_graph(self.similarity_matrix_, self.k)

        # Apply Chinese Whispers algorithm using the chinese-whispers library
        initial_labels = chinese_whispers(
            graph=self.graph_,
            iterations=self.iterations,
            weighting=self.weighting
        )
                # Map labels to consecutive integers
        attr = 'label'
        labels = np.array([self.graph_.nodes[node][attr] for node in range(n_samples)])
        unique_labels = np.unique(labels)
        label_mapping = {label: idx for idx, label in enumerate(unique_labels)}
        labels_mapped = np.array([label_mapping[label] for label in labels])
        self.labels_ = labels_mapped

        
        # Aggregate clusters if necessary
        # Assuming aggregate_clusters takes the graph and initial labels and returns refined labels
        aggregated_labels = aggregate_clusters(
            graph=self.graph_
            
        )

        # # Ensure cluster labels start from 0 and are consecutive
        # self.labels_ = self._map_labels_to_consecutive(aggregated_labels)
         
        # Identify unique clusters excluding noise (-1)
        unique_labels = set(self.labels_)
        unique_labels.discard(-1)  # If -1 is used for outliers

        # Set cluster centers
        self.set_cluster_centers_indices(unique_labels)

        # Set outlier thresholds based on cluster centers
        self.set_outlier_thresholds(unique_labels)

        # Compute overall outlier ratio in the training data
        self.outlier_ratio_ = np.sum(self.labels_ == -1) / len(self.labels_)

        return self

    def _convert_distance_to_similarity(self, distance_matrix):
        """
        Convert distance matrix to similarity matrix based on weighting.

        Parameters:
        - distance_matrix (ndarray): Precomputed distance matrix.

        Returns:
        - similarity_matrix (ndarray): Similarity matrix.
        """
        # Invert distance to get similarity
        # To avoid division by zero, add a small epsilon
        epsilon = 1e-8
        similarity_matrix = 1 / (distance_matrix + epsilon)

        # Apply weighting
        if self.weighting == 'top':
            # Topological weighting: only keep the top k similarities
            if self.k is None:
                # If k is None, consider all neighbors
                return similarity_matrix
            N = self.k
            for i in range(similarity_matrix.shape[0]):
                # Get indices of top N similarities for each row
                top_n_idx = np.argsort(similarity_matrix[i])[::-1][:N]
                mask = np.ones(similarity_matrix.shape[1], dtype=bool)
                mask[top_n_idx] = False
                similarity_matrix[i][mask] = 0
        elif self.weighting == 'lin':
            # Linear weighting: scale similarities linearly between 0 and 1
            similarity_matrix = (similarity_matrix - np.min(similarity_matrix)) / (
                np.max(similarity_matrix) - np.min(similarity_matrix) + 1e-8
            )
        elif self.weighting == 'log':
            # Logarithmic weighting: apply log scaling
            similarity_matrix = np.log(similarity_matrix + 1)
            similarity_matrix = (similarity_matrix - np.min(similarity_matrix)) / (
                np.max(similarity_matrix) - np.min(similarity_matrix) + 1e-8
            )
        else:
            raise ValueError(f"Unknown weighting method: {self.weighting}")

        return similarity_matrix

    def _build_graph(self, similarity_matrix, k):
        """
        Build a weighted graph from the similarity matrix, considering top k neighbors.

        Parameters:
        - similarity_matrix (ndarray): Similarity matrix.
        - k (int or None): Number of top similar neighbors to consider.

        Returns:
        - G (networkx.Graph): Weighted graph.
        """
        G = nx.Graph()
        n_samples = similarity_matrix.shape[0]
        for i in range(n_samples):
            if k is not None:
                # Get top k similar neighbors for node i, including self if needed
                top_k = np.argsort(similarity_matrix[i])[::-1][:k]
            else:
                # Connect to all other nodes
                top_k = np.argsort(similarity_matrix[i])[::-1]
            for j in top_k:
                if i == j:
                    continue  # Exclude self-loops
                weight = similarity_matrix[i, j]
                if weight > 0:
                    G.add_edge(i, j, weight=weight)
        return G

    def _map_labels_to_consecutive(self, labels):
        """
        Map cluster labels to start from 0 and be consecutive integers.

        Parameters:
        - labels (list or ndarray): Original cluster labels.

        Returns:
        - mapped_labels (ndarray): Mapped cluster labels starting from 0.
        """
        unique_labels = sorted(set(labels.key()))
        mapped_labels ={}
        # Handle outliers if labeled as -1
        if -1 in unique_labels:
            unique_labels.remove(-1)
            label_mapping = {label: idx for idx, label in enumerate(unique_labels)}
            label_mapping[-1] = -1  # Keep outliers as -1
        else:
            label_mapping = {label: idx for idx, label in enumerate(unique_labels)}
        mapped_labels = np.array([label_mapping[label] for label in labels])
        return mapped_labels

    def set_cluster_centers_indices(self, unique_labels):
        """
        Determine and store cluster center indices.

        Parameters:
        - unique_labels (set): Set of unique cluster labels.
        """
        self._cluster_centers_indices_ = {}
        for label in unique_labels:
            cluster_indices = np.where(self.labels_ == label)[0]
            if len(cluster_indices) == 0:
                continue
            # Compute the medoid: point with minimum total distance to others in the cluster
            sub_distance_matrix = self.distance_matrix_[np.ix_(cluster_indices, cluster_indices)]
            total_distances = sub_distance_matrix.sum(axis=1)
            medoid_idx = cluster_indices[np.argmin(total_distances)]
            self._cluster_centers_indices_[label] = medoid_idx

    def set_outlier_thresholds(self, unique_labels):
        """
        Determine and store outlier thresholds for each cluster.

        Parameters:
        - unique_labels (set): Set of unique cluster labels.
        """
        self.outlier_thresholds_ = {}
        for label in unique_labels:
            medoid_idx = self._cluster_centers_indices_[label]
            cluster_mask = self.labels_ == label
            distances_to_medoid = self.distance_matrix_[cluster_mask, medoid_idx]
            # Define the threshold as the 95th percentile of distances
            threshold = np.percentile(distances_to_medoid, 95)
            self.outlier_thresholds_[label] = threshold

    def _compute_outlier_mask(self):
        """
        Compute a boolean mask indicating which samples are outliers based on thresholds.

        Returns:
        - outlier_mask (ndarray): Boolean array where True indicates an outlier.
        """
        outlier_mask = np.zeros(len(self.labels_), dtype=bool)
        for label, medoid_idx in self._cluster_centers_indices_.items():
            cluster_mask = self.labels_ == label
            distances_to_medoid = self.distance_matrix_[cluster_mask, medoid_idx]
            threshold = self.outlier_thresholds_.get(label, np.inf)
            outliers = distances_to_medoid > threshold
            outlier_mask[cluster_mask] = outliers
        return outlier_mask

    def predict(self, X, check_outliers=True):
        """
        Predict cluster labels for new data based on the distance to cluster centers.

        Parameters:
        - X (ndarray): Distance matrix of shape (n_samples_new, n_clusters).
                       Each column corresponds to a cluster center.
        - check_outliers (bool): Whether to check for outliers based on thresholds.

        Returns:
        - labels (ndarray): Cluster labels for each sample. Outliers are marked as -1.
        """
        check_is_fitted(self, ['cluster_centers_indices_'])

        # Assign each sample to the nearest cluster center
        labels = np.argmin(X, axis=1)

        if check_outliers:
            # Retrieve the minimal distance for each sample
            min_distances = X[np.arange(X.shape[0]), labels]
            # Retrieve corresponding cluster labels
            cluster_labels = list(self._cluster_centers_indices_.keys())
            assigned_cluster_labels = [cluster_labels[label] for label in labels]
            # Retrieve thresholds for assigned clusters
            thresholds = np.array([self.outlier_thresholds_.get(label, np.inf) for label in assigned_cluster_labels])
            # Identify outliers
            outliers = min_distances > thresholds
            labels[outliers] = -1

        return labels
    @property
    def cluster_centers_indices_(self):
        """
        Get the indices of cluster centers (medoids).

        Returns:
        - centers: dict
            Dictionary mapping cluster labels to medoid indices.
        """
        if not hasattr(self, '_cluster_centers_indices_'):
            raise AttributeError("The cluster_centers_indices_ attribute is not set.")
        return list(self._cluster_centers_indices_.values()) 
    
    @cluster_centers_indices_.setter
    def cluster_centers_indices_(self, value):
        self._cluster_centers_indices_ = value
    def fit_predict(self, X, y=None):
        """
        Fit the model and predict the cluster labels for the training data.

        Parameters:
        - X (ndarray): Precomputed distance matrix of shape (n_samples, n_samples).
        - y: Ignored.

        Returns:
        - labels (ndarray): Cluster labels for each sample.
        """
        self.fit(X)
        # Apply outlier thresholds to training data
        outlier_mask = self._compute_outlier_mask()
        labels = self.labels_.copy()
        labels[outlier_mask] = -1
        self.outlier_ratio_ = np.sum(labels == -1) / len(labels)
        self.labels_ = labels
        return self.labels_

    def get_params(self, deep=True):
        """
        Get parameters for this estimator.

        Parameters:
        - deep (bool): If True, will return the parameters for this estimator and
                       contained subobjects that are estimators.

        Returns:
        - params (dict): Parameter names mapped to their values.
        """
        return {'iterations': self.iterations, 'weighting': self.weighting, 'k': self.k}

    def set_params(self, **params):
        """
        Set the parameters of this estimator.

        Parameters:
        - **params: dict
            Estimator parameters.

        Returns:
        - self: Estimator instance.
        """
        for key, value in params.items():
            setattr(self, key, value)
        return self