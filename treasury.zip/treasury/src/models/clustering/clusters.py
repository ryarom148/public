import numpy as np
from sklearn.base import BaseEstimator, ClusterMixin
from sklearn.cluster import AffinityPropagation
from sklearn.utils.validation import check_is_fitted
import warnings

warnings.filterwarnings("ignore")
def calculate_sigma_from_distances(distance_matrix, percentiles=[50], show_plot=False):
    """
    Calculate sigma for Gaussian kernel to convert distance to similarity.
    
    Parameters:
    - distance_matrix (np.ndarray): Distance matrix (n x n).
    - percentiles (list): Percentiles to calculate sigma, typically around 50th.
    - show_plot (bool): If True, plot sorted distances.
    
    Returns:
    - sigma (float): Calculated sigma for Gaussian kernel.
    """
    # Extract the upper triangle to avoid redundant values
    upper_tri_indices = np.triu_indices_from(distance_matrix, k=1)
    upper_tri_distances = distance_matrix[upper_tri_indices]
    
    # Sort distances
    sorted_distances = np.sort(upper_tri_distances)
    
    # Calculate sigma as the median or a chosen percentile
    sigma = np.percentile(sorted_distances, percentiles[0])
    
   
    return sigma


def distance_to_similarity_matrix(distance_matrix):
    """
    Convert a distance matrix to a similarity matrix using Gaussian kernel.
    
    Parameters:
    - distance_matrix (np.ndarray): Distance matrix (n x n).
    - sigma (float): Gaussian kernel sigma.
    - show_plot (bool): If True, display histogram of similarities.
    
    Returns:
    - similarity_matrix (np.ndarray): Converted similarity matrix.
    """
    sigma = calculate_sigma_from_distances(distance_matrix)
    
    similarity_matrix = np.exp(-np.square(distance_matrix) / (2 * sigma ** 2))
   

    return similarity_matrix

class CustomAffinityPropagation(BaseEstimator, ClusterMixin):
    def __init__(self, damping=0.9, preference=None):
        """
        Custom Affinity Propagation clustering estimator.

        Parameters:
        - damping (float): Damping factor between 0.5 and 1. Used to avoid numerical oscillations.
        - preference (float or None): Preference for each point to be chosen as an exemplar.
                                      If None, the median of the input similarities is used.
        """
        self.damping = damping
        self.preference = preference

    def fit(self, X, y=None):
        """
        Fit the Affinity Propagation model using the precomputed distance matrix.

        Parameters:
        - X (ndarray): Precomputed distance matrix of shape (n_samples, n_samples).
        - y: Ignored.

        Returns:
        - self
        """
        self.distance_matrix_ = X

        # Compute similarity matrix (negative distance)
        #self.similarity_matrix_ = -self.distance_matrix_
         # To avoid division by zero, add a small epsilon
        epsilon = 1e-8
        #similarity_matrix = 1 / (self.distance_matrix_ + epsilon)
        #similarity_matrix = -self.distance_matrix_
        similarity_matrix = distance_to_similarity_matrix(self.distance_matrix_)
        # Initialize AffinityPropagation with provided parameters
        try:
            self.model_ = AffinityPropagation(
                affinity='precomputed',
                damping=self.damping,
                preference=self.preference,
                random_state=42
            )
            self.labels_ = self.model_.fit_predict(similarity_matrix)

            # Retrieve cluster centers indices directly from the model
            self._cluster_centers_indices_ = self.model_.cluster_centers_indices_

            # Identify unique clusters excluding noise (-1), though AffinityPropagation does not assign -1
            unique_labels = set(self.labels_)
            unique_labels.discard(-1)  # Not necessary for AffinityPropagation, kept for consistency

            # Set cluster centers using the inherent cluster_centers_indices_
            self.set_cluster_centers_indices(unique_labels)

            # Set outlier thresholds based on cluster centers
            self.set_outlier_thresholds(unique_labels)

            # Compute overall outlier ratio in the training data
            # Since AffinityPropagation does not inherently identify outliers, outlier_ratio_ is based on thresholding
            self.outlier_ratio_ = np.sum(self._compute_outlier_mask()) / len(self.labels_)
        except Exception as e:
            print(f"Error during fitting: {e}")
            raise e

        return self

    def set_cluster_centers_indices(self, unique_labels):
        """
        Determine and store cluster center indices.

        Parameters:
        - unique_labels (set): Set of unique cluster labels excluding noise.
        """
        # return
        cluster_centers_indices_ = {}
        for label in unique_labels:
         #     # AffinityPropagation assigns each cluster label to a unique cluster center
         #     # Find the index of the cluster center for this label
            center_idx = self._cluster_centers_indices_[label]
            cluster_centers_indices_[label] = center_idx
        self._cluster_centers_indices_ = cluster_centers_indices_

    def set_outlier_thresholds(self, unique_labels):
        """
        Determine and store outlier thresholds for each cluster.

        Parameters:
        - unique_labels (set): Set of unique cluster labels excluding noise.
        """
        self.outlier_thresholds_ = {}
        for label in unique_labels:
            medoid_idx = self._cluster_centers_indices_[label]
            cluster_mask = self.labels_ == label
            # Distances from points in the cluster to the medoid
            distances_to_medoid = self.distance_matrix_[cluster_mask, medoid_idx]
            # Define the threshold as the 95th percentile of distances
            threshold = np.percentile(distances_to_medoid, 95)
            self.outlier_thresholds_[label] = threshold

    def _compute_outlier_mask(self):
        """
        Compute a boolean mask indicating which samples are outliers based on thresholds.

        Returns:
        - outlier_mask (ndarray): Boolean array where True indicates an outlier.
        """
        outlier_mask = np.zeros(len(self.labels_), dtype=bool)
        for label, medoid_idx in self._cluster_centers_indices_.items():
            cluster_mask = self.labels_ == label
            distances_to_medoid = self.distance_matrix_[cluster_mask, medoid_idx]
            threshold = self.outlier_thresholds_.get(label, np.inf)
            outliers = distances_to_medoid > threshold
            outlier_mask[cluster_mask] = outliers
        return outlier_mask

    def predict(self, X, check_outliers=True):
        """
        Predict cluster labels for new data based on the distance to cluster centers.

        Parameters:
        - X (ndarray): Distance matrix of shape (n_samples_new, n_clusters).
                       Each column corresponds to a cluster center.
        - check_outliers (bool): Whether to check for outliers based on thresholds.

        Returns:
        - labels (ndarray): Cluster labels for each sample. Outliers are marked as -1.
        """
        check_is_fitted(self, ['cluster_centers_indices_', 'outlier_thresholds_'])

        # Assign each sample to the nearest cluster center
        labels = np.argmin(X, axis=1)

        if check_outliers:
            # Retrieve the minimal distance for each sample
            min_distances = X[np.arange(X.shape[0]), labels]
            # Retrieve corresponding cluster labels
            cluster_labels = list(self._cluster_centers_indices_.keys())
            assigned_cluster_labels = [cluster_labels[label] for label in labels]
            # Retrieve thresholds for assigned clusters
            thresholds = np.array([self.outlier_thresholds_.get(label, np.inf) for label in assigned_cluster_labels])
            # Identify outliers
            outliers = min_distances > thresholds
            labels[outliers] = -1

        return labels
    @property
    def cluster_centers_indices_(self):
        """
        Get the indices of cluster centers (medoids).

        Returns:
        - centers: dict
            Dictionary mapping cluster labels to medoid indices.
        """
        if not hasattr(self, '_cluster_centers_indices_'):
            raise AttributeError("The cluster_centers_indices_ attribute is not set.")
        return list(self._cluster_centers_indices_.values()) 
    @cluster_centers_indices_.setter
    def cluster_centers_indices_(self, value):
        self._cluster_centers_indices_ = value
    
    def fit_predict(self, X, y=None):
        """
        Fit the model and predict the cluster labels for the training data.

        Parameters:
        - X (ndarray): Precomputed distance matrix of shape (n_samples, n_samples).
        - y: Ignored.

        Returns:
        - labels (ndarray): Cluster labels for each sample.
        """
        self.fit(X)
        # Apply outlier thresholds to training data
        outlier_mask = self._compute_outlier_mask()
        labels = self.labels_.copy()
        labels[outlier_mask] = -1
        self.outlier_ratio_ = np.sum(labels == -1) / len(labels)
        self.labels_ = labels
        return self.labels_

    def get_params(self, deep=True):
        """
        Get parameters for this estimator.

        Parameters:
        - deep (bool): If True, will return the parameters for this estimator and
                       contained subobjects that are estimators.

        Returns:
        - params (dict): Parameter names mapped to their values.
        """
        return {'damping': self.damping, 'preference': self.preference}

    def set_params(self, **params):
        """
        Set the parameters of this estimator.

        Parameters:
        - **params: dict
            Estimator parameters.

        Returns:
        - self: Estimator instance.
        """
        for key, value in params.items():
            setattr(self, key, value)
        return self