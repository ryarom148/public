import numpy as np
from sklearn.base import BaseEstimator, ClusterMixin
from sklearn.cluster import DBSCAN
from sklearn.utils.validation import check_is_fitted

import warnings

warnings.filterwarnings("ignore")


class CustomDBSCAN(BaseEstimator, ClusterMixin):
    def __init__(self, eps=0.5, min_samples=5):
        """
        Custom DBSCAN clustering estimator.

        Parameters:
        - eps (float): The maximum distance between two samples for one to be considered
                       as in the neighborhood of the other.
        - min_samples (int): The number of samples in a neighborhood for a point to be considered
                             as a core point.
        """
        self.eps = eps
        self.min_samples = min_samples

    def fit(self, X, y=None):
        """
        Fit the DBSCAN model using the precomputed distance matrix.

        Parameters:
        - X (ndarray): Precomputed distance matrix of shape (n_samples, n_samples).
        - y: Ignored.

        Returns:
        - self
        """
        self.distance_matrix_ = X
        self.model_ = DBSCAN(
            metric='precomputed',
            eps=self.eps,
            min_samples=self.min_samples
        )
        self.labels_ = self.model_.fit_predict(self.distance_matrix_)

        # Identify unique clusters excluding noise (-1)
        unique_labels = set(self.labels_)
        unique_labels.discard(-1)

        # Set cluster centers
        self.set_cluster_centers_indices(unique_labels)

        # Set outlier thresholds
        self.set_outlier_thresholds(unique_labels)

        # Compute overall outlier ratio in the training data
        self.outlier_ratio_ = np.sum(self.labels_ == -1) / len(self.labels_)

        return self

    def set_cluster_centers_indices(self, unique_labels):
        """
        Determine and store cluster center indices.

        Parameters:
        - unique_labels (set): Set of unique cluster labels excluding noise.
        """
        self._cluster_centers_indices_ = {}
        for label in unique_labels:
            cluster_indices = np.where(self.labels_ == label)[0]
            if len(cluster_indices) == 0:
                continue
            # Extract the sub-distance matrix for the cluster
            sub_distance_matrix = self.distance_matrix_[np.ix_(cluster_indices, cluster_indices)]
            # Compute the sum of distances for each point in the cluster
            total_distances = sub_distance_matrix.sum(axis=1)
            # Identify the medoid (point with minimum total distance)
            medoid_idx = cluster_indices[np.argmin(total_distances)]
            self._cluster_centers_indices_[label] = medoid_idx

    def set_outlier_thresholds(self, unique_labels):
        """
        Determine and store outlier thresholds for each cluster.

        Parameters:
        - unique_labels (set): Set of unique cluster labels excluding noise.
        """
        self.outlier_thresholds_ = {}
        for label in unique_labels:
            medoid_idx = self._cluster_centers_indices_[label]
            cluster_mask = self.labels_ == label
            # Distances from points in the cluster to the medoid
            distances_to_medoid = self.distance_matrix_[cluster_mask, medoid_idx]
            # Define the threshold as the 95th percentile of distances
            threshold = np.percentile(distances_to_medoid, 95)
            self.outlier_thresholds_[label] = threshold

    def predict(self, X, check_outliers=True):
        """
        Predict cluster labels for new data based on the distance to cluster centers.

        Parameters:
        - X (ndarray): Distance matrix of shape (n_samples_new, n_clusters).
                       Each column corresponds to a cluster center.
        - check_outliers (bool): Whether to check for outliers based on thresholds.

        Returns:
        - labels (ndarray): Cluster labels for each sample. Outliers are marked as -1.
        """
        check_is_fitted(self, ['cluster_centers_indices_'])

        # Assign each sample to the nearest cluster center
        labels = np.argmin(X, axis=1)

        if check_outliers:
            # Retrieve the minimal distance for each sample
            min_distances = X[np.arange(X.shape[0]), labels]
            # Retrieve corresponding cluster labels
            cluster_labels = list(self._cluster_centers_indices_.keys())
            assigned_cluster_labels = [cluster_labels[label] for label in labels]
            # Retrieve thresholds for assigned clusters
            thresholds = np.array([self.outlier_thresholds_.get(label, np.inf) for label in assigned_cluster_labels])
            # Identify outliers
            outliers = min_distances > thresholds
            labels[outliers] = -1

        return labels
    @property
    def cluster_centers_indices_(self):
        """
        Get the indices of cluster centers (medoids).

        Returns:
        - centers: dict
            Dictionary mapping cluster labels to medoid indices.
        """
        if not hasattr(self, '_cluster_centers_indices_'):
            raise AttributeError("The cluster_centers_indices_ attribute is not set.")
        return list(self._cluster_centers_indices_.values()) 
    @cluster_centers_indices_.setter
    def cluster_centers_indices_(self, value):
        self._cluster_centers_indices_ = value

    def fit_predict(self, X, y=None):
        """
        Fit the model and predict the cluster labels for the training data.

        Parameters:
        - X (ndarray): Precomputed distance matrix of shape (n_samples, n_samples).
        - y: Ignored.

        Returns:
        - labels (ndarray): Cluster labels for each sample.
        """
        self.fit(X)
        return self.labels_

    def get_params(self, deep=True):
        """
        Get parameters for this estimator.

        Parameters:
        - deep (bool): If True, will return the parameters for this estimator and
                       contained subobjects that are estimators.

        Returns:
        - params (dict): Parameter names mapped to their values.
        """
        return {'eps': self.eps, 'min_samples': self.min_samples}

    def set_params(self, **params):
        """
        Set the parameters of this estimator.

        Parameters:
        - **params: dict
            Estimator parameters.

        Returns:
        - self: Estimator instance.
        """
        for key, value in params.items():
            setattr(self, key, value)
        return self