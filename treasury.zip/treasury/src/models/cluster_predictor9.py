import numpy as np
from typing import List, Optional, Dict, Any
from sklearn.base import BaseEstimator, ClusterMixin
from sklearn.utils.validation import check_is_fitted
from sklearn.metrics import make_scorer, silhouette_score, calinski_harabasz_score, davies_bouldin_score
from joblib import Parallel, delayed
import hashlib
import os
import time
import joblib
import logging
from clustering.customAgglomerativeClustering import CustomAgglomerativeClustering
from clustering.customAffinityPropagation import CustomAffinityPropagation
from clustering.customDBSCAN import CustomDBSCAN
from clustering.customChineseWhispers import CustomChineseWhispers
from clustering.customOptics import CustomOPTICS
from clustering.optimizer import TimeSeriesClusterOptimizer
from cluster_utility import distance_to_similarity_matrix
from tslearn.metrics import cdist_dtw, cdist_soft_dtw
from aeon.distances import (
    dtw_distance, lcss_distance, erp_distance,
    edr_distance, msm_distance, twe_distance
)
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

class TimeSeriesClusterPredictor():
    def __init__(
        self,
        algorithm: str = 'ChineseWhispers',
        algorithms_param: Optional[Dict[str, Any]] = None,
        distance: str = 'dtw',
        distance_params: Optional[Dict[str, Any]] = None,

        n_jobs: int = -1,
       # optimization_metric: str = 'combined',  # Options: 'combined', 'silhouette', 'calinski_harabasz', 'davies_bouldin'
        verbose: int = 1
    ):
        """
        Initialize the TimeSeriesClusterPredictor.
        
        Parameters:
        - clustering_algorithms (dict): Dictionary mapping algorithm names to their classes.
        - distance (str): Distance metric to use.
        - distance_params (dict): Additional parameters for distance functions.
        - grid_search_method (str): Grid search method to use ('GridSearchCV', 'HalvingGridSearchCV', 'BayesSearchCV').
        - n_jobs (int): Number of parallel jobs.
        - optimization_metric (str): Metric to optimize ('combined', 'silhouette', 'calinski_harabasz', 'davies_bouldin').
        - verbose (int): Verbosity level.
        """
        self.clustering_algorithms = {
            'AgglomerativeClustering': CustomAgglomerativeClustering,
            'AffinityPropagation': CustomAffinityPropagation,
            'DBSCAN': CustomDBSCAN,
            'OPTICS': CustomOPTICS,
            'ChineseWhispers': CustomChineseWhispers
        }
        self.distance = distance
        self.distance_params = distance_params
        self.algorithm = algorithm
        self.algorithms_param = algorithms_param
        self.n_jobs = n_jobs
        self.verbose = verbose
        
        # Define distance metrics
        self.distance_metrics = {
            'dtw': dtw_distance,
            'softdtw': cdist_soft_dtw,
            'euclidean': 'euclidean',
            'lcss': lcss_distance,
            'erp': erp_distance,
            'edr': edr_distance,
            'msm': msm_distance,
            'twe': twe_distance,
        }
        
        # Initialize logger
        self.logger = logging.getLogger(self.__class__.__name__)
        if not self.logger.handlers:
            # Prevent adding multiple handlers in interactive environments
            handler = logging.StreamHandler()
            formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
            handler.setFormatter(formatter)
            self.logger.addHandler(handler)
            self.logger.setLevel(logging.INFO)
        
        # Initialize dictionaries to store best estimators and scores
        self.best_estimators_ = {}
        self.best_scores_ = {}
    
    def _cdist_generic(self, dist_fun, dataset1, dataset2=None) -> np.ndarray:
        """Generic parallel distance computation."""
        if dataset2 is None:
            matrix = np.zeros((len(dataset1), len(dataset1)))
            indices = np.triu_indices(len(dataset1), k=0)
            
            matrix[indices] = Parallel(n_jobs=self.n_jobs, prefer="threads")(
                delayed(dist_fun)(dataset1[i], dataset1[j], **self.distance_params)
                for i in range(len(dataset1))
                for j in range(i, len(dataset1))
            )
            
            indices_lower = np.tril_indices(len(dataset1), k=-1)
            matrix[indices_lower] = matrix.T[indices_lower]
            return matrix
        else:
            distances = Parallel(n_jobs=self.n_jobs, prefer="threads")(
                delayed(dist_fun)(dataset1[i], dataset2[j], **self.distance_params)
                for i in range(len(dataset1))
                for j in range(len(dataset2))
            )
            return np.reshape(distances, (len(dataset1), len(dataset2)))
    
    def compute_distance_matrix(self, X: List[np.ndarray]) -> np.ndarray:
        """Compute distance matrix with caching."""
        params_str = '_'.join(f"{k}:{v}" for k, v in sorted(self.distance_params.items()))
        params_hash = hashlib.md5(params_str.encode()).hexdigest()
        cache_dir = 'distance_matrices'
        cache_path = os.path.join(cache_dir, f"{self.distance}_{params_hash}.pkl")
        os.makedirs(cache_dir, exist_ok=True)
    
        if os.path.exists(cache_path):
            self.logger.info("Loading cached distance matrix")
            distance_matrix = joblib.load(cache_path)
        else:
            self.logger.info(f"Computing distance matrix using {self.distance}")
            start_time = time.time()
    
            if self.distance == 'dtw':
                distance_matrix = cdist_dtw(X, n_jobs=self.n_jobs, **self.distance_params)
            elif self.distance == 'softdtw':
                distance_matrix = cdist_soft_dtw(X, **self.distance_params)
            else:
                dist_func = self.distance_metrics.get(self.distance)
                if dist_func is None:
                    raise ValueError(f"Unsupported distance metric: {self.distance}")
                distance_matrix = self._cdist_generic(dist_func, X)
    
            elapsed_time = time.time() - start_time
            self.logger.info(f"Distance matrix computed in {elapsed_time:.2f} seconds")
            joblib.dump(distance_matrix, cache_path)
        
        self.distance_matrix_ = distance_matrix
        return distance_matrix
    
    def _compute_distances_to_centers(self, X: List[np.ndarray], centers: List[np.ndarray]) -> np.ndarray:
        """Compute distances between samples and given cluster centers."""
        if self.distance == 'dtw':
            return cdist_dtw(X, centers, n_jobs=self.n_jobs, **self.distance_params)
        elif self.distance == 'softdtw':
            return cdist_soft_dtw(X, centers, **self.distance_params)
        else:
            dist_func = self.distance_metrics.get(self.distance)
            if dist_func is None:
                raise ValueError(f"Unsupported distance metric: {self.distance}")
            return self._cdist_generic(dist_func, X, centers)
    
   
    def fit(self, X_train: List[np.ndarray]):
        """
        Fit all clustering algorithms on the training data.
        
        Parameters:
        - X_train: List of training time series (each as a NumPy array).
        
        Returns:
        - self
        """
        self.logger.info("Starting to fit clustering algorithms.")
        #self.X_train = X_train
        
        # Compute distance matrix for training data
        distance_matrix_train = self.compute_distance_matrix(X_train)
        
        
        # Store distance and similarity matrices for parameter grid generation
        self.distance_matrix_train_ = distance_matrix_train
        # self.similarity_matrix_train_ = similarity_matrix
        
        # Initialize storage for cluster centers
        self.cluster_centers_ = None
        
        # Fit each clustering algorithm
        estimator = self.clustering_algorithms[self.algorithm]
        estimator.fit(distance_matrix_train)
        
        # Identify cluster centers if applicable
        if hasattr(estimator, 'cluster_centers_indices_'):
            centers_indices = estimator.cluster_centers_indices_
            self.cluster_centers_ = X_train[centers_indices]
           
            self.logger.info(f"{self.algorithm}: Identified {len(self.cluster_centers_)} cluster centers.")
        else:
            self.cluster_centers_ = None
            self.logger.info(f"{self.algorithm}: No cluster centers identified.")
        if hasattr(estimator, 'labels_'):
             self.labels_ = estimator.labels_
        self.estimator = estimator
        self.logger.info("Fitting of clustering algorithms completed.")
        return self
    
    def predict(self, X_unseen: List[np.ndarray]) -> np.ndarray:
        """
        Predict cluster labels for unseen time series using the specified algorithm.
        
        Parameters:
        - X_unseen: List of unseen time series (each as a NumPy array).
        
        
        Returns:
        - labels: NumPy array of cluster labels for each unseen time series. Outliers are marked as -1.
        """
        self.logger.info(f"Starting prediction using {self.algorithm}.")
        if self.estimator is None:
            raise ValueError(f"Algorithm '{self.algorithm}' has not been fitted .")
        
        
        # Compute distances between unseen samples and cluster centers
        distance_matrix_centers = self._compute_distances_to_centers(X_unseen, self.cluster_centers_)
         # Predict labels
        labels = self.estimator.predict(distance_matrix_centers)
        
        self.logger.info(f"Prediction completed using {self.algorithm}.")
        return labels
    
    def score(
        self,
        predicted_lables: Optional[List[str]] = None
       
    ) -> Dict[str, Any]:
        """
        Compute optimization score for the specified algorithm.
        
        Parameters:
        - predicted_lables (Optional[List[str]]): List of predicted labels for unseen data.
       
        Returns:
        - -> Dict[str, Any]: Variouse  metrics.
        """
        self.logger.info(f"Computing optimization score for {self.algorithm}.")
                      
        # Compute clustering metrics
        ## silhouette can accept distance matrix
        silhouette = silhouette_score(self.distance_matrix_, self.labels_, metric='precomputed')
         ## calinski_harabasz and  davies_bouldin have to accept list of time series accept distance matrix
        calinski_harabasz = calinski_harabasz_score(self.X_train, self.labels_)
        davies_bouldin = davies_bouldin_score(self.X_train, self.labels_)
        davies_bouldin_normalized = 1 / (1 + davies_bouldin)
        calinski_harabasz_normalized = 1-1/calinski_harabasz
        combined_score = (0.4*silhouette + 0.3* calinski_harabasz_normalized + 0.3* davies_bouldin_normalized)
        train_outlier_ratio = np.sum(self.labels == -1) / len(self.labels)
        #print("outlier train:", outlier_ratio)
            # Adjust combined score
        combined_score *= (1 - train_outlier_ratio)
        
        # Adjust score based on outlier ratio from X_test if provided
        if predicted_lables is  not None:
            # Compute distance matrix for test data
           
            test_labels = predicted_lables
            # Compute outlier ratio
            outlier_ratio = np.sum(test_labels == -1) / len(test_labels)
            # Adjust combined score
            combined_score *= (1 - outlier_ratio)
        
        self.logger.info(f"Computed optimization score for {self.algorithm}: {combined_score:.4f}")
        scores = {}
        scores['clusters'] = len(self.cluster_centers_)
        scores['combined'] = combined_score
        scores['silhouette'] = silhouette
        scores['calinski_harabasz'] = calinski_harabasz
        scores['davies_bouldin'] = davies_bouldin
        scores['train_outliers_ratio'] = train_outlier_ratio
        if predicted_lables is not None:
            scores['test_outliers_ratio'] = outlier_ratio

        print (f'number of clusters:{len(self.cluster_centers_)}')                        
        print (f'combined score:{combined_score}')
        print (f'silhouette score:{silhouette}')
        print (f'calinski_harabasz score:{calinski_harabasz}')
        print (f'davies_bouldin score:{calinski_harabasz}')
        print (f'train_outliers_ratio:{train_outlier_ratio}')
        print (f'test_outliers_ratio:{outlier_ratio}')
        
        return scores
    



    def find_best_parameters(
        self,
        X_train: List[np.ndarray],
        X_test: Optional[List[np.ndarray]] = None,
        algorithms: Optional[List[str]] = None,
        search_method: Optional[str] = "Nevergrad",
    ) -> Dict[str, Any]:
        """
        Find the best hyperparameters for each clustering algorithm using grid search or nevergrad
        and generate comparison charts for metrics and cluster distribution for each algorithm.

        Parameters:
        - X_train (List[np.ndarray], optional): List of train time series.
        - X_test (List[np.ndarray], optional): List of test time series for outlier ratio computation.
        - algorithms (List[str], optional): List of algorithm names to tune. If None, tune all.
        - search_method (str, optional): Grid search method to use ('GridSearchCV', 'Nevergrad').

        Returns:
        - best_algorithm (dict): Dictionary containing the best overall algorithm and its associated details.
        """
        self.logger.info("Starting hyperparameter tuning for clustering algorithms.")
        
        optime = TimeSeriesClusterOptimizer(
            X_train=X_train,
            distance=self.distance,
            distance_params=self.distance_params,
            X_test=X_test,
            n_jobs=-1,
            optimization_metric='combined',
            verbose=0
        )

        best_results = optime.find_best_parameters(
            algorithms=algorithms,
            grid_search_method=search_method,
            cv=2
        )

        best_estimators = best_results['best_estimators']
        best_scores = best_results['best_scores']

        # Identify the best overall algorithm based on combined score
        best_algorithm_name = max(best_scores, key=best_scores.get)
        best_algorithm = best_estimators[best_algorithm_name]
        best_score = best_scores[best_algorithm_name]

        # For plotting metrics comparison
        metric_data = []
        cluster_distribution_data = []
        outlier_ratios = {}

        # Collect metrics and distribution data for all algorithms
        for name, estimator in best_estimators.items():
            labels = estimator.labels_

            # Collect the clustering metrics
            silhouette = silhouette_score(estimator.distance_matrix_, labels, metric='precomputed')
            calinski_harabasz = calinski_harabasz_score(X_train, labels)
            davies_bouldin = davies_bouldin_score(X_train, labels)
            
            # Calculate outlier ratio for train data
            outlier_ratio_train = np.sum(labels == -1) / len(labels)

            # If test data is available, calculate outlier ratio for test data
            if X_test is not None:
                distance_matrix_test = optime._compute_distances_to_centers(X_test, X_train[estimator.cluster_centers_indices_])
                test_labels = estimator.predict(distance_matrix_test)
                outlier_ratio_test = np.sum(test_labels == -1) / len(test_labels)
            else:
                outlier_ratio_test = None

            # Store train and test outlier ratios in a dictionary
            outlier_ratios[name] = {
                "train": outlier_ratio_train,
                "test": outlier_ratio_test
            }

            # Add metrics to the data for the comparison chart
            metric_data.extend([
                {"Algorithm": name, "Metric": "Combined Score", "Score": best_scores[name], "Normalized": best_scores[name] / max(1, best_scores[name])},
                {"Algorithm": name, "Metric": "Silhouette Score", "Score": silhouette, "Normalized": silhouette / max(1, silhouette)},
                {"Algorithm": name, "Metric": "Calinski-Harabasz", "Score": calinski_harabasz, "Normalized": 1 - 1 / calinski_harabasz},
                {"Algorithm": name, "Metric": "Davies-Bouldin", "Score": davies_bouldin, "Normalized": 1 / (1 + davies_bouldin)},
            ])

            # Calculate cluster distribution for train data
            unique, counts = np.unique(labels, return_counts=True)
            total_train = len(labels)
            
            for cluster, count in zip(unique, counts):
                if cluster == -1:
                    cluster_name = "Outliers"
                else:
                    cluster_name = f"Cluster {cluster}"
                    
                percentage = (count / total_train) * 100
                cluster_distribution_data.append({
                    "Algorithm": name,
                    "Cluster": cluster_name,
                    "Count": count,
                    "Percentage": percentage
                })

            # Add annotation details for train and test outlier ratios
            outlier_test_text = f"{outlier_ratio_test:.2%}" if outlier_ratio_test is not None else "N/A"
            annotation_text = (
                f"Outlier Ratio (Train): {outlier_ratio_train:.2%}\n"
                f"Train Time Series: {len(X_train)}, Test Time Series: {len(X_test) if X_test is not None else -1}\n"
                f"Outlier Ratio (Test): {outlier_test_text}\n"
                f"Combined Score: {best_scores[name]:.4f}\n"
                f"Silhouette Score: {silhouette:.4f}\n"
                f"Calinski-Harabasz Score: {calinski_harabasz:.2f}\n"
                f"Davies-Bouldin Score: {davies_bouldin:.4f}"
            )   

            # Plotting cluster distribution for each algorithm
            cluster_dist_df = pd.DataFrame([d for d in cluster_distribution_data if d["Algorithm"] == name])
            plt.figure(figsize=(12, 6))
            sns.barplot(data=cluster_dist_df, x="Cluster", y="Percentage")
            plt.title(f"{name} - Best Parameters: {estimator.get_params()}\n{annotation_text}")
            plt.ylabel("Percentage of Total Time Series")
            plt.xlabel("Clusters")
            for i, (count, percentage) in enumerate(zip(cluster_dist_df["Count"], cluster_dist_df["Percentage"])):
                plt.text(i, percentage + 1, f"{count} ({percentage:.1f}%)", ha='center', fontsize=9)
            plt.tight_layout()
            plt.show()

        # Plotting the metrics comparison for all algorithms
        metric_df = pd.DataFrame(metric_data)
        plt.figure(figsize=(14, 8))
        sns.set(style="whitegrid")

        # Create the categorical plot
        catplot = sns.catplot(
            data=metric_df,
            x="Metric",
            y="Normalized",
            hue="Algorithm",
            kind="bar",
            height=6,
            aspect=1.5,
            legend_out=True
        )

        # Extract and format cluster, outlier ratio, and test data outlier ratio info for subtitle
       # Generate subtitle text with separate handling for None check
        subtitle_text = "\n".join(
            f"{algorithm}: Clusters: {len(set(labels)) - (1 if -1 in labels else 0)}, "
            f"Outlier Ratio (Train): {outlier_ratios[algorithm]['train']:.2%}, "
            f"Outlier Ratio (Test): {f'{outlier_ratios[algorithm]['test']:.2%}' if outlier_ratios[algorithm]['test'] is not None else 'N/A'}"
            for algorithm in best_estimators.keys()
            )

        # Adjust title, subtitle, and layout
        plt.suptitle(
            f"Score Comparison by Metric\nDistance: {self.distance} ({self.distance_params})",
            fontsize=16,
            fontweight='bold',
            y=1.05
        )
        plt.title(subtitle_text, fontsize=10, y=1.02)
        plt.ylim(0, 1.1)
        plt.xlabel("Metric", fontsize=14)
        plt.ylabel("Normalized Score", fontsize=14)
        plt.xticks(fontsize=12)
        plt.yticks(fontsize=12)

        # Iterate over the data points in `metric_df` to annotate each bar with the actual score
        for p, (_, row) in zip(catplot.ax.patches, metric_df.iterrows()):
            score = row["Score"]
            
            # Add score as label on the bar
            catplot.ax.annotate(
                f"{score:.2f}",
                (p.get_x() + p.get_width() / 2, p.get_height()),
                ha='center',
                va='bottom',
                fontsize=9,
                color="black",
                fontweight='bold'
            )

        # Adjust legend position for clarity
        plt.legend(title="Algorithm", bbox_to_anchor=(1.05, 1), loc='upper left', fontsize=12, title_fontsize='13')

        plt.tight_layout()
        plt.show()

        return {
            'best_algorithm_name': best_algorithm_name,
            'best_algorithm': best_algorithm,
            'best_score': best_score,
            'metric_data': metric_data,
            'cluster_distribution_data': cluster_distribution_data
        }


import numpy as np
from sklearn.datasets import make_blobs
from sklearn.preprocessing import StandardScaler
import time
import pandas as pd
from sklearn.metrics import adjusted_rand_score, adjusted_mutual_info_score
import matplotlib.pyplot as plt
import seaborn as sns
# Generate synthetic time series data
def generate_synthetic_data(n_samples=90, n_features=100, n_clusters=5, random_state=42):
    np.random.seed(random_state)
    X = []
    labels = []
    t = np.linspace(0, 4 * np.pi, n_features)
    
    # Define distinct patterns for each cluster
    patterns = []
    for i in range(n_clusters):
        phase_shift = i * np.pi / 2  # Phase shift to separate clusters
        amplitude = 1 + i * 0.5      # Different amplitude for each cluster
        frequency = 1 + i * 0.2      # Different frequency for each cluster
        pattern = amplitude * np.sin(frequency * t + phase_shift)
        patterns.append(pattern)
    
    # Generate data for each cluster
    samples_per_cluster = n_samples // n_clusters
    for i in range(n_clusters):
        pattern = patterns[i]
        for _ in range(samples_per_cluster):
            noise = np.random.normal(0, 0.2, n_features)  # Adjusted noise level
            X.append(pattern + noise)
            labels.append(i)
    
    X = np.array(X)
    labels = np.array(labels)
    return X, labels    

def main():
    # Generate synthetic dataset with known clusters
    # Step 1: Generate synthetic time series data
    X_train, labels_true = generate_synthetic_data(n_samples=1000, n_features=100, n_clusters=17,random_state=24)
    X_test, y_test_true = generate_synthetic_data(n_samples=100, n_features=100, n_clusters=17, random_state=24)

  
    # Initialize the predictor with all clustering algorithms
# clustering_algorithms={
#         'AgglomerativeClustering': CustomAgglomerativeClustering,
#         'AffinityPropagation': CustomAffinityPropagation,
#         'DBSCAN': CustomDBSCAN,
#         'OPTICS': CustomOPTICS,
#         'ChineseWhispers': CustomChineseWhispers
#     },
    cluster_predctor = TimeSeriesClusterPredictor(distance='dtw',
                    distance_params={'global_constraint': 'sakoe_chiba', 'sakoe_chiba_radius': 3})
   
    
    best_results = cluster_predctor.find_best_parameters(
                X_train=X_train,
                X_test=X_test,
                algorithms = None,# None, ,'DBSCAN' #['AffinityPropagation'],'AgglomerativeClustering''AgglomerativeClustering',  # None implies tuning all supported algorithms
                search_method ='GridSearchCV', #'Nevergrad', #'Nevergrad',  # Can also be 'GridSearchCV' or 'BayesSearchCV'
                )

   

if __name__ == "__main__":
    main()