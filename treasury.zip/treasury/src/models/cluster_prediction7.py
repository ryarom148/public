
import numpy as np
import joblib
from joblib import Parallel, delayed, dump, load
from sklearn.base import BaseEstimator, ClusterMixin
from sklearn.metrics import silhouette_score, calinski_harabasz_score, davies_bouldin_score
from tslearn.metrics import cdist_dtw, cdist_soft_dtw
import aeon
from aeon.distances import (dtw_distance, lcss_distance, erp_distance,
                            edr_distance, msm_distance, twe_distance)
from aeon.clustering import TimeSeriesKMeans, TimeSeriesKMedoids
from sklearn.cluster import AgglomerativeClustering, DBSCAN, OPTICS, AffinityPropagation
from chinese_whispers import chinese_whispers, aggregate_clusters
import networkx as nx
from typing import Dict, List, Union, Optional, Callable
import os
import hashlib
import logging
import time
from sklearn.utils.validation import check_is_fitted
from chi_whisper import ChineseWhispersClustering
from sklearn.datasets import make_blobs


logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)
aeon.AEON_DEPRECATION_WARNING = False
os.environ['AEON_DEPRECATION_WARNING'] = 'False'

class TimeSeriesClusterPredictor(BaseEstimator, ClusterMixin):
    def __init__(
        self,
        n_jobs: int = -1,
        random_state: Optional[int] = None,
        distance: Union[str, Callable] = 'dtw',
        distance_params: Optional[Dict] = None,
        algorithm: str = 'kmeans',
        algo_params: Optional[Dict] = None,
        optimization_metric: str = 'combined'
    ):
        self.n_jobs = n_jobs
        self.random_state = random_state
        self.distance = distance
        self.distance_params = distance_params if distance_params is not None else {}
        self.algorithm = algorithm
        self.algo_params = algo_params if algo_params is not None else {}
        self.optimization_metric = optimization_metric

        self.distance_metrics = {
            'dtw': dtw_distance,
            'softdtw': cdist_soft_dtw,
            'euclidean': 'euclidean',
            'lcss': lcss_distance,
            'erp': erp_distance,
            'edr': edr_distance,
            'msm': msm_distance,
            'twe': twe_distance,
        }

        self.clustering_algorithms = {
            'kmeans': TimeSeriesKMeans,
            'kmedoids': TimeSeriesKMedoids,
            'agglomerative': AgglomerativeClustering,
            'dbscan': DBSCAN,
            'optics': OPTICS,
            'affinity_propagation': AffinityPropagation,
            'chinese_whispers': ChineseWhispersClustering
        }

        if isinstance(self.distance, str) and self.distance not in self.distance_metrics:
            raise ValueError(f"Unsupported distance metric: {self.distance}")
        if self.algorithm not in self.clustering_algorithms:
            raise ValueError(f"Unsupported clustering algorithm: {self.algorithm}")

        # Initialize state
        self.labels_ = None
        self.cluster_centers_ = None
        self.distance_matrix_cache = None
        self.outlier_threshold = None
        self.X_fit_ = None

    def get_params(self, deep=True):
        """
        Get parameters for this estimator.
        
        Parameters:
        -----------
        deep : bool, default=True
            If True, will return the parameters for this estimator and contained
            subobjects that are estimators.
            
        Returns:
        --------
        params : dict
            Parameter names mapped to their values.
        """
        params = {
            'n_jobs': self.n_jobs,
            'random_state': self.random_state,
            'distance': self.distance,
            'algorithm': self.algorithm,
            'optimization_metric': self.optimization_metric
        }
        
        # Add distance parameters with prefix
        if self.distance_params:
            for key, value in self.distance_params.items():
                params[f'distance_params__{key}'] = value
                
        # Add algorithm parameters with prefix
        if self.algo_params:
            for key, value in self.algo_params.items():
                params[f'algo_params__{key}'] = value
                
        return params


    def set_params(self, **params):
        """
        Set the parameters of this estimator.
        
        Parameters:
        -----------
        **params : dict
            Estimator parameters.
            
        Returns:
        --------
        self : estimator instance
            Returns self.
        """
        distance_params = {}
        algo_params = {}
        
        valid_params = self.get_params()
        
        for key, value in params.items():
            if key.startswith('distance_params__'):
                param_name = key.split('__')[1]
                distance_params[param_name] = value
            elif key.startswith('algo_params__'):
                param_name = key.split('__')[1]
                algo_params[param_name] = value
            # elif key not in valid_params:
            #     raise ValueError(f'Invalid parameter {key} for estimator {self.__class__.__name__}')
            else:
                setattr(self, key, value)
        
        # Update parameter dictionaries if they were modified
        if distance_params:
            self.distance_params = distance_params
        if algo_params:
            self.algo_params = algo_params
        
        return self
    
    def _cdist_generic(self, dist_fun, dataset1, dataset2=None) -> np.ndarray:
        """
        Generic parallel distance computation between time series.
        
        Parameters:
        -----------
        dist_fun : callable
            Distance function to use
        dataset1 : array-like, shape=(n_ts1, sz1, d) or (n_ts1, sz1)
            First dataset of time series
        dataset2 : array-like, optional, shape=(n_ts2, sz2, d) or (n_ts2, sz2)
            Second dataset of time series. If None, compute self-similarity of dataset1
        
        Returns:
        --------
        distances : np.ndarray
            Distance matrix
        """
        if dataset2 is None:
            # Self-similarity case
            matrix = np.zeros((len(dataset1), len(dataset1)))
            indices = np.triu_indices(len(dataset1), k=0)
            
            matrix[indices] = Parallel(n_jobs=self.n_jobs, prefer="threads")(
                delayed(dist_fun)(dataset1[i], dataset1[j], **self.distance_params)
                for i in range(len(dataset1))
                for j in range(i, len(dataset1))
            )
            
            # Fill lower triangular part
            indices_lower = np.tril_indices(len(dataset1), k=-1)
            matrix[indices_lower] = matrix.T[indices_lower]
            
            return matrix
        else:
            # Paired distance case
            distances = Parallel(n_jobs=self.n_jobs, prefer="threads")(
                delayed(dist_fun)(dataset1[i], dataset2[j], **self.distance_params)
                for i in range(len(dataset1))
                for j in range(len(dataset2))
            )
            return np.reshape(distances, (len(dataset1), len(dataset2)))

    def compute_distance_matrix(self, X: np.ndarray) -> np.ndarray:
        """Compute distance matrix with caching."""
        # Generate cache path
        params_str = '_'.join(f"{k}:{v}" for k, v in sorted(self.distance_params.items()))
        params_hash = hashlib.md5(params_str.encode()).hexdigest()
        cache_path = os.path.join('distance_matrices', f"{self.distance}_{params_hash}.pkl")
        os.makedirs(os.path.dirname(cache_path), exist_ok=True)
        
        if os.path.exists(cache_path):
            logger.info(f"Loading cached distance matrix")
            return joblib.load(cache_path)

        logger.info(f"Computing distance matrix using {self.distance}")
        start_time = time.time()
        
        # Handle different distance metrics
        if self.distance == 'dtw':
            matrix = cdist_dtw(X, n_jobs=self.n_jobs, **self.distance_params)
        elif self.distance == 'softdtw':
            matrix = cdist_soft_dtw(X, **self.distance_params)
        else:
            dist_func = self.distance_metrics[self.distance]
            matrix = self._cdist_generic(dist_func, X)

        logger.info(f"Distance matrix computed in {time.time() - start_time:.2f} seconds")
        joblib.dump(matrix, cache_path)
        
        return matrix

    def _compute_distances_to_centers(self, X: np.ndarray) -> np.ndarray:
        """Compute distances between samples and cluster centers."""
        if not hasattr(self, 'cluster_centers_') or self.cluster_centers_ is None:
            raise ValueError("Cluster centers not computed yet. Call fit first.")

        # Handle different distance metrics
        if self.distance == 'dtw':
            return cdist_dtw(X, self.cluster_centers_, n_jobs=self.n_jobs, **self.distance_params)
        elif self.distance == 'softdtw':
            return cdist_soft_dtw(X, self.cluster_centers_, **self.distance_params)
        else:
            dist_func = self.distance_metrics[self.distance]
            return self._cdist_generic(dist_func, X, self.cluster_centers_)
    # def compute_distance_matrix(self, X: np.ndarray, cache_path: Optional[str] = None) -> np.ndarray:
    #     """Compute distance matrix using selected metric."""
    #     logger.info(f"Computing distance matrix using distance={self.distance}")
    #     start_time = time.time()

    #     if cache_path and os.path.exists(cache_path):
    #         logger.info(f"Loading distance matrix from cache: {cache_path}")
    #         with open(cache_path, 'rb') as f:
    #             self.distance_matrix_cache = load(f)
    #         logger.info(f"Loaded cached distance matrix in {time.time() - start_time:.2f} seconds")
    #         return self.distance_matrix_cache

    #     if self.distance_matrix_cache is not None:
    #         return self.distance_matrix_cache

    #     if isinstance(self.distance, str):
    #         metric = self.distance_metrics[self.distance]
    #         if self.distance == 'dtw':
    #             self.distance_matrix_cache = cdist_dtw(X, n_jobs=self.n_jobs,**self.distance_params)
    #         elif self.distance == 'softdtw':
    #             self.distance_matrix_cache = cdist_soft_dtw(X, **self.distance_params,n_jobs=self.n_jobs,)
    #         elif self.distance == 'euclidean':
    #             X_flat = X.reshape((len(X), -1))
    #             self.distance_matrix_cache = np.array([
    #                 [np.linalg.norm(x - y) for y in X_flat] for x in X_flat
    #             ])
    #         else:
    #             self.distance_matrix_cache = self._parallel_distance_computation(X, metric)
    #     else:
    #         self.distance_matrix_cache = self._parallel_distance_computation(X, self.distance)

    #     if cache_path:
    #         logger.info(f"Saving distance matrix to cache: {cache_path}")
    #         with open(cache_path, 'wb') as f:
    #             dump(self.distance_matrix_cache, f)

    #     logger.info(f"Computed distance matrix in {time.time() - start_time:.2f} seconds")
    #     return self.distance_matrix_cache

    # def _parallel_distance_computation(self, X: np.ndarray, metric: Callable) -> np.ndarray:
    #     """Compute distance matrix in parallel."""
    #     n_samples = len(X)
        
    #     def compute_distances(start, end):
    #         sub_matrix = np.zeros((end - start, n_samples))
    #         for i in range(start, end):
    #             for j in range(i, n_samples):
    #                 dist = metric(X[i], X[j], **self.distance_params)
    #                 sub_matrix[i - start, j] = dist
    #                 if i != j:
    #                     sub_matrix[j - start, i] = dist
    #         return sub_matrix

    #     chunk_size = max(1, n_samples // (4 * self.n_jobs))
    #     chunks = [(i, min(i + chunk_size, n_samples)) for i in range(0, n_samples, chunk_size)]
        
    #     results = Parallel(n_jobs=self.n_jobs)(
    #         delayed(compute_distances)(start, end) for start, end in chunks
    #     )
        
    #     return np.vstack(results)

    # def _compute_cluster_centers(self, X: np.ndarray):
    #     """Compute cluster centers based on algorithm type."""
    #     if hasattr(self.best_model, 'cluster_centers_'):
    #         self.cluster_centers_ = self.best_model.cluster_centers_
    #     else:
    #         # Compute medoids for each cluster
    #         unique_labels = np.unique(self.labels_[self.labels_ >= 0])
    #         self.cluster_centers_ = []
    #         for label in unique_labels:
    #             cluster_points = X[self.labels_ == label]
    #             if len(cluster_points) > 0:
    #                 distances = self.compute_distance_matrix(cluster_points)
    #                 medoid_idx = np.argmin(distances.sum(axis=0))
    #                 self.cluster_centers_.append(cluster_points[medoid_idx])
    #         self.cluster_centers_ = np.array(self.cluster_centers_)
    def _compute_cluster_centers(self, X: np.ndarray, distance_matrix:np.ndarray):
        """
        Compute cluster centers based on algorithm type and available properties.
        """
        if self.algorithm in ['kmeans','kmedoids']:
            self.cluster_centers_ = self.best_model.cluster_centers_
        # elif self.algorithm == 'kmedoids':
        #     self.cluster_centers_ = X[self.best_model.medoid_indices_]  # kmedoids stores indices of medoids
        elif self.algorithm in ['affinity_propagation','chinese_whispers']:
            self.cluster_centers_ = X[self.best_model.cluster_centers_indices_]
        elif self.algorithm in ['dbscan', 'optics']:
            # Use core samples for computing centers
            core_samples_mask = np.zeros_like(self.labels_, dtype=bool)
            core_samples_mask[self.best_model.core_sample_indices_] = True
            unique_labels = np.unique(self.labels_[self.labels_ >= 0])
            centers = []
            
            for label in unique_labels:
                # Get all points and core points in cluster
                cluster_mask = self.labels_ == label
                core_cluster_mask = cluster_mask & core_samples_mask
                
                if np.any(core_cluster_mask):
                    # If we have core points, use only those for center computation
                    cluster_points = X[core_cluster_mask]
                else:
                    # Fallback to all points if no core points
                    cluster_points = X[cluster_mask]
                    
                if len(cluster_points) > 0:
                    # Compute medoid from distance matrix of cluster points
                    cluster_distances = distance_matrix(cluster_points)
                    medoid_idx = np.argmin(cluster_distances.sum(axis=0))
                    centers.append(cluster_points[medoid_idx])
                    
            self.cluster_centers_ = np.array(centers)
        
        else:
            # For other algorithms, compute centers based on labels

            centers = []
            unique_labels = np.unique(self.labels_[self.labels_ >= 0])
            for cluster_label in np.unique(unique_labels):
                cluster_indices = np.where(self.labels_  == cluster_label)[0]
                cluster_distances = distance_matrix[np.ix_(cluster_indices, cluster_indices)]
                total_distances = cluster_distances.sum(axis=1)
                medoid_index = cluster_indices[np.argmin(total_distances)]
               
                centers.append(X[self.labels_ == cluster_label][medoid_index])
            self.cluster_centers_ = np.array(centers)

          
    
    # def _compute_outlier_threshold(self, X: np.ndarray):
    #     """Compute threshold for outlier detection."""
    #     if self.cluster_centers_ is not None:
    #         distances = self._compute_distances_to_centers(X)
    #         self.outlier_threshold = np.percentile(distances.min(axis=1), 95)
    def _compute_outlier_threshold(self, X: np.ndarray):
        """Compute threshold for outlier detection."""
        if self.cluster_centers_ is not None:
            distances = self._compute_distances_to_centers(X)
            self.outlier_threshold = np.percentile(distances.min(axis=1), 95)

            #  """
            #     Calculate outlier thresholds for each cluster based on distances to cluster centers.

            #     Parameters:
            #     - distance_matrix: np.ndarray
            #         Precomputed distance matrix of shape (n_samples, n_samples).
            #     """
            # self.outlier_thresholds_ = {}
            # for label, nodes in self.clusters_.items():
            #     center_node = self.cluster_centers_indices_[label]
            #     indices = np.array(list(nodes))
            #     distances = distance_matrix[indices, center_node]

            #     # Using percentile for outlier detection
            #     threshold = np.percentile(distances, self.outlier_percentile)
            #     self.outlier_thresholds_[f'cluster_{label}'] = threshold

    # def _compute_distances_to_centers(self, X: np.ndarray) -> np.ndarray:
    #     """Compute distances from samples to cluster centers."""
    #     distances = np.zeros((len(X), len(self.cluster_centers_)))
    #     for i, center in enumerate(self.cluster_centers_):
    #         for j, sample in enumerate(X):
    #             if isinstance(self.distance, str):
    #                 metric = self.distance_metrics[self.distance]
    #                 if callable(metric):
    #                     distances[j, i] = metric(sample, center, **self.distance_params)
    #                 else:
    #                     distances[j, i] = np.linalg.norm(sample - center)
    #             else:
    #                 distances[j, i] = self.distance(sample, center, **self.distance_params)
    #     return distances

    
    def fit(self, X, y=None):
        """
        Fit the clustering model.
        Handle precomputed distances for algorithms that support it.
        """
        distance_matrix = self.compute_distance_matrix(X)
        
        if self.algorithm in ['agglomerative', 'dbscan', 'affinity_propagation','chinese_whispers']:
            # These algorithms can use precomputed distance matrix
            self.best_model = self.clustering_algorithms[self.algorithm](
                affinity='precomputed',
                **self.algo_params
            )
            self.labels_ = self.best_model.fit_predict(distance_matrix)
        else:
            # These algorithms need raw data
            self.best_model = self.clustering_algorithms[self.algorithm](
                **self.algo_params
            )
            self.labels_ = self.best_model.fit_predict(X)
        
        self._compute_cluster_centers(X,distance_matrix)
        self._compute_outlier_threshold(X,distance_matrix)
        self.X_fit_ = X
        return self

    def predict(self, X):
        """Predict clusters for X."""
        check_is_fitted(self)
        
        if self.algorithm in ['kmeans', 'kmedoids'] and hasattr(self.best_model, 'predict'):
            return self.best_model.predict(X)
        
        # For other algorithms, use distances to assign clusters
        distances = self._compute_distances_to_centers(X)
        if self.algorithm == 'chinese_whispers':
            return self.best_model.predict(distances,True)
       
        labels = distances.argmin(axis=1)
        
        # Mark outliers
        if self.outlier_threshold is not None:
            outliers = distances.min(axis=1) > self.outlier_threshold
            labels[outliers] = -1
            
        return labels

    def fit_predict(self, X, y=None):
        """Compute cluster centers and predict cluster index for each sample."""
        return self.fit(X).predict(X)

    def _compute_optimization_score(self, X: np.ndarray, X_test: Optional[np.ndarray] = None) -> float:
        """Compute optimization score."""
        logger.info("Computing optimization score")
        start_time = time.time()
        
        silhouette = silhouette_score(X, self.labels_)
        calinski_harabasz = calinski_harabasz_score(X, self.labels_)
        davies_bouldin = davies_bouldin_score(X, self.labels_)
        
        davies_bouldin_normalized = 1 / (1 + davies_bouldin)
        combined_score = (silhouette + calinski_harabasz / 1000 + davies_bouldin_normalized) / 3
        
        if X_test is not None:
            test_labels = self.predict(X_test)
            outlier_ratio = np.sum(test_labels == -1) / len(test_labels)
            combined_score *= (1 - outlier_ratio)
        
        logger.info(f"Computed optimization score in {time.time() - start_time:.2f} seconds")
        
        if self.optimization_metric == 'combined':
            return combined_score
        elif self.optimization_metric == 'silhouette':
            return silhouette
        elif self.optimization_metric == 'calinski_harabasz':
            return calinski_harabasz
        elif self.optimization_metric == 'davies_bouldin':
            return davies_bouldin_normalized
        else:
            raise ValueError(f"Unsupported optimization metric: {self.optimization_metric}")

    def score(self, X, y=None):
        """Returns the score defined by optimization_metric."""
        return self._compute_optimization_score(X)

    # def chinese_whispers_clustering(self, X: np.ndarray, distance_matrix: np.ndarray) -> np.ndarray:
    #     """Implement Chinese Whispers clustering."""
    #     start_time = time.time()
    #     logger.info("Performing Chinese Whispers clustering...")
    #     n_samples = distance_matrix.shape[0]
        
    #     sigma = np.std(distance_matrix)
    #     similarity_matrix = np.exp(-distance_matrix ** 2 / (2 * sigma ** 2))

    #     G = nx.Graph()
    #     for i in range(n_samples):
    #         for j in range(i + 1, n_samples):
    #             weight = similarity_matrix[i, j]
    #             if weight > 0:
    #                 G.add_edge(i, j, weight=weight)

    #     iterations = self.algo_params.get('iterations', 20)
    #     weighting = self.algo_params.get('weighting', 'top')
    #     chinese_whispers(G, weighting=weighting, iterations=iterations)
    #     self.G = G

    #     labels = np.array([G.nodes[node]['label'] for node in G.nodes()])
    #     unique_labels = np.unique(labels)
    #     label_mapping = {label: idx for idx, label in enumerate(unique_labels)}
    #     labels_mapped = np.array([label_mapping[label] for label in labels])

    #     logger.info(f"Chinese Whispers clustering completed in {time.time() - start_time:.2f} seconds")
    #     return labels_mapped
# def main():
#     datasets = {
#         'small': make_blobs(n_samples=10000, n_features=22, centers=3, random_state=42)[0],
        
#     }

#     distance_metrics = {
#         #'euclidean': {},
#         #'dtw': {'sakoe_chiba_radius': 1},
#        # 'softdtw': {'gamma': 0.1},
#         'lcss': {'epsilon': 0.1},
#         'erp': {'g': 0.1},
#         'edr': {'epsilon': 0.1},
#         'msm': {'c': 0.1},
#         'twe': {'nu': 0.1, 'lmbda': 2} 
#     }

#     for dataset_name, dataset in datasets.items():
#         print(f"\nTesting on {dataset_name} dataset (shape: {dataset.shape})")
        
#         for metric, params in distance_metrics.items():
#             print(f"\nTesting {metric} distance with parameters: {params}")
            
#             try:
#                 predictor = TimeSeriesClusterPredictor(distance=metric, distance_params=params)
                
#                 start_time = time.time()
#                 distance_matrix = predictor.compute_distance_matrix(dataset)
#                 end_time = time.time()
                
#                 calculation_time = end_time - start_time
                
#                 assert distance_matrix.shape == (len(dataset), len(dataset)), "Incorrect shape of distance matrix"
#                 assert np.allclose(distance_matrix, distance_matrix.T), "Distance matrix is not symmetric"
#                 assert np.all(np.diag(distance_matrix) == 0), "Diagonal of distance matrix is not all zeros"
                
#                 print(f"  Calculation time: {calculation_time:.4f} seconds")
#                 print(f"  Matrix shape: {distance_matrix.shape}")
#                 print(f"  Min distance: {np.min(distance_matrix):.4f}")
#                 print(f"  Max distance: {np.max(distance_matrix):.4f}")
#                 print(f"  Mean distance: {np.mean(distance_matrix):.4f}")
                
#                 cache_start_time = time.time()
#                 cached_distance_matrix = predictor.compute_distance_matrix(dataset)
#                 cache_end_time = time.time()
#                 cache_calculation_time = cache_end_time - cache_start_time
                
#                 assert np.array_equal(distance_matrix, cached_distance_matrix), "Cached matrix doesn't match original"
#                 print(f"  Cached calculation time: {cache_calculation_time:.4f} seconds")
                
#             except Exception as e:
#                 print(f"  Error occurred: {str(e)}")

# if __name__ == "__main__":
#     main()



import numpy as np
from sklearn.datasets import make_blobs
import time
import logging
import pandas as pd
import matplotlib.pyplot as plt
#from memory_profiler import memory_usage
import seaborn as sns
from typing import Dict, List

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def generate_test_data():
    """Generate test datasets of different characteristics."""
    datasets = {}
    
    # Small dataset
    X_small, _ = make_blobs(n_samples=100, n_features=10, centers=3, 
                           random_state=42)
    datasets['small'] = X_small
    
    # # Medium dataset
    # X_medium, _ = make_blobs(n_samples=500, n_features=20, centers=5,
    #                         random_state=42)
    # datasets['medium'] = X_medium
    
    # # Large dataset
    # X_large, _ = make_blobs(n_samples=1000, n_features=30, centers=8,
    #                        random_state=42)
    # datasets['large'] = X_large
    
    return datasets

def test_clustering_algorithm(predictor, X: np.ndarray, algorithm: str, algo_params: Dict):
    """Test single clustering algorithm and measure performance."""
    try:
        # Set algorithm and parameters
        predictor.set_params(algorithm=algorithm, algo_params=algo_params)
        
        # Measure memory and time
        start_time = time.time()
        #mem_usage = memory_usage((predictor.fit, (X,), {}), max_usage=True)
        predictor.fit(X)
        fit_time = time.time() - start_time
        
        # Compute clustering quality metrics
        score = predictor.score(X)
        
        return {
            'success': True,
            'fit_time': fit_time,
            #'memory_mb': mem_usage,
            'score': score,
            'n_clusters': len(np.unique(predictor.labels_[predictor.labels_ >= 0]))
        }
    
    except Exception as e:
        logger.error(f"Error testing {algorithm}: {str(e)}")
        return {
            'success': False,
            'error': str(e)
        }

def main():
    # Generate test datasets
    datasets = generate_test_data()
    
    # Define clustering algorithms and their parameters
    clustering_configs = {
        'kmeans': {
            'algo_params__n_clusters': 5,
            'algo_params__max_iter': 300
        },
        'kmedoids': {
            'algo_params__n_clusters': 5,
            'algo_params__max_iter': 300
        },
        'agglomerative': {
            'algo_params__n_clusters': 5,
            'algo_params__linkage': 'ward'
        },
        'dbscan': {
            'algo_params__eps': 0.5,
            'algo_params__min_samples': 5
        },
        'optics': {
            'algo_params__min_samples': 5,
            'algo_params__xi': 0.05
        },
        'affinity_propagation': {
            'algo_params__damping': 0.5,
            'algo_params__preference': -50
        },
        'chinese_whispers': {
             'algo_params__k':5,
            'algo_params__iterations': 20,
            'algo_params__weighting': 'top'
        }
    }
    
    # Results storage
    results = []
    
    # Test each dataset size
    for dataset_name, X in datasets.items():
        logger.info(f"\nTesting on {dataset_name} dataset (shape: {X.shape})")
        
        # Initialize predictor with DTW distance
        predictor = TimeSeriesClusterPredictor(
            distance='dtw',
            distance_params={'global_constraint': 'sakoe_chiba', 'sakoe_chiba_radius': 3},
            n_jobs=-1,
            random_state=42
        )
        
        # Test each clustering algorithm
        for algorithm, algo_params in clustering_configs.items():
            logger.info(f"\nTesting {algorithm}")
            
            result = test_clustering_algorithm(predictor, X, algorithm, algo_params)
            result.update({
                'dataset': dataset_name,
                'dataset_size': len(X),
                'algorithm': algorithm
            })
            
            results.append(result)
            
            if result['success']:
                logger.info(f"  Time: {result['fit_time']:.2f} seconds")
                logger.info(f"  Memory: {result['memory_mb']:.2f} MB")
                logger.info(f"  Score: {result['score']:.4f}")
                logger.info(f"  Clusters: {result['n_clusters']}")
            else:
                logger.error(f"  Failed: {result['error']}")
    
    # Convert results to DataFrame
    results_df = pd.DataFrame(results)
    
    # Plot performance comparison
    plt.figure(figsize=(15, 10))
    
    # Time comparison
    plt.subplot(2, 2, 1)
    success_results = results_df[results_df['success']]
    sns.barplot(data=success_results, x='algorithm', y='fit_time', hue='dataset')
    plt.xticks(rotation=45)
    plt.title('Clustering Time by Algorithm')
    
    # Memory usage
    plt.subplot(2, 2, 2)
    sns.barplot(data=success_results, x='algorithm', y='memory_mb', hue='dataset')
    plt.xticks(rotation=45)
    plt.title('Memory Usage by Algorithm')
    
    # Score comparison
    plt.subplot(2, 2, 3)
    sns.barplot(data=success_results, x='algorithm', y='score', hue='dataset')
    plt.xticks(rotation=45)
    plt.title('Clustering Score by Algorithm')
    
    # Number of clusters
    plt.subplot(2, 2, 4)
    sns.barplot(data=success_results, x='algorithm', y='n_clusters', hue='dataset')
    plt.xticks(rotation=45)
    plt.title('Number of Clusters by Algorithm')
    
    plt.tight_layout()
    plt.show()
    
    # Print summary statistics
    print("\nSummary Statistics:")
    summary = success_results.groupby('algorithm').agg({
        'fit_time': ['mean', 'std'],
        'memory_mb': ['mean', 'std'],
        'score': ['mean', 'std'],
        'n_clusters': ['mean', 'std']
    }).round(3)
    print(summary)
    
    # Print failures if any
    failures = results_df[~results_df['success']]
    if len(failures) > 0:
        print("\nFailed Tests:")
        for _, row in failures.iterrows():
            print(f"{row['algorithm']} on {row['dataset']}: {row['error']}")

if __name__ == "__main__":
    main()
