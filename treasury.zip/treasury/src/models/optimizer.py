
from sklearn.model_selection import GridSearchCV, HalvingGridSearchCV
from skopt import BayesSearchCV
from skopt.space import Real, Integer, Categorical
import pandas as pd
import numpy as np
import time
from typing import Dict, List, Union, Optional
import logging
from  cluster_prediction7 import TimeSeriesClusterPredictor
logger = logging.getLogger(__name__)

class TimeSeriesClusterOptimizer:
    def __init__(
        self,
        optimization_method: str = 'bayesian',  # 'grid', 'halving', 'bayesian'
        n_jobs: int = -1,
        random_state: Optional[int] = None,
        cv: int = 3,
        verbose: int = 1
    ):
        self.optimization_method = optimization_method
        self.n_jobs = n_jobs
        self.random_state = random_state
        self.cv = cv
        self.verbose = verbose
        
        # Define parameter spaces for each distance metric
        self.distance_params = {
            'dtw': {
                'grid': {
                    'distance_params__sakoe_chiba_radius': [None, 1, 3, 5],
                    'distance_params__global_constraint': [None, "sakoe_chiba"]
                },
                'bayesian': {
                    'distance_params__sakoe_chiba_radius': Categorical([None, 1, 3, 5]),
                    'distance_params__global_constraint': Categorical([None, "sakoe_chiba"])
                }
            },
            'softdtw': {
                'grid': {
                    'distance_params__gamma': [0.1, 1.0, 10.0]
                },
                'bayesian': {
                    'distance_params__gamma': Real(0.1, 10.0, prior='log-uniform')
                }
            },
            'lcss': {
                'grid': {
                    'distance_params__epsilon': [0.1, 0.5, 1.0]
                },
                'bayesian': {
                    'distance_params__epsilon': Real(0.1, 1.0, prior='uniform')
                }
            },
            'erp': {
                'grid': {
                    'distance_params__g_value': [0.0, 0.5, 1.0]
                },
                'bayesian': {
                    'distance_params__g_value': Real(0.0, 1.0, prior='uniform')
                }
            },
            'msm': {
                'grid': {
                    'distance_params__c': [0.1, 1.0, 5.0]
                },
                'bayesian': {
                    'distance_params__c': Real(0.1, 5.0, prior='log-uniform')
                }
            },
            'twe': {
                'grid': {
                    'distance_params__nu': [0.001, 0.01, 0.1],
                    'distance_params__lmbda': [1.0, 2.0, 5.0]
                },
                'bayesian': {
                    'distance_params__nu': Real(0.001, 0.1, prior='log-uniform'),
                    'distance_params__lmbda': Real(1.0, 5.0, prior='uniform')
                }
            }
        }
        
        # Define parameter spaces for each clustering algorithm
        self.clustering_params = {
            'kmeans': {
                'grid': {
                    'algo_params__n_clusters': [2, 3, 5, 8],
                    'algo_params__max_iter': [100, 300],
                },
                'bayesian': {
                    'algo_params__n_clusters': Integer(2, 10),
                    'algo_params__max_iter': Integer(100, 300)
                }
            },
            'kmedoids': {
                'grid': {
                    'algo_params__n_clusters': [2, 3, 5, 8]
                },
                'bayesian': {
                    'algo_params__n_clusters': Integer(2, 10)
                }
            },
            'agglomerative': {
                'grid': {
                    'algo_params__n_clusters': [2, 3, 5, 8],
                    'algo_params__linkage': ['ward', 'complete', 'average']
                },
                'bayesian': {
                    'algo_params__n_clusters': Integer(2, 10),
                    'algo_params__linkage': Categorical(['ward', 'complete', 'average'])
                }
            },
            'dbscan': {
                'grid': {
                    'algo_params__eps': [0.1, 0.5, 1.0],
                    'algo_params__min_samples': [3, 5, 10]
                },
                'bayesian': {
                    'algo_params__eps': Real(0.1, 1.0, prior='uniform'),
                    'algo_params__min_samples': Integer(2, 10)
                }
            },
            'optics': {
                'grid': {
                    'algo_params__min_samples': [3, 5, 10],
                    'algo_params__xi': [0.05, 0.1, 0.2]
                },
                'bayesian': {
                    'algo_params__min_samples': Integer(2, 10),
                    'algo_params__xi': Real(0.01, 0.3, prior='uniform')
                }
            },
            'affinity_propagation': {
                'grid': {
                    'algo_params__damping': [0.5, 0.7, 0.9],
                    'algo_params__preference': [-50, -10, -1]
                },
                'bayesian': {
                    'algo_params__damping': Real(0.5, 0.9, prior='uniform'),
                    'algo_params__preference': Real(-50, -1, prior='uniform')
                }

            },
            'chinese_whispers': {
                'grid': {
                    'algo_params__iterations': [20, 100, 1000],
                    'algo_params__weighting': ['top', 'lin', 'log'],
                    'algo_params__k': [10, 20, 40],
                    'algo_params__seed': [None, 42]  # Optional random seed
                },
                'bayesian': {
                    'algo_params__iterations': Integer(10, 50),
                    'algo_params__k': Integer(10, 20, 40),
                    'algo_params__weighting': Categorical(['top', 'lin', 'log']),
                    
                    'algo_params__seed': Categorical([None, 42])
                }
            }
        }

    def _get_search_cv(self, base_estimator, param_space):
        """Create appropriate search CV based on optimization method."""
        if self.optimization_method == 'grid':
            return GridSearchCV(
                estimator=base_estimator,
                param_grid=param_space,
                cv=self.cv,
                n_jobs=self.n_jobs,
                verbose=self.verbose
            )
        elif self.optimization_method == 'halving':
            return HalvingGridSearchCV(
                estimator=base_estimator,
                param_grid=param_space,
                cv=self.cv,
                n_jobs=self.n_jobs,
                verbose=self.verbose
            )
        else:  # bayesian
            return BayesSearchCV(
                estimator=base_estimator,
                search_spaces=param_space,
                cv=self.cv,
                n_jobs=self.n_jobs,
                verbose=self.verbose,
                n_iter=50
            )

    def optimize(self, X: np.ndarray, distance: str, algorithm: str, X_test: Optional[np.ndarray] = None):
        """
        Optimize parameters for specific distance metric and clustering algorithm.
        
        Parameters:
        -----------
        X : array-like
            Training data
        distance : str
            Distance metric to optimize
        algorithm : str
            Clustering algorithm to optimize
        X_test : array-like, optional
            Test data for evaluating generalization
            
        Returns:
        --------
        dict with optimization results
        """
        logger.info(f"Optimizing for distance={distance}, algorithm={algorithm}")
        
        # Validate inputs
        if distance not in self.distance_params:
            raise ValueError(f"Unsupported distance metric: {distance}")
        if algorithm not in self.clustering_params:
            raise ValueError(f"Unsupported clustering algorithm: {algorithm}")
            
        # Create parameter space
        space_type = 'bayesian' if self.optimization_method == 'bayesian' else 'grid'
        param_space = {
            'distance': [distance],
            'algorithm': [algorithm],
            **self.distance_params[distance][space_type],
            **self.clustering_params[algorithm][space_type]
        }
        
        # Create base estimator
        base_estimator = TimeSeriesClusterPredictor(
            n_jobs=self.n_jobs,
            random_state=self.random_state
        )
        
        # Create and run search
        search = self._get_search_cv(base_estimator, param_space)
        
        start_time = time.time()
        search.fit(X)
        optimization_time = time.time() - start_time
        
        # Prepare results
        results = {
            'best_score': search.best_score_,
            'best_params': search.best_params_,
            'optimization_time': optimization_time,
            'best_estimator': search.best_estimator_,
            'cv_results': pd.DataFrame(search.cv_results_)
        }
        
        # Test performance if test data provided
        if X_test is not None:
            test_score = search.best_estimator_.score(X_test)
            results['test_score'] = test_score
            
        return results

    def optimize_all(self, X: np.ndarray, X_test: Optional[np.ndarray] = None):
        """
        Optimize all valid distance-algorithm combinations.
        """
        results = {}
        
        for distance in self.distance_params.keys():
            for algorithm in self.clustering_params.keys():
                try:
                    result = self.optimize(X, distance, algorithm, X_test)
                    results[f"{distance}_{algorithm}"] = result
                except Exception as e:
                    logger.error(f"Error optimizing {distance}_{algorithm}: {str(e)}")
                    
        return results
