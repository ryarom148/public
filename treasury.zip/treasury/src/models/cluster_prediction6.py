import numpy as np
from joblib import Parallel, delayed, dump, load
from sklearn.base import BaseEstimator, ClusterMixin
from sklearn.metrics import silhouette_score, calinski_harabasz_score, davies_bouldin_score
from tslearn.metrics import cdist_dtw, cdist_soft_dtw
import aeon
from aeon.distances import (dtw_distance, lcss_distance, erp_distance,
                            edr_distance, msm_distance, twe_distance)
from aeon.clustering import TimeSeriesKMeans, TimeSeriesKMedoids
from sklearn.cluster import AgglomerativeClustering, DBSCAN, OPTICS, AffinityPropagation
from chinese_whispers import chinese_whispers, aggregate_clusters
import networkx as nx
from typing import Dict, List, Union, Optional, Callable
import os
import logging
import time
from sklearn.datasets import make_blobs
import traceback

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)
aeon.AEON_DEPRECATION_WARNING = False
os.environ['AEON_DEPRECATION_WARNING'] = 'False'

class TimeSeriesClusterPredictor(BaseEstimator, ClusterMixin):
    def __init__(
        self,
        n_jobs: int = -1,
        random_state: Optional[int] = None,
        optimization_metric: str = 'combined',
        optimization_method: str = 'bayesian',
        distance: Union[str, Callable] = 'dtw',
        distance_params: Optional[Dict] = None,
        algorithm: str = 'kmeans',
        algo_params: Optional[Dict] = None
    ):
        self.n_jobs = n_jobs
        self.random_state = random_state
        self.optimization_metric = optimization_metric
        self.optimization_method = optimization_method
        self.distance = distance
        self.distance_params = distance_params if distance_params is not None else {}
        self.algorithm = algorithm
        self.algo_params = algo_params if algo_params is not None else {}
        
        self.distance_metrics = {
            'dtw': dtw_distance,
            'softdtw': cdist_soft_dtw,
            'euclidean': 'euclidean',
            'lcss': lcss_distance,
            'erp': erp_distance,
            'edr': edr_distance,
            'msm': msm_distance,
            'twe': twe_distance,
        }
        
        if isinstance(self.distance, str) and self.distance not in self.distance_metrics:
            raise ValueError(f"Unsupported distance metric: {self.distance}")

        self.clustering_algorithms = {
            'kmeans': TimeSeriesKMeans,
            'kmedoids': TimeSeriesKMedoids,
            'agglomerative': AgglomerativeClustering,
            'dbscan': DBSCAN,
            'optics': OPTICS,
            'affinity_propagation': AffinityPropagation,
            'chinese_whispers': self.chinese_whispers_clustering
        }
        if self.algorithm not in self.clustering_algorithms:
            raise ValueError(f"Unsupported clustering algorithm: {self.algorithm}")
        
        self.best_model = None
        self.cluster_centers_ = None
        self.labels_ = None
        self.best_params_ = None
        self.best_score_ = None
        self.outlier_threshold = None
        self.X_fit_ = None
        self.distance_matrix_cache = None

    def _get_valid_params(self, method):
        """
        Get valid parameters and their defaults for each method.
        Parameters not provided will use defaults or be omitted if optional.
        """
        valid_params = {
            # Distance metrics with ALL valid parameters and defaults
            'dtw': {
                'global_constraint': None,  # Optional
                'sakoe_chiba_radius': None,  # Optional
                'itakura_max_slope': None,  # Optional
                'n_jobs': 1,  # Optional
                'verbose': False  # Optional
            },
            'softdtw': {
                'gamma': 1.0,  # Required, with default
                'n_jobs': 1,  # Optional
                'dist': 'euclidean'  # Optional
            },
            'euclidean': {},  # No parameters needed
            'lcss': {
                'epsilon': 1.0  # Required, with default
            },
            'erp': {
                'g_value': 0.0,  # Required, with default
                'bands': None  # Optional
            },
            'edr': {
                'epsilon': 1.0,  # Required, with default
                'bands': None  # Optional
            },
            'msm': {
                'c': 1.0, # Required, with default
                'window': None,
                'itakura_max_slope': None
            },
            'twe': {
                'window': None,  # Required, with default
                'lmbda':1,#lmbda constant penalty for insert or delete operations. Must be >= 1.0.
                'nu': 0.001  # A non-negative constant called the stiffness, which penalises moves off the diagonal
            },
            
            # Clustering algorithms with ALL valid parameters and defaults
            'kmeans': {
                'n_clusters': 8,
                'init': 'k-means++',
                'n_init': 10,
                'max_iter': 300,
                'tol': 1e-4,
                'verbose': 0,
                'random_state': None,
                'copy_x': True
            },
            'kmedoids': {
                'n_clusters': 8,
                'init': 'build',
                'max_iter': 300,
                'random_state': None
            },
            'agglomerative': {
                'n_clusters': None,
                'affinity': 'euclidean',
                'memory': None,
                'connectivity': None,
                'compute_full_tree': 'auto',
                'linkage': 'ward',
                'distance_threshold': None
            },
            'dbscan': {
                'eps': 0.5,
                'min_samples': 5,
                'metric': 'euclidean',
                'metric_params': None,
                'algorithm': 'auto',
                'leaf_size': 30,
                'p': None,
                'n_jobs': None
            },
            'optics': {
                'min_samples': 5,
                'max_eps': np.inf,
                'metric': 'minkowski',
                'p': 2,
                'metric_params': None,
                'cluster_method': 'xi',
                'eps': None,
                'xi': 0.05,
                'predecessor_correction': True,
                'min_cluster_size': None,
                'algorithm': 'auto',
                'leaf_size': 30,
                'n_jobs': None
            },
            'affinity_propagation': {
                'damping': 0.5,
                'max_iter': 200,
                'convergence_iter': 15,
                'preference': None,
                'affinity': 'euclidean',
                'verbose': False
            },
            'chinese_whispers': {
                'iterations': 20,
                'weighting': 'top',
                'threshold': 0.0,
                'seed': None
            }
        }
        return valid_params.get(method, {})

    def compute_distance_matrix(self, X: np.ndarray, cache_path: Optional[str] = None) -> np.ndarray:
        logger.info(f"Computing distance matrix using distance={self.distance}")
        start_time = time.time()
        
        if cache_path and os.path.exists(cache_path):
            logger.info(f"Loading distance matrix from cache: {cache_path}")
            with open(cache_path, 'rb') as f:
                self.distance_matrix_cache = load(f)
            logger.info(f"Loaded cached distance matrix in {time.time() - start_time:.2f} seconds")
            return self.distance_matrix_cache
        
        if self.distance_matrix_cache is not None:
            return self.distance_matrix_cache
        
        self.distance_matrix_cache = self._compute_full_distance_matrix(X)
        
        if cache_path:
            logger.info(f"Saving distance matrix to cache: {cache_path}")
            with open(cache_path, 'wb') as f:
                dump(self.distance_matrix_cache, f)
        
        logger.info(f"Computed distance matrix in {time.time() - start_time:.2f} seconds")
        return self.distance_matrix_cache
    
    def _compute_full_distance_matrix(self, X: np.ndarray) -> np.ndarray:
        n_samples = len(X)
        distances = np.zeros((n_samples, n_samples))

        if isinstance(self.distance, str):
            metric = self.distance_metrics[self.distance]
            if self.distance == 'dtw':
                distances = cdist_dtw(X, n_jobs=self.n_jobs, **self.distance_params)
            elif self.distance == 'softdtw':
                distances = cdist_soft_dtw(X, **self.distance_params)
            elif self.distance == 'euclidean':
                X_flat = X.reshape((len(X), -1))
                distances = np.array([
                    [np.linalg.norm(x - y) for y in X_flat] for x in X_flat
                ])
            elif callable(metric):
                distances = self._parallel_distance_computation(X, metric)
        elif callable(self.distance):
            distances = self._parallel_distance_computation(X, self.distance)
        else:
            raise ValueError("Distance must be either a string or a callable")
        
        return distances
    
    def _parallel_distance_computation(self, X: np.ndarray, metric: Callable) -> np.ndarray:
        n_samples = len(X)
        
        def compute_distances(start, end):
            sub_matrix = np.zeros((end - start, n_samples))
            for i in range(start, end):
                for j in range(i, n_samples):
                    dist = metric(X[i], X[j], **self.distance_params)
                    sub_matrix[i - start, j] = dist
                    if i != j:
                        sub_matrix[j - start, i] = dist
            return sub_matrix

        chunk_size = max(1, n_samples // (4 * self.n_jobs))
        chunks = [(i, min(i + chunk_size, n_samples)) for i in range(0, n_samples, chunk_size)]
        
        results = Parallel(n_jobs=self.n_jobs)(
            delayed(compute_distances)(start, end) for start, end in chunks
        )
        
        distances = np.vstack(results)
        
        return distances

    def set_params(self, **params):
        """
        Set parameters using _get_valid_params for defaults and validation.
        Only includes provided parameters and required defaults.
        """
        if 'distance' in params:
            self.distance = params['distance']
            # Get defaults for current distance
            distance_defaults = self._get_valid_params(self.distance)
            self.distance_params = {k: v for k, v in distance_defaults.items() 
                                  if v is not None}  # Only include non-None defaults
                
        if 'algorithm' in params:
            self.algorithm = params['algorithm']
            # Get defaults for current algorithm
            algo_defaults = self._get_valid_params(self.algorithm)
            self.algo_params = {k: v for k, v in algo_defaults.items() 
                              if v is not None}  # Only include non-None defaults
                
        if 'distance_params' in params:
            # Update with provided parameters
            valid_params = self._get_valid_params(self.distance)
            self.distance_params.update({
                k: v for k, v in params['distance_params'].items() 
                if k in valid_params
            })
                
        if 'algo_params' in params:
            # Update with provided parameters
            valid_params = self._get_valid_params(self.algorithm)
            self.algo_params.update({
                k: v for k, v in params['algo_params'].items() 
                if k in valid_params
            })
                
        for key, value in params.items():
            if key not in ['distance_params', 'algo_params']:
                setattr(self, key, value)
        
        return self

    def chinese_whispers_clustering(self, X: np.ndarray, distance_matrix: np.ndarray) -> np.ndarray:
        start_time = time.time()
        logger.info("Performing Chinese Whispers clustering...")
        n_samples = distance_matrix.shape[0]
        
        sigma = np.std(distance_matrix)
        similarity_matrix = np.exp(-distance_matrix ** 2 / (2 * sigma ** 2))

        G = nx.Graph()
        for i in range(n_samples):
            for j in range(i + 1, n_samples):
                weight = similarity_matrix[i, j]
                if weight > 0:
                    G.add_edge(i, j, weight=weight)

        iterations = self.algo_params.get('iterations', 20)
        weighting = self.algo_params.get('weighting', 'top')
        chinese_whispers(G, weighting=weighting, iterations=iterations)
        self.G = G

        labels = np.array([G.nodes[node]['label'] for node in G.nodes()])
        unique_labels = np.unique(labels)
        label_mapping = {label: idx for idx, label in enumerate(unique_labels)}
        labels_mapped = np.array([label_mapping[label] for label in labels])

        self.cluster_centers = np.array([
            X[labels_mapped == label][
                np.argmin(distance_matrix[np.ix_(labels_mapped == label, labels_mapped == label)].sum(axis=1))
            ] for label in unique_labels
        ])

        logger.info(f"Chinese Whispers clustering completed in {time.time() - start_time:.2f} seconds.")
        return labels_mapped
    
    def fit(self, X, y=None):
        """
        Compute clustering.
        
        Parameters:
        -----------
        X : array-like of shape (n_samples, n_features)
            Training instances to cluster.
        y : Ignored
            Not used, present here for API consistency by convention.
            
        Returns:
        --------
        self : object
            Returns self.
        """
        if self.algorithm == 'chinese_whispers':
            distance_matrix = self.compute_distance_matrix(X)
            self.labels_ = self.chinese_whispers_clustering(X, distance_matrix)
        else:
            # Get clustering algorithm and its parameters
            algo_class = self.clustering_algorithms[self.algorithm]
            distance_matrix = self.compute_distance_matrix(X)
            
            if self.algorithm in ['kmeans', 'kmedoids']:
                self.best_model = algo_class(**self.algo_params)
                self.labels_ = self.best_model.fit_predict(X)
            else:
                self.best_model = algo_class(**self.algo_params)
                self.labels_ = self.best_model.fit_predict(distance_matrix)
            
            if hasattr(self.best_model, 'cluster_centers_'):
                self.cluster_centers_ = self.best_model.cluster_centers_
        
        self.X_fit_ = X
        return self

    def fit_predict(self, X, y=None):
        """
        Compute cluster centers and predict cluster index for each sample.
        
        Parameters:
        -----------
        X : array-like of shape (n_samples, n_features)
            New data to transform.
        y : Ignored
            Not used, present here for API consistency by convention.
            
        Returns:
        --------
        labels : ndarray of shape (n_samples,)
            Index of the cluster each sample belongs to.
        """
        return self.fit(X).labels_

    def predict(self, X):
        """
        Predict the closest cluster for each sample in X.
        
        Parameters:
        -----------
        X : array-like of shape (n_samples, n_features)
            New data to predict.
            
        Returns:
        --------
        labels : ndarray of shape (n_samples,)
            Index of the cluster each sample belongs to.
        """
        check_is_fitted(self)
        
        # Compute distances to cluster centers
        if self.algorithm in ['kmeans', 'kmedoids']:
            return self.best_model.predict(X)
        else:
            # For other algorithms, compute distances to fitted data
            distances = self.compute_distance_matrix(X)
            if self.algorithm == 'dbscan' or self.algorithm == 'optics':
                # For density-based clustering, use epsilon to assign points
                min_distances = distances.min(axis=1)
                labels = np.where(min_distances <= self.algo_params.get('eps', np.inf),
                                self.labels_[distances.argmin(axis=1)],
                                -1)
            else:
                # For other algorithms, assign to nearest cluster
                labels = self.labels_[distances.argmin(axis=1)]
            return labels

    def score(self, X, y=None):
        """
        Compute clustering performance score.
        Uses silhouette_score if y is not provided, else adjusted_rand_score.
        
        Parameters:
        -----------
        X : array-like of shape (n_samples, n_features)
            Data to score.
        y : array-like of shape (n_samples,), optional
            True labels for X.
            
        Returns:
        --------
        score : float
            Clustering performance score.
        """
        check_is_fitted(self)
        
        if y is not None:
            from sklearn.metrics import adjusted_rand_score
            labels = self.predict(X)
            return adjusted_rand_score(y, labels)
        else:
            distance_matrix = self.compute_distance_matrix(X)
            if len(np.unique(self.labels_)) <= 1:
                return 0.0
            return silhouette_score(distance_matrix, self.labels_, metric='precomputed')

    def transform(self, X):
        """
        Transform X to a cluster-distance space.
        
        Parameters:
        -----------
        X : array-like of shape (n_samples, n_features)
            New data to transform.
            
        Returns:
        --------
        X_new : array-like of shape (n_samples, n_clusters)
            X transformed in the new space.
        """
        check_is_fitted(self)
        
        if not hasattr(self, 'cluster_centers_'):
            raise NotImplementedError(
                f"Transform is not implemented for {self.algorithm} clustering."
            )
        
        distances = self.compute_distance_matrix(X)
        unique_labels = np.unique(self.labels_[self.labels_ >= 0])
        result = np.zeros((X.shape[0], len(unique_labels)))
        
        for i, label in enumerate(unique_labels):
            mask = self.labels_ == label
            if np.any(mask):
                result[:, i] = distances[:, mask].min(axis=1)
        
        return result

    def fit_transform(self, X, y=None):
        """
        Compute clustering and transform X to cluster-distance space.
        
        Parameters:
        -----------
        X : array-like of shape (n_samples, n_features)
            New data to transform.
        y : Ignored
            Not used, present here for API consistency by convention.
            
        Returns:
        --------
        X_new : array-like of shape (n_samples, n_clusters)
            X transformed in the new space.
        """
        return self.fit(X).transform(X)