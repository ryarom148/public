import numpy as np
from joblib import Parallel, delayed, dump, load
from sklearn.base import BaseEstimator, ClusterMixin
from sklearn.metrics import silhouette_score, calinski_harabasz_score, davies_bouldin_score
from tslearn.metrics import cdist_dtw, cdist_soft_dtw
import aeon
from aeon.distances import (dtw_distance, lcss_distance, erp_distance,
                            edr_distance, msm_distance, twe_distance)
from aeon.clustering import TimeSeriesKMeans, TimeSeriesKMedoids
from sklearn.cluster import AgglomerativeClustering, DBSCAN, OPTICS, AffinityPropagation
from chinese_whispers import chinese_whispers, aggregate_clusters
import networkx as nx
from typing import Dict, List, Union, Optional, Callable
import os
import logging
import time
from sklearn.datasets import make_blobs

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)
aeon.AEON_DEPRECATION_WARNING = False
os.environ['AEON_DEPRECATION_WARNING'] = 'False'
class TimeSeriesClusterPredictor(BaseEstimator, ClusterMixin):
    def __init__(
        self,
        n_jobs: int = -1,
        random_state: Optional[int] = None,
        optimization_metric: str = 'combined',
        optimization_method: str = 'bayesian',
        distance: Union[str, Callable] = 'dtw',
        distance_params: Optional[Dict] = None,
        algorithm: str = 'kmeans',
        algo_params: Optional[Dict] = None
    ):
        self.n_jobs = n_jobs
        self.random_state = random_state
        self.optimization_metric = optimization_metric
        self.optimization_method = optimization_method
        self.distance = distance
        self.distance_params = distance_params if distance_params is not None else {}
        self.algorithm = algorithm
        self.algo_params = algo_params if algo_params is not None else {}
        
        self.distance_metrics = {
            'dtw': dtw_distance,
            'softdtw': cdist_soft_dtw,
            'euclidean': 'euclidean',
            'lcss': lcss_distance,
            'erp': erp_distance,
            'edr': edr_distance,
            'msm': msm_distance,
            'twe': twe_distance,
        }
        
        if isinstance(self.distance, str) and self.distance not in self.distance_metrics:
            raise ValueError(f"Unsupported distance metric: {self.distance}")

        self.clustering_algorithms = {
            'kmeans': TimeSeriesKMeans,
            'kmedoids': TimeSeriesKMedoids,
            'agglomerative': AgglomerativeClustering,
            'dbscan': DBSCAN,
            'optics': OPTICS,
            'affinity_propagation': AffinityPropagation,
            'chinese_whispers': self.chinese_whispers_clustering
        }
        if self.algorithm not in self.clustering_algorithms:
            raise ValueError(f"Unsupported clustering algorithm: {self.algorithm}")
        
        self.best_model = None
        self.cluster_centers_ = None
        self.labels_ = None
        self.best_params_ = None
        self.best_score_ = None
        self.outlier_threshold = None
        self.X_fit_ = None
        self.distance_matrix_cache = None

    def compute_distance_matrix(self, X: np.ndarray, cache_path: Optional[str] = None) -> np.ndarray:
        logger.info(f"Computing distance matrix using distance={self.distance}")
        start_time = time.time()
        
        if cache_path and os.path.exists(cache_path):
            logger.info(f"Loading distance matrix from cache: {cache_path}")
            with open(cache_path, 'rb') as f:
                self.distance_matrix_cache = load(f)
            logger.info(f"Loaded cached distance matrix in {time.time() - start_time:.2f} seconds")
            return self.distance_matrix_cache
        
        if self.distance_matrix_cache is not None:
            return self.distance_matrix_cache
        
        self.distance_matrix_cache = self._compute_full_distance_matrix(X)
        
        if cache_path:
            logger.info(f"Saving distance matrix to cache: {cache_path}")
            with open(cache_path, 'wb') as f:
                dump(self.distance_matrix_cache, f)
        
        logger.info(f"Computed distance matrix in {time.time() - start_time:.2f} seconds")
        return self.distance_matrix_cache
    
    def _compute_full_distance_matrix(self, X: np.ndarray) -> np.ndarray:
        n_samples = len(X)
        distances = np.zeros((n_samples, n_samples))

        if isinstance(self.distance, str):
            metric = self.distance_metrics[self.distance]
            if self.distance == 'dtw':
                distances = cdist_dtw(X, n_jobs=self.n_jobs, **self.distance_params)
            elif self.distance == 'softdtw':
                distances = cdist_soft_dtw(X, **self.distance_params)
            elif self.distance == 'euclidean':
                X_flat = X.reshape((len(X), -1))
                distances = np.array([
                    [np.linalg.norm(x - y) for y in X_flat] for x in X_flat
                ])
            elif callable(metric):
                distances = self._parallel_distance_computation(X, metric)
        elif callable(self.distance):
            distances = self._parallel_distance_computation(X, self.distance)
        else:
            raise ValueError("Distance must be either a string or a callable")
        
        return distances
    
    def _parallel_distance_computation(self, X: np.ndarray, metric: Callable) -> np.ndarray:
        n_samples = len(X)
        
        def compute_distances(start, end):
            sub_matrix = np.zeros((end - start, n_samples))
            for i in range(start, end):
                for j in range(i, n_samples):
                    dist = metric(X[i], X[j], **self.distance_params)
                    sub_matrix[i - start, j] = dist
                    if i != j:
                        sub_matrix[j - start, i] = dist
            return sub_matrix

        chunk_size = max(1, n_samples // (4 * self.n_jobs))
        chunks = [(i, min(i + chunk_size, n_samples)) for i in range(0, n_samples, chunk_size)]
        
        results = Parallel(n_jobs=self.n_jobs)(
            delayed(compute_distances)(start, end) for start, end in chunks
        )
        
        distances = np.vstack(results)
        
        return distances
    
    def chinese_whispers_clustering(self, X: np.ndarray, distance_matrix: np.ndarray) -> np.ndarray:
        start_time = time.time()
        logger.info("Performing Chinese Whispers clustering...")
        n_samples = distance_matrix.shape[0]
        
        sigma = np.std(distance_matrix)
        similarity_matrix = np.exp(-distance_matrix ** 2 / (2 * sigma ** 2))

        G = nx.Graph()
        for i in range(n_samples):
            for j in range(i + 1, n_samples):
                weight = similarity_matrix[i, j]
                if weight > 0:
                    G.add_edge(i, j, weight=weight)

        iterations = self.algo_params.get('iterations', 20)
        weighting = self.algo_params.get('weighting', 'top')
        chinese_whispers(G, weighting=weighting, iterations=iterations)
        self.G = G

        labels = np.array([G.nodes[node]['label'] for node in G.nodes()])
        unique_labels = np.unique(labels)
        label_mapping = {label: idx for idx, label in enumerate(unique_labels)}
        labels_mapped = np.array([label_mapping[label] for label in labels])

        self.cluster_centers = np.array([
            X[labels_mapped == label][
                np.argmin(distance_matrix[np.ix_(labels_mapped == label, labels_mapped == label)].sum(axis=1))
            ] for label in unique_labels
        ])

        logger.info(f"Chinese Whispers clustering completed in {time.time() - start_time:.2f} seconds.")
        return labels_mapped
    def _get_valid_params(self, method):
        if method in ['dtw', 'softdtw', 'lcss', 'erp', 'edr', 'msm', 'twe']:
            return ['gamma', 'epsilon', 'window_size']  # Add more parameters as needed
        elif method in ['kmeans', 'kmedoids']:
            return ['n_clusters', 'max_iter']
        elif method == 'agglomerative':
            return ['distance_threshold', 'linkage']
        elif method in ['dbscan', 'optics']:
            return ['eps', 'min_samples']
        elif method == 'affinity_propagation':
            return ['damping', 'preference', 'max_iter']
        elif method == 'chinese_whispers':
            return ['weight_threshold']
        else:
            return []
        
    def get_params(self, deep=True):
        return {
            'n_jobs': self.n_jobs,
            'random_state': self.random_state,
            'optimization_metric': self.optimization_metric,
            'optimization_method': self.optimization_method,
            'distance': self.distance,
            'distance_params': self.distance_params,
            'algorithm': self.algorithm,
            'algo_params': self.algo_params
        }

    def set_params(self, **params):
        for param, value in params.items():
            setattr(self, param, value)
        return self

def main():
    datasets = {
        'small': make_blobs(n_samples=100, n_features=10, centers=3, random_state=42)[0],
        'medium': make_blobs(n_samples=1000, n_features=20, centers=5, random_state=42)[0],
        'large': make_blobs(n_samples=5000, n_features=50, centers=10, random_state=42)[0]
    }

    distance_metrics = {
        'euclidean': {},
        'dtw': {'window': 0.1},
        'softdtw': {'gamma': 0.1},
        'lcss': {'epsilon': 0.1},
        'erp': {'g': 0.1},
        'edr': {'epsilon': 0.1},
        'msm': {'c': 0.1},
        'twe': {'nu': 0.1, 'lambda': 0.5}
    }

    for dataset_name, dataset in datasets.items():
        print(f"\nTesting on {dataset_name} dataset (shape: {dataset.shape})")
        
        for metric, params in distance_metrics.items():
            print(f"\nTesting {metric} distance with parameters: {params}")
            
            try:
                predictor = TimeSeriesClusterPredictor(distance=metric, distance_params=params)
                
                start_time = time.time()
                distance_matrix = predictor.compute_distance_matrix(dataset)
                end_time = time.time()
                
                calculation_time = end_time - start_time
                
                assert distance_matrix.shape == (len(dataset), len(dataset)), "Incorrect shape of distance matrix"
                assert np.allclose(distance_matrix, distance_matrix.T), "Distance matrix is not symmetric"
                assert np.all(np.diag(distance_matrix) == 0), "Diagonal of distance matrix is not all zeros"
                
                print(f"  Calculation time: {calculation_time:.4f} seconds")
                print(f"  Matrix shape: {distance_matrix.shape}")
                print(f"  Min distance: {np.min(distance_matrix):.4f}")
                print(f"  Max distance: {np.max(distance_matrix):.4f}")
                print(f"  Mean distance: {np.mean(distance_matrix):.4f}")
                
                cache_start_time = time.time()
                cached_distance_matrix = predictor.compute_distance_matrix(dataset)
                cache_end_time = time.time()
                cache_calculation_time = cache_end_time - cache_start_time
                
                assert np.array_equal(distance_matrix, cached_distance_matrix), "Cached matrix doesn't match original"
                print(f"  Cached calculation time: {cache_calculation_time:.4f} seconds")
                
            except Exception as e:
                print(f"  Error occurred: {str(e)}")

if __name__ == "__main__":
    main()