import numpy as np
from joblib import Parallel, delayed, dump, load
from sklearn.base import BaseEstimator, ClusterMixin
from sklearn.metrics import silhouette_score, calinski_harabasz_score, davies_bouldin_score
from tslearn.metrics import cdist_dtw, cdist_soft_dtw
from aeon.distances import (dtw_distance, lcss_distance, erp_distance,
                            edr_distance, msm_distance, twe_distance)
from aeon.clustering import TimeSeriesKMeans, TimeSeriesKMedoids
from sklearn.cluster import AgglomerativeClustering, DBSCAN, AffinityPropagation
from chinese_whispers import chinese_whispers, aggregate_clusters
import networkx as nx
from typing import Dict, List, Union, Optional, Callable
import os
import hashlib
import logging
import time

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class TimeSeriesClusterPredictor(BaseEstimator, ClusterMixin):
    def __init__(
        self,
        distance: Union[str, Callable] = 'dtw',
        distance_params: Optional[Dict] = None,
        algorithm: str = 'kmeans',
        algo_params: Optional[Dict] = None,
        n_jobs: int = -1,
        random_state: Optional[int] = None,
        optimization_metric: str = 'combined'
    ):
        self.distance = distance
        self.distance_params = distance_params if distance_params is not None else {}
        self.algorithm = algorithm
        self.algo_params = algo_params if algo_params is not None else {}
        self.n_jobs = n_jobs
        self.random_state = random_state
        self.optimization_metric = optimization_metric
        
        self.distance_metrics = {
            'dtw': dtw_distance,
            'softdtw': cdist_soft_dtw,
            'euclidean': 'euclidean',
            'lcss': lcss_distance,
            'erp': erp_distance,
            'edr': edr_distance,
            'msm': msm_distance,
            'twe': twe_distance,
        }
        
        self.clustering_algorithms = {
            'kmeans': TimeSeriesKMeans,
            'kmedoids': TimeSeriesKMedoids,
            'agglomerative': AgglomerativeClustering,
            'dbscan': DBSCAN,
            'affinity_propagation': AffinityPropagation,
            'chinese_whispers': self.chinese_whispers_clustering
        }
        
        self.best_model = None
        self.cluster_centers_ = None
        self.outlier_threshold = None
        self.labels_ = None
        self.distance_matrix_cache = None

    def compute_distance_matrix(self, X: np.ndarray, cache_path: Optional[str] = None) -> np.ndarray:
        logger.info(f"Computing distance matrix using distance={self.distance}")
        start_time = time.time()
        
        if cache_path and os.path.exists(cache_path):
            logger.info(f"Loading distance matrix from cache: {cache_path}")
            with open(cache_path, 'rb') as f:
                self.distance_matrix_cache = load(f)
            logger.info(f"Loaded cached distance matrix in {time.time() - start_time:.2f} seconds")
            return self.distance_matrix_cache
        
        if self.distance_matrix_cache is not None:
            return self.distance_matrix_cache
        
        self.distance_matrix_cache = self._compute_full_distance_matrix(X)
        
        if cache_path:
            logger.info(f"Saving distance matrix to cache: {cache_path}")
            with open(cache_path, 'wb') as f:
                dump(self.distance_matrix_cache, f)
        
        logger.info(f"Computed distance matrix in {time.time() - start_time:.2f} seconds")
        return self.distance_matrix_cache

    def _compute_full_distance_matrix(self, X: np.ndarray) -> np.ndarray:
        n_samples = len(X)
        distances = np.zeros((n_samples, n_samples))

        if isinstance(self.distance, str):
            metric = self.distance_metrics[self.distance]
            if self.distance == 'dtw':
                distances = cdist_dtw(X, n_jobs=self.n_jobs, **self.distance_params)
            elif self.distance == 'softdtw':
                distances = cdist_soft_dtw(X, **self.distance_params)
            elif self.distance == 'euclidean':
                X_flat = X.reshape((len(X), -1))
                distances = np.array([
                    [np.linalg.norm(x - y) for y in X_flat] for x in X_flat
                ])
            elif callable(metric):
                distances = self._parallel_distance_computation(X, metric)
        elif callable(self.distance):
            distances = self._parallel_distance_computation(X, self.distance)
        else:
            raise ValueError("Distance must be either a string or a callable")
        
        return distances

    def _parallel_distance_computation(self, X: np.ndarray, metric: Callable) -> np.ndarray:
        n_samples = len(X)
        
        def compute_distances(start, end):
            sub_matrix = np.zeros((end - start, n_samples))
            for i in range(start, end):
                for j in range(n_samples):
                    sub_matrix[i - start, j] = metric(X[i], X[j], **self.distance_params)
            return sub_matrix

        chunk_size = max(1, n_samples // (4 * max(1, self.n_jobs)))
        chunks = [(i, min(i + chunk_size, n_samples)) for i in range(0, n_samples, chunk_size)]
        
        results = Parallel(n_jobs=self.n_jobs)(
            delayed(compute_distances)(start, end) for start, end in chunks
        )
        
        return np.vstack(results)

    def fit(self, X: np.ndarray, y=None, cache_path: Optional[str] = None):
        logger.info(f"Fitting the clustering model using algorithm={self.algorithm}")
        start_time = time.time()
        
        if len(X) == 0:
            raise ValueError("Input data X is empty")
        
        self.X_ = X
        distance_cache_key = hashlib.md5(f"{self.distance}_{self.distance_params}".encode()).hexdigest()
        cache_path = f"{cache_path}_{distance_cache_key}.pkl" if cache_path else None
        distance_matrix = self.compute_distance_matrix(X, cache_path)

        if self.algorithm in self.clustering_algorithms:
            if self.algorithm == 'chinese_whispers':
                self.labels_ = self.chinese_whispers_clustering(X, distance_matrix)
            else:
                clusterer = self.clustering_algorithms[self.algorithm](
                    **self.algo_params,
                    random_state=self.random_state
                )
                if self.algorithm in ['kmeans', 'kmedoids']:
                    self.labels_ = clusterer.fit_predict(X)
                else:
                    self.labels_ = clusterer.fit_predict(distance_matrix)
        else:
            raise ValueError(f"Unsupported clustering algorithm: {self.algorithm}")

        self.best_model = clusterer
        self._compute_cluster_centers(X)
        self._compute_outlier_threshold(X)

        logger.info(f"Fitted the clustering model in {time.time() - start_time:.2f} seconds")
        return self

    def _compute_cluster_centers(self, X: np.ndarray):
        if hasattr(self.best_model, 'cluster_centers_'):
            self.cluster_centers_ = self.best_model.cluster_centers_
        else:
            unique_labels = np.unique(self.labels_)
            self.cluster_centers_ = np.array([
                X[self.labels_ == label].mean(axis=0) for label in unique_labels if label != -1
            ])

    def _compute_outlier_threshold(self, X: np.ndarray):
        if self.cluster_centers_ is not None:
            distances = self._compute_distances_to_centers(X)
            self.outlier_threshold = np.percentile(distances.min(axis=1), 95)

    def _compute_distances_to_centers(self, X: np.ndarray) -> np.ndarray:
        logger.info("Computing distances to cluster centers")
        start_time = time.time()
        
        if self.distance in self.distance_metrics:
            metric = self.distance_metrics[self.distance]
        elif callable(self.distance):
            metric = self.distance
        else:
            raise ValueError(f"Unsupported distance metric: {self.distance}")

        def compute_distances_for_chunk(chunk_start, chunk_end):
            chunk_distances = np.zeros((chunk_end - chunk_start, len(self.cluster_centers_)))
            for i, x in enumerate(X[chunk_start:chunk_end]):
                for j, center in enumerate(self.cluster_centers_):
                    if callable(metric):
                        chunk_distances[i, j] = metric(x, center, **self.distance_params)
                    elif metric == 'euclidean':
                        chunk_distances[i, j] = np.linalg.norm(x - center)
                    else:
                        raise ValueError(f"Unsupported distance metric: {self.distance}")
            return chunk_distances

        n_samples = len(X)
        chunk_size = max(1, n_samples // (4 * self.n_jobs))
        chunks = [(i, min(i + chunk_size, n_samples)) for i in range(0, n_samples, chunk_size)]

        distances = Parallel(n_jobs=self.n_jobs)(
            delayed(compute_distances_for_chunk)(start, end) for start, end in chunks
        )

        distances = np.vstack(distances)

        logger.info(f"Computed distances to cluster centers in {time.time() - start_time:.2f} seconds")
        return distances

    def predict(self, X: np.ndarray) -> np.ndarray:
        logger.info("Predicting cluster labels for new data points")
        start_time = time.time()
        
        if not hasattr(self.best_model, 'predict') and self.cluster_centers_ is None:
            raise ValueError("Model is not fitted yet. Call 'fit' before using this method.")

        if X.shape[1:] != self.X_.shape[1:]:
            logger.warning("The number of features in X does not match the training data.")

        if hasattr(self.best_model, 'predict'):
            labels = self.best_model.predict(X)
        else:
            distances = self._compute_distances_to_centers(X)
            labels = distances.argmin(axis=1)

        if self.outlier_threshold is not None:
            logger.info("Identifying outliers based on threshold")
            outliers = distances.min(axis=1) > self.outlier_threshold
            labels[outliers] = -1

        logger.info(f"Predicted cluster labels in {time.time() - start_time:.2f} seconds")
        return labels

    def chinese_whispers_clustering(self, X: np.ndarray, distance_matrix: np.ndarray) -> np.ndarray:
        logger.info("Applying Chinese Whispers clustering algorithm")
        start_time = time.time()
        
        n_samples = distance_matrix.shape[0]
        sigma = np.std(distance_matrix)
        similarity_matrix = np.exp(-distance_matrix ** 2 / (2 * sigma ** 2))

        G = nx.Graph()
        for i in range(n_samples):
            for j in range(i + 1, n_samples):
                weight = similarity_matrix[i, j]
                if weight > 0:
                    G.add_edge(i, j, weight=weight)

        iterations = self.algo_params.get('iterations', 20)
        weighting = self.algo_params.get('weighting', 'top')
        chinese_whispers(G, weighting=weighting, iterations=iterations)

        labels = np.array([G.nodes[node]['label'] for node in G.nodes()])
        unique_labels = np.unique(labels)
        label_mapping = {label: idx for idx, label in enumerate(unique_labels)}
        labels_mapped = np.array([label_mapping[label] for label in labels])

        logger.info(f"Applied Chinese Whispers clustering in {time.time() - start_time:.2f} seconds")
        return labels_mapped

    def _compute_optimization_score(self, X: np.ndarray, X_test: Optional[np.ndarray] = None) -> float:
        logger.info("Computing optimization score")
        start_time = time.time()
        
        silhouette = silhouette_score(X, self.labels_)
        calinski_harabasz = calinski_harabasz_score(X, self.labels_)
        davies_bouldin = davies_bouldin_score(X, self.labels_)

        davies_bouldin_normalized = 1 / (1 + davies_bouldin)
        combined_score = (silhouette + calinski_harabasz / 1000 + davies_bouldin_normalized) / 3

        if X_test is not None:
            test_labels = self.predict(X_test)
            outlier_ratio = np.sum(test_labels == -1) / len(test_labels)
            combined_score *= (1 - outlier_ratio)

        logger.info(f"Computed optimization score in {time.time() - start_time:.2f} seconds")
        
        if self.optimization_metric == 'combined':
            return combined_score
        elif self.optimization_metric == 'silhouette':
            return silhouette
        elif self.optimization_metric == 'calinski_harabasz':
            return calinski_harabasz
        elif self.optimization_metric == 'davies_bouldin':
            return davies_bouldin_normalized
        else:
            raise ValueError(f"Unsupported optimization metric: {self.optimization_metric}")

    # ... (previous TimeSeriesClusterPredictor class implementation remains the same)

from sklearn.model_selection import GridSearchCV
from sklearn.experimental import enable_halving_search_cv
from sklearn.model_selection import HalvingGridSearchCV
from skopt import BayesSearchCV
from skopt.space import Real, Categorical, Integer

def optimize_clustering(X: np.ndarray, X_test: Optional[np.ndarray] = None,
                        search_method: str = 'grid', n_iter: int = 50, cv: int = 3,
                        cache_path: Optional[str] = None):
    logger.info(f"Starting clustering optimization using {search_method} search")
    
    param_grid = {
        'distance': ['dtw', 'softdtw', 'euclidean', 'lcss', 'erp', 'edr', 'msm', 'twe'],
        'algorithm': ['kmeans', 'kmedoids', 'agglomerative', 'dbscan', 'affinity_propagation', 'chinese_whispers'],
        'algo_params__n_clusters': range(2, 11),
        'distance_params__sakoe_chiba_radius': [None, 1, 5, 10],
        'distance_params__gamma': [0.1, 1.0, 10.0],
        'distance_params__epsilon': [0.1, 0.5, 1.0],
        'distance_params__g': [0.0, 0.5, 1.0],
        'distance_params__c': [0.1, 1.0, 10.0],
        'distance_params__nu': [0.001, 0.01, 0.1],
        'distance_params__lambda': [0.1, 1.0, 10.0],
        'algo_params__max_iter': [100, 300, 500],
        'algo_params__linkage': ['ward', 'complete', 'average', 'single'],
        'algo_params__eps': [0.1, 0.5, 1.0],
        'algo_params__min_samples': [2, 5, 10],
        'algo_params__damping': [0.5, 0.7, 0.9],
        'algo_params__preference': ['median', 'mean', None],
        'algo_params__iterations': [10, 20, 50],
        'algo_params__weighting': ['top', 'lin', 'log'],
    }

    estimator = TimeSeriesClusterPredictor()

    if search_method == 'grid':
        search = GridSearchCV(
            estimator,
            param_grid,
            cv=cv,
            n_jobs=-1,
            verbose=2
        )
    elif search_method == 'halving_grid':
        search = HalvingGridSearchCV(
            estimator,
            param_grid,
            cv=cv,
            n_jobs=-1,
            verbose=2
        )
    elif search_method == 'bayes':
        search_spaces = {
            'distance': Categorical(['dtw', 'softdtw', 'euclidean', 'lcss', 'erp', 'edr', 'msm', 'twe']),
            'algorithm': Categorical(['kmeans', 'kmedoids', 'agglomerative', 'dbscan', 'affinity_propagation', 'chinese_whispers']),
            'algo_params__n_clusters': Integer(2, 10),
            'distance_params__sakoe_chiba_radius': Categorical([None, 1, 5, 10]),
            'distance_params__gamma': Real(0.1, 10.0, prior='log-uniform'),
            'distance_params__epsilon': Real(0.1, 1.0, prior='uniform'),
            'distance_params__g': Real(0.0, 1.0, prior='uniform'),
            'distance_params__c': Real(0.1, 10.0, prior='log-uniform'),
            'distance_params__nu': Real(0.001, 0.1, prior='log-uniform'),
            'distance_params__lambda': Real(0.1, 10.0, prior='log-uniform'),
            'algo_params__max_iter': Integer(100, 500),
            'algo_params__linkage': Categorical(['ward', 'complete', 'average', 'single']),
            'algo_params__eps': Real(0.1, 1.0, prior='uniform'),
            'algo_params__min_samples': Integer(2, 10),
            'algo_params__damping': Real(0.5, 0.9, prior='uniform'),
            'algo_params__preference': Categorical(['median', 'mean', None]),
            'algo_params__iterations': Integer(10, 50),
            'algo_params__weighting': Categorical(['top', 'lin', 'log']),
        }
        search = BayesSearchCV(
            estimator,
            search_spaces,
            n_iter=n_iter,
            cv=cv,
            n_jobs=-1,
            verbose=2
        )
    else:
        raise ValueError(f"Unsupported search method: {search_method}")

    search.fit(X)

    best_model = search.best_estimator_
    best_params = search.best_params_
    best_score = search.best_score_

    if X_test is not None:
        test_score = best_model._compute_optimization_score(X, X_test)
        logger.info(f"Test score: {test_score}")

    logger.info(f"Optimization complete with best score: {best_score}")
    return best_model, best_params, best_score

# Example usage
if __name__ == "__main__":
    from sklearn.model_selection import train_test_split
    from sklearn.preprocessing import StandardScaler
    
    # Generate synthetic time series data
    n_samples = 1000
    n_features = 10
    n_timesteps = 50
    X = np.random.randn(n_samples, n_timesteps, n_features)
    
    # Split the data into training and testing sets
    X_train, X_test = train_test_split(X, test_size=0.2, random_state=42)
    
    # Normalize the data
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train.reshape(-1, n_features)).reshape(X_train.shape)
    X_test_scaled = scaler.transform(X_test.reshape(-1, n_features)).reshape(X_test.shape)
    
    # Perform parameter search using different methods
    search_methods = ['grid', 'halving_grid', 'bayes']
    
    for method in search_methods:
        logger.info(f"\nPerforming {method} search...")
        best_model, best_params, best_score = optimize_clustering(
            X_train_scaled, 
            X_test_scaled, 
            search_method=method, 
            n_iter=50 if method == 'bayes' else None
        )
        
        logger.info(f"Best parameters: {best_params}")
        logger.info(f"Best score: {best_score}")
        
        # Use the best model for prediction
        train_labels = best_model.labels_
        test_labels = best_model.predict(X_test_scaled)
        
        logger.info(f"Number of clusters: {len(np.unique(train_labels))}")
        logger.info(f"Number of outliers in test set: {np.sum(test_labels == -1)}")

    # Compare results
    logger.info("\nComparison of search methods:")
    for method in search_methods:
        _, best_params, best_score = optimize_clustering(
            X_train_scaled, 
            X_test_scaled, 
            search_method=method, 
            n_iter=50 if method == 'bayes' else None
        )
        logger.info(f"{method}: Best score = {best_score}, Best params = {best_params}")