import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from matplotlib.colors import ListedColormap  # Add this line

from sklearn.metrics import confusion_matrix, classification_report, accuracy_score
from sklearn.ensemble import RandomForestClassifier
import xgboost as xgb
import lightgbm as lgb
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import TimeSeriesSplit, GridSearchCV
from sklearn.preprocessing import StandardScaler

# For HMM
from hmmlearn import hmm

# For UKF and Particle Filter
from filterpy.kalman import UnscentedKalmanFilter, MerweScaledSigmaPoints
from filterpy.monte_carlo import systematic_resample
import pfilter
from pfilter import ParticleFilter,squared_error
from pfilter import gaussian_noise
# For seasonality analysis
from statsmodels.tsa.seasonal import seasonal_decompose
from statsmodels.graphics.tsaplots import plot_acf, plot_pacf
from scipy import signal

# For statistical functions
import scipy.stats
# For statistical functions
import scipy.stats
from darts.utils.statistics import check_seasonality
from darts import TimeSeries
from sklearn.neighbors import KNeighborsClassifier
class StabilityAnalyser:
    def __init__(self, data):
        """
        Initialize the StabilityAnalyser with the input data.

        Parameters:
        - data (pd.DataFrame): DataFrame with columns ['date', 'client_id', 'cluster', 'average_monthly_balance', 'monthly_std']
        """
        self.data = data.copy()
        self.data['date'] = pd.to_datetime(self.data['date'])
        self.preprocessed = False
        self.stability_scores = None
        self.model_results = {}
        self.cluster_map = {}
        self.inverse_cluster_map = {}
        self.models = {}
        self.label_encoder = None

    def preprocess_data(self):
        """
        Preprocess the input data to prepare it for analysis.
        """
        # Sort data
        self.data.sort_values(['client_id', 'date'], inplace=True)

        # Create 'month_str' column
        self.data['month_str'] = self.data['date'].dt.strftime('%Y_%m')
        print(self.data.head(10))
        # Pivot data to have clients as rows and months as columns for clusters
        cluster_pivot = self.data.pivot(index='client_id', columns='month_str', values='cluster')
       
        # Pivot data for average_monthly_balance
        balance_mean_pivot = self.data.pivot(index='client_id', columns='month_str', values='average_monthly_balance')
        # Pivot data for monthly_std
        balance_std_pivot = self.data.pivot(index='client_id', columns='month_str', values='monthly_std')

        # Sort columns chronologically
        cluster_pivot = cluster_pivot.sort_index(axis=1)
        balance_mean_pivot = balance_mean_pivot.sort_index(axis=1)
        balance_std_pivot = balance_std_pivot.sort_index(axis=1)
        # print(cluster_pivot)
        # print('#################')
        # print(balance_mean_pivot)
        # print('#################')

        # Handle missing values
        # Fill missing clusters with a placeholder '-99'
        cluster_pivot.fillna(-99, inplace=True)
        # Fill missing balance stats with 0
        balance_mean_pivot.fillna(0, inplace=True)
        balance_std_pivot.fillna(0, inplace=True)

        # Encode clusters to numeric values
        self.all_clusters = sorted(self.data['cluster'].dropna().unique())
        self.cluster_map = {cluster: idx for idx, cluster in enumerate(self.all_clusters)}
        self.cluster_map[-99] = -99  # For missing values
        self.inverse_cluster_map = {idx: cluster for cluster, idx in self.cluster_map.items()}
        #print ('######## cluster map')
        cluster_pivot = cluster_pivot.applymap(lambda x: self.cluster_map.get(x, -99))
        print(cluster_pivot)
        # Store month columns
        self.month_cols = cluster_pivot.columns.tolist()

        # Store processed data
        self.cluster_pivot = cluster_pivot
        self.balance_mean_pivot = balance_mean_pivot
        self.balance_std_pivot = balance_std_pivot

        self.preprocessed = True
    def calculate_cluster_persistence(self):
        """
        Calculate the persistence of clients in the same cluster over time.
        """
        if not self.preprocessed:
            self.preprocess_data()

        # Remove rows with NaN in 'cluster' column
        self.data = self.data.dropna(subset=['cluster'])

        # Ensure 'cluster' column is of consistent type (e.g., string)
        self.data['cluster'] = self.data['cluster'].astype(str)

        # Ensure that 'cluster' is sorted by 'client_id' and 'date'
        self.data.sort_values(['client_id', 'date'], inplace=True)

        # Calculate if cluster changes for each client
        self.data['cluster_change'] = self.data.groupby('client_id')['cluster'].transform(lambda x: x != x.shift())

        # Since the first observation per client will be True (since there's no previous cluster), set it to False
        first_obs = self.data.groupby('client_id').head(1).index
        self.data.loc[first_obs, 'cluster_change'] = False

        # Calculate persistence rate per cluster
        persistence = self.data.groupby('cluster')['cluster_change'].apply(
            lambda x: 1 - x.sum() / x.count()
        )

        # Map cluster codes to labels if necessary
        # if hasattr(self, 'inverse_cluster_map'):
        #     # Ensure keys are strings
        #     self.inverse_cluster_map = {str(k): v for k, v in self.inverse_cluster_map.items()}
        #     persistence.index = persistence.index.map(self.inverse_cluster_map)

        # Print or store the persistence rates
        print("Cluster Persistence Rates:")
        print(persistence)

        self.cluster_persistence = persistence

    def calculate_annual_stability_scores(self):
        """
        Calculate annual stability scores for each client.
        """
        if not self.preprocessed:
            self.preprocess_data()

        # Extract years from month columns
        years = sorted(set(col.split('_')[0] for col in self.month_cols))

        # Initialize a DataFrame to store annual stability scores with client_id as the index
        stability_scores = pd.DataFrame(index=self.cluster_pivot.index)

        for year in years:
            # Get month columns for the year
            year_month_cols = [col for col in self.month_cols if col.startswith(year)]
            if len(year_month_cols) < 2:
                continue

            # Extract data for the year and handle missing values
            clusters_year = self.cluster_pivot[year_month_cols].replace(-99, np.nan)

            # Calculate transitions for the year
            transitions = clusters_year.diff(axis=1) != 0
            transitions = transitions.fillna(False)

            # Calculate total transitions and valid periods
            total_transitions = transitions.sum(axis=1)
            valid_periods = clusters_year.notna().sum(axis=1) - 1

            # Handle division by zero and invalid operations
            with np.errstate(divide='ignore', invalid='ignore'):
                stability_col = f'stability_{year}'
                stability_scores[stability_col] = 1 - (total_transitions / valid_periods)
                # Replace infinite and NaN values with 1 (fully stable)
                stability_scores[stability_col] = stability_scores[stability_col].replace([np.inf, -np.inf], np.nan)
                stability_scores[stability_col] = stability_scores[stability_col].fillna(1)

        # Calculate overall stability score
        stability_cols = [col for col in stability_scores.columns if col.startswith('stability_')]
        stability_scores['overall_stability'] = stability_scores[stability_cols].mean(axis=1)

        # Classify clients based on overall stability score
        stability_scores['classification'] = 'Moderate'
        stability_scores.loc[stability_scores['overall_stability'] >= 0.8, 'classification'] = 'Stable'
        stability_scores.loc[stability_scores['overall_stability'] < 0.5, 'classification'] = 'Unstable'

        # Reset index to include client_id as a column
        stability_scores = stability_scores.reset_index()
        self.stability_scores = stability_scores

    def construct_confusion_matrices(self):
        """
        Construct confusion matrices for each year.
        """
        if not self.preprocessed:
            self.preprocess_data()

        self.confusion_matrices = {}
        years = sorted(set(col.split('_')[0] for col in self.month_cols))
        labels = list(self.cluster_map.values())

        for year in years:
            # Prepare data for the year
            year_month_cols = [col for col in self.month_cols if col.startswith(year)]
            if len(year_month_cols) < 2:
                continue

            y_true = []
            y_pred = []
            for i in range(len(year_month_cols) - 1):
                current_month = year_month_cols[i]
                next_month = year_month_cols[i + 1]
                current_clusters = self.cluster_pivot[current_month]
                next_clusters = self.cluster_pivot[next_month]

                # Exclude missing values
                mask = (current_clusters != -99) & (next_clusters != -99)
                y_true.extend(next_clusters[mask])
                y_pred.extend(current_clusters[mask])

            # Compute confusion matrix
            cm = confusion_matrix(y_true, y_pred, labels=labels)
            self.confusion_matrices[year] = cm

            # Plot confusion matrix
            plt.figure(figsize=(8, 6))
            sns.heatmap(cm, annot=True, fmt='d', xticklabels=self.inverse_cluster_map.values(),
                        yticklabels=self.inverse_cluster_map.values(), cmap='Blues')
            plt.xlabel('Predicted Cluster (Current Month)')
            plt.ylabel('Actual Cluster (Next Month)')
            plt.title(f'Confusion Matrix for Year {year}')
            plt.show()

    def identify_instability_periods(self):
        """
        Identify periods with high instability and visualize transition patterns.
        """
        if not self.preprocessed:
            self.preprocess_data()

        # Calculate monthly transition rates
        monthly_transition_rates = {}
        for i in range(len(self.month_cols) - 1):
            current_month = self.month_cols[i]
            next_month = self.month_cols[i + 1]
            current_clusters = self.cluster_pivot[current_month]
            next_clusters = self.cluster_pivot[next_month]
            mask = (current_clusters != -99) & (next_clusters != -99)
            transitions = (current_clusters != next_clusters) & mask
            transition_rate = transitions.sum() / mask.sum()
            monthly_transition_rates[next_month] = transition_rate

        # Plot transition rates over time
        transition_df = pd.DataFrame(list(monthly_transition_rates.items()), columns=['Month', 'TransitionRate'])
        transition_df['Date'] = pd.to_datetime(transition_df['Month'], format='%Y_%m')
        transition_df.sort_values('Date', inplace=True)

        plt.figure(figsize=(12, 6))
        plt.plot(transition_df['Date'], transition_df['TransitionRate'], marker='o')
        plt.title('Monthly Cluster Transition Rates')
        plt.xlabel('Date')
        plt.ylabel('Transition Rate')
        plt.grid(True)
        plt.show()

        self.monthly_transition_rates = transition_df

    def analyze_transition_patterns(self):
        """
        Analyze transition patterns between clusters.
        """
        if not self.preprocessed:
            self.preprocess_data()

        # Aggregate transitions
        clusters = list(self.cluster_map.values())
        transition_counts = pd.DataFrame(0, index=clusters, columns=clusters)
        for i in range(len(self.month_cols) - 1):
            current_month = self.month_cols[i]
            next_month = self.month_cols[i + 1]
            current_clusters = self.cluster_pivot[current_month]
            next_clusters = self.cluster_pivot[next_month]
            mask = (current_clusters != -99) & (next_clusters != -99)
            transitions = pd.crosstab(current_clusters[mask], next_clusters[mask])
            transition_counts = transition_counts.add(transitions, fill_value=0)

        # Normalize to get probabilities
        transition_probs = transition_counts.div(transition_counts.sum(axis=1), axis=0)
        transition_probs.fillna(0, inplace=True)

        # Plot transition matrix
        plt.figure(figsize=(10, 8))
        sns.heatmap(transition_probs, annot=True, fmt='.2f', xticklabels=self.inverse_cluster_map.values(),
                    yticklabels=self.inverse_cluster_map.values(), cmap='viridis')
        plt.xlabel('Next Month Cluster')
        plt.ylabel('Current Month Cluster')
        plt.title('Cluster Transition Probabilities')
        plt.show()

        self.transition_probs = transition_probs

    def detect_seasonality(self):
        """
        Perform seasonality analysis on the proportion of clients in each cluster.
        """
        if not self.preprocessed:
            self.preprocess_data()

        # Aggregate cluster counts per month
        melted_data = self.cluster_pivot.reset_index().melt(
            id_vars='client_id',
            value_vars=self.month_cols,
            var_name='Month',
            value_name='Cluster'
        )
        cluster_counts = melted_data.groupby(['Month', 'Cluster']).size().reset_index(name='Count')

        # Calculate total clients per month
        total_clients_per_month = melted_data.groupby('Month')['client_id'].nunique().reset_index(name='TotalClients')

        # Merge total clients with cluster counts
        cluster_counts = cluster_counts.merge(total_clients_per_month, on='Month')

        # Calculate proportions
        cluster_counts['Proportion'] = cluster_counts['Count'] / cluster_counts['TotalClients']

        # Pivot to get time series for each cluster
        cluster_pivot = cluster_counts.pivot(index='Month', columns='Cluster', values='Proportion').fillna(0)

        # Convert 'Month' to datetime
        cluster_pivot.index = pd.to_datetime(cluster_pivot.index, format='%Y_%m')
        cluster_pivot = cluster_pivot.sort_index()

        # Perform seasonal decomposition for each cluster
        self.seasonality_results = {}
        for cluster in cluster_pivot.columns:
            ts = cluster_pivot[cluster]
            ts = ts.asfreq('M')
            ts = ts.fillna(0)

            # Check if the time series has enough data points and variation
            if ts.isnull().all() or ts.nunique() <= 1 or len(ts.dropna()) < 3:
                print(f"Not enough data points or variation for cluster {self.inverse_cluster_map.get(cluster, cluster)} to perform seasonality analysis.")
                continue

            # Perform seasonal decomposition
            try:
                decomposition = seasonal_decompose(ts, model='additive', period=12)
                self.seasonality_results[cluster] = decomposition

                # Plot decomposition
                decomposition.plot()
                plt.suptitle(f'Seasonal Decomposition for Cluster {self.inverse_cluster_map.get(cluster, cluster)}')
                plt.show()
            except ValueError as e:
                print(f"Seasonal decomposition failed for cluster {self.inverse_cluster_map.get(cluster, cluster)}: {e}")
                continue

            # Autocorrelation analysis
            max_lags = min(24, (len(ts.dropna()) // 2) - 1)
            if max_lags < 1:
                max_lags = 1  # Ensure at least 1 lag

            fig, ax = plt.subplots(2, 1, figsize=(12, 8))

            # Plot ACF
            try:
                plot_acf(ts, ax=ax[0], lags=max_lags)
                ax[0].set_title(f'Autocorrelation Function for Cluster {self.inverse_cluster_map.get(cluster, cluster)}')
            except Exception as e:
                print(f"ACF plot failed for cluster {self.inverse_cluster_map.get(cluster, cluster)}: {e}")
                plt.close(fig)
                continue

            # Plot PACF
            try:
                plot_pacf(ts, ax=ax[1], lags=max_lags, method='ywm')
                ax[1].set_title(f'Partial Autocorrelation Function for Cluster {self.inverse_cluster_map.get(cluster, cluster)}')
            except Exception as e:
                print(f"PACF plot failed for cluster {self.inverse_cluster_map.get(cluster, cluster)}: {e}")
                plt.close(fig)
                continue

            plt.tight_layout()
            plt.show()

            # Spectral analysis for the current cluster
            frequencies, power = signal.periodogram(ts.dropna())
            plt.figure(figsize=(10, 6))
            plt.plot(frequencies, power)
            plt.title(f'Periodogram for Cluster {self.inverse_cluster_map.get(cluster, cluster)}')
            plt.xlabel('Frequency')
            plt.ylabel('Power')
            plt.show()
    
    


    def detect_client_cluster_seasonality(self, sample_size=10):
        """
        Analyze seasonality of cluster assignments for each client using darts.
        """
        if not self.preprocessed:
            self.preprocess_data()
        
        # Randomly sample clients for visualization
        sampled_clients = np.random.choice(self.cluster_pivot.index, size=min(sample_size, len(self.cluster_pivot.index)), replace=False)
        
        # Initialize a list to store seasonality periods for each client
        client_seasonality = []
        
        for client_id in self.cluster_pivot.index:
            # Extract the client's cluster assignment time series
            ts = self.cluster_pivot.loc[client_id]
            ts = ts.replace(-99, np.nan).dropna()

            # Ensure the time series is long enough
            if len(ts) < 24:
                continue  # Skip clients with insufficient data

            # Ensure the index is a DatetimeIndex
            if not isinstance(ts.index, pd.DatetimeIndex):
                ts.index = pd.to_datetime(ts.index, format='%Y_%m')

            # Map clusters to integers
            cluster_labels = ts.unique()
            cluster_map = {cluster: idx for idx, cluster in enumerate(cluster_labels)}
            ts_numeric = ts.map(cluster_map)

            # Convert to darts TimeSeries
            ts_darts = TimeSeries.from_series(ts_numeric)

            # Check for seasonality
            is_seasonal, period = check_seasonality(ts_darts, max_lag=12)

            client_seasonality.append({
                'client_id': client_id,
                'is_seasonal': is_seasonal,
                'period': int(period) if is_seasonal else None
            })

            # Visualization for sampled clients
            if client_id in sampled_clients:
                plt.figure(figsize=(12, 4))
                plt.plot(ts.index, ts_numeric, marker='o')
                plt.title(f'Cluster Assignment Time Series for Client {client_id}')
                plt.xlabel('Time')
                plt.ylabel('Cluster (Encoded)')
                plt.show()

        # Convert to DataFrame
        client_seasonality_df = pd.DataFrame(client_seasonality)
        self.client_seasonality = client_seasonality_df

        print("Seasonality detection for clients (first 5):")
        print(client_seasonality_df.head())
    def analyze_seasonality_distribution(self):
        """
        Analyze and visualize the distribution of seasonality periods across clients.
        """
        if not hasattr(self, 'client_seasonality'):
            print("Client seasonality data not found. Run detect_client_cluster_seasonality() first.")
            return

        # Extract periods from client_seasonality
        seasonality_info = self.client_seasonality.dropna(subset=['period'])

        # Plot histogram of periods
        plt.figure(figsize=(10, 6))
        plt.hist(seasonality_info['period'], bins=range(1, 25), edgecolor='black', align='left')
        plt.title('Distribution of Detected Seasonality Periods Across Clients')
        plt.xlabel('Seasonality Period (Months)')
        plt.ylabel('Number of Clients')
        plt.xticks(range(1, 25))
        plt.show()

        # Print summary statistics
        print("Summary of Detected Seasonality Periods:")
        print(seasonality_info['period'].describe())
    def timeline_plots_individual_clients(self, client_ids=None, num_clients=5):
        """
        Create timeline plots for individual clients.

        Parameters:
        - client_ids (list): List of client IDs to plot. If None, randomly select clients.
        - num_clients (int): Number of clients to plot if client_ids is None.
        """
        if not self.preprocessed:
            self.preprocess_data()

        if client_ids is None:
            client_ids = np.random.choice(self.cluster_pivot.index, size=num_clients, replace=False)

        for client_id in client_ids:
            client_clusters = self.cluster_pivot.loc[client_id]
            client_clusters = client_clusters.replace(-99, np.nan)
            client_clusters = client_clusters.map(self.inverse_cluster_map)
            dates = pd.to_datetime(self.month_cols, format='%Y_%m')

            plt.figure(figsize=(12, 4))
            plt.plot(dates, client_clusters, marker='o')
            plt.title(f'Cluster Assignments Over Time for Client {client_id}')
            plt.xlabel('Date')
            plt.ylabel('Cluster')
            plt.xticks(rotation=45)
            plt.grid(True)
            plt.show()

    def heatmap_cluster_assignments(self):
        """
        Create a heatmap of cluster assignments for a sample of clients.
        """
        if not self.preprocessed:
            self.preprocess_data()

        # Sample clients
        sample_size = min(100, len(self.cluster_pivot))  # Ensure sample size doesn't exceed available clients
        sampled_clients = np.random.choice(
            self.cluster_pivot.index, size=sample_size, replace=False
        )
        heatmap_data = self.cluster_pivot.loc[sampled_clients]
        heatmap_data = heatmap_data.replace(-99, np.nan)

        # Prepare cluster codes and labels
        unique_codes = sorted(heatmap_data.stack().dropna().unique())
        num_clusters = len(unique_codes)

        # Ensure the keys in inverse_cluster_map are of the same type as unique_codes
        # If unique_codes are integers, convert keys in inverse_cluster_map to integers
        # First, check the data type of unique_codes
        code_dtype = type(unique_codes[0])

        if hasattr(self, 'inverse_cluster_map'):
            # Convert keys in inverse_cluster_map to match code_dtype
            self.inverse_cluster_map = {code_dtype(k): v for k, v in self.inverse_cluster_map.items()}

            # Create code_to_label mapping
            code_to_label = {code: self.inverse_cluster_map[code] for code in unique_codes}
        else:
            # If inverse_cluster_map doesn't exist, use default mapping
            code_to_label = {code: f"Cluster_{code}" for code in unique_codes}

        # Map cluster codes to labels in heatmap_data
        heatmap_data_mapped = heatmap_data.applymap(lambda x: code_to_label.get(x, np.nan))

        # Create a numerical representation for the heatmap
        label_to_num = {label: idx for idx, label in enumerate(sorted(code_to_label.values()))}
        heatmap_data_numeric = heatmap_data_mapped.applymap(lambda x: label_to_num.get(x, np.nan))

        # Plot heatmap
        plt.figure(figsize=(15, 10))
        sns.heatmap(
            heatmap_data_numeric,
            cmap='viridis',
            cbar_kws={'ticks': list(label_to_num.values()), 'label': 'Cluster'},
            yticklabels=False
        )

        # Set colorbar labels to cluster names
        colorbar = plt.gca().collections[0].colorbar
        colorbar.set_ticks(list(label_to_num.values()))
        colorbar.set_ticklabels(list(label_to_num.keys()))

        plt.title('Heatmap of Cluster Assignments for Sampled Clients')
        plt.xlabel('Month')
        plt.ylabel('Clients')
        plt.show()
        
    def distribution_of_stability_scores(self):
        """
        Visualize the distribution of stability scores.
        """
        if self.stability_scores is None:
            self.calculate_annual_stability_scores()

        plt.figure(figsize=(10, 6))
        sns.histplot(self.stability_scores['overall_stability'], bins=20, kde=True)
        plt.title('Distribution of Overall Stability Scores')
        plt.xlabel('Overall Stability Score')
        plt.ylabel('Frequency')
        plt.show()

    def annual_cluster_distribution(self):
        """
        Plot year-over-year cluster distribution.
        """
        if not self.preprocessed:
            self.preprocess_data()

        # Aggregate cluster counts per year
        years = sorted(set(col.split('_')[0] for col in self.month_cols))
        cluster_distribution = pd.DataFrame()

        for year in years:
            year_month_cols = [col for col in self.month_cols if col.startswith(year)]
            clusters_in_year = self.cluster_pivot[year_month_cols].stack().replace(-99, np.nan).dropna()
            cluster_counts = clusters_in_year.value_counts(normalize=True).sort_index()
            cluster_distribution[year] = cluster_counts

        cluster_distribution = cluster_distribution.transpose()
        cluster_distribution.index.name = 'Year'

        # Plot
        cluster_distribution.plot(kind='bar', stacked=True, figsize=(12, 6), colormap='tab20')
        plt.title('Year-over-Year Cluster Distribution')
        plt.xlabel('Year')
        plt.ylabel('Proportion of Clients')
        plt.legend(title='Cluster', bbox_to_anchor=(1.05, 1), loc='upper left')
        plt.tight_layout()
        plt.show()

    def compile_report(self):
        """
        Compile findings into a summary report.
        """
        report = {}

        # Stability summary
        stability_summary = self.stability_scores['overall_stability'].describe()
        report['stability_summary'] = stability_summary

        # Classification counts
        classification_counts = self.stability_scores['classification'].value_counts()
        report['classification_counts'] = classification_counts

        # Transition patterns
        report['transition_patterns'] = self.transition_probs

        # Monthly transition rates
        report['monthly_transition_rates'] = self.monthly_transition_rates

        # You can add more details as needed

        self.report = report

    def feature_engineering(self):
        """
        Perform feature engineering for predictive modeling.
        """
        if not self.preprocessed:
            self.preprocess_data()

        # Prepare the modeling dataset
        feature_list = []
        for idx, row in self.cluster_pivot.iterrows():
            client_id = idx
            for i in range(2, len(self.month_cols) - 1):  # Start from index 2 to have t-2
                current_month = self.month_cols[i]
                next_month = self.month_cols[i + 1]
                prev_month = self.month_cols[i - 1]
                prev_prev_month = self.month_cols[i - 2]

                features = {
                    'client_id': client_id,
                    'current_month': current_month,
                    'next_month': next_month,
                    'cluster_t': row[current_month],
                    'cluster_t+1': row[next_month],
                    'cluster_t-1': row[prev_month],
                    'cluster_t-2': row[prev_prev_month],
                    'month': int(current_month.split('_')[1]),
                    'year': int(current_month.split('_')[0]),
                    'balance_mean_t': self.balance_mean_pivot.loc[client_id, current_month],
                    'balance_mean_t-1': self.balance_mean_pivot.loc[client_id, prev_month],
                    'balance_mean_t-2': self.balance_mean_pivot.loc[client_id, prev_prev_month],
                    'balance_std_t': self.balance_std_pivot.loc[client_id, current_month],
                    'balance_std_t-1': self.balance_std_pivot.loc[client_id, prev_month],
                    'balance_std_t-2': self.balance_std_pivot.loc[client_id, prev_prev_month],
                }

                # Exclude cases with missing clusters
                if -99 in [features['cluster_t'], features['cluster_t+1'], features['cluster_t-1'], features['cluster_t-2']]:
                    continue

                feature_list.append(features)

        self.model_df = pd.DataFrame(feature_list)

        # Merge stability classification
        if self.stability_scores is None:
            self.calculate_annual_stability_scores()
        self.model_df = self.model_df.merge(self.stability_scores[['client_id', 'classification']], on='client_id', how='left')

        # Encode clusters as strings for one-hot encoding
        cluster_cols = ['cluster_t', 'cluster_t-1', 'cluster_t-2', 'cluster_t+1']
        for col in cluster_cols:
            self.model_df[col] = self.model_df[col].astype(str)

        # One-hot encode categorical variables
        categorical_cols = ['cluster_t', 'cluster_t-1', 'cluster_t-2', 'month', 'classification']
        self.model_df_encoded = pd.get_dummies(self.model_df, columns=categorical_cols, drop_first=False)

        # Prepare features and target variable
        self.X = self.model_df_encoded.drop(['client_id', 'current_month', 'next_month', 'cluster_t+1'], axis=1)
        self.y = self.model_df['cluster_t+1']

        # Standardize numerical features
        scaler = StandardScaler()
        numerical_cols = ['balance_mean_t', 'balance_mean_t-1', 'balance_mean_t-2',
                          'balance_std_t', 'balance_std_t-1', 'balance_std_t-2']
        self.X[numerical_cols] = scaler.fit_transform(self.X[numerical_cols])

    def train_models(self):
        """
        Train multiple models for predicting next month's cluster assignments with fine-tuning and cross-validation.
        """
        if self.model_df is None:
            self.feature_engineering()

        # Time-based cross-validation
        tscv = TimeSeriesSplit(n_splits=5)

        # Label encode the target variable
        self.label_encoder = LabelEncoder()
        y_encoded = self.label_encoder.fit_transform(self.y)

        # Define hyperparameter grids for each model
        param_grids = {
            'RandomForest': {
                'n_estimators': [50, 100],
                'max_depth': [None, 10, 20],
                'min_samples_split': [2, 5]
            },
            'XGBoost': {
                'n_estimators': [50, 100],
                'max_depth': [3, 6],
                'learning_rate': [0.1, 0.01]
            },
            'LightGBM': {
                'n_estimators': [50, 100],
                'max_depth': [-1, 10],
                'learning_rate': [0.1, 0.01]
            }
        }

        # Initialize models
        models = {
            'RandomForest': RandomForestClassifier(random_state=42),
            'XGBoost': xgb.XGBClassifier(use_label_encoder=False, eval_metric='mlogloss', random_state=42),
            'LightGBM': lgb.LGBMClassifier(random_state=42)
        }

        # Train and fine-tune models using GridSearchCV
        for model_name, model in models.items():
            print(f"Training and fine-tuning {model_name}...")
            param_grid = param_grids[model_name]
            grid_search = GridSearchCV(
                estimator=model,
                param_grid=param_grid,
                cv=tscv,
                scoring='accuracy',
                n_jobs=-1
            )
            grid_search.fit(self.X, y_encoded)
            best_model = grid_search.best_estimator_
            self.models[model_name] = best_model

            # Store results
            self.model_results[model_name] = {
                'best_params': grid_search.best_params_,
                'cv_results': grid_search.cv_results_
            }

            print(f"Best parameters for {model_name}: {grid_search.best_params_}")

        # Evaluate models on the last fold of the TimeSeriesSplit
        train_index, test_index = list(tscv.split(self.X))[-1]
        X_train, X_test = self.X.iloc[train_index], self.X.iloc[test_index]
        y_train_encoded, y_test_encoded = y_encoded[train_index], y_encoded[test_index]

        for model_name, model in self.models.items():
            print(f"Evaluating {model_name} on the test set...")
            model.fit(X_train, y_train_encoded)
            y_pred_encoded = model.predict(X_test)
            y_pred = self.label_encoder.inverse_transform(y_pred_encoded)
            y_test = self.label_encoder.inverse_transform(y_test_encoded)

            # Evaluate
            accuracy = accuracy_score(y_test, y_pred)
            print(f"{model_name} Test Accuracy: {accuracy:.4f}")
            print(classification_report(y_test, y_pred))

            # Store predictions and actuals
            self.model_results[model_name]['y_test'] = y_test
            self.model_results[model_name]['y_pred'] = y_pred

        # Hidden Markov Model (HMM)
        #self.train_hmm()

        # State Space Models (UKF and Particle Filter)
        self.train_state_space_models()

    def train_hmm(self):
        """
        Train a Hidden Markov Model (HMM) for cluster prediction.
        """
        print("Training Hidden Markov Model (HMM)...")

        # Prepare sequences for HMM
        client_sequences = []
        lengths = []
        self.label_encoder_hmm = LabelEncoder()
        self.label_encoder_hmm.fit(self.model_df['cluster_t'].astype(str).unique())

        for client_id, group in self.model_df.groupby('client_id'):
            seq = group.sort_values('current_month')['cluster_t'].astype(str).values
            seq_encoded = self.label_encoder_hmm.transform(seq)
            client_sequences.append(seq_encoded)
            lengths.append(len(seq_encoded))

        X_hmm = np.concatenate(client_sequences).reshape(-1, 1)

        # Initialize and train the HMM model
        n_components = len(self.label_encoder_hmm.classes_)
        hmm_model = hmm.MultinomialHMM(n_components=n_components, n_iter=100, random_state=42)
        hmm_model.fit(X_hmm, lengths)
        self.models['HMM'] = hmm_model

        # Predict using HMM on the test set
        test_clients = self.model_df['client_id'].unique()
        y_test = []
        y_pred = []

        for client_id in test_clients:
            client_data = self.model_df[self.model_df['client_id'] == client_id]
            client_data = client_data.sort_values('current_month')
            seq = client_data['cluster_t'].astype(str).values
            seq_encoded = self.label_encoder_hmm.transform(seq).reshape(-1, 1)

            if len(seq_encoded) < 2:
                continue

            # Decode the sequence
            logprob, state_sequence = hmm_model.decode(seq_encoded[:-1])
            last_state = state_sequence[-1]
            next_state_prob = hmm_model.transmat_[last_state]
            predicted_state = np.argmax(next_state_prob)
            predicted_cluster = self.label_encoder_hmm.inverse_transform([predicted_state])[0]
            actual_cluster = client_data['cluster_t+1'].iloc[-1]

            y_pred.append(predicted_cluster)
            y_test.append(actual_cluster)

        # Evaluate
        print("HMM Model Performance:")
        print(classification_report(y_test, y_pred))

        # Store results
        self.model_results['HMM'] = {
            'y_test': y_test,
            'y_pred': y_pred
        }




    def train_state_space_models(self):
        """
        Train state space models using Particle Filter (with pfilter library) and UKF with multivariate inputs.
        """
        print("Training State Space Models (Particle Filter with pfilter library and UKF)...")

        # Prepare data for state space models
        # We'll use the balance features as state variables

        # Split data into train and test based on time
        tscv = TimeSeriesSplit(n_splits=5)
        splits = list(tscv.split(self.model_df))
        train_index, test_index = splits[-1]
        train_data = self.model_df.iloc[train_index].reset_index(drop=True)
        test_data = self.model_df.iloc[test_index].reset_index(drop=True)

        # Encode cluster labels to integers
        label_encoder = LabelEncoder()
        label_encoder.fit(self.model_df['cluster_t'].unique())
        train_data['cluster_t_enc'] = label_encoder.transform(train_data['cluster_t'])
        test_data['cluster_t_enc'] = label_encoder.transform(test_data['cluster_t'])
        test_data['cluster_t_plus1_enc'] = label_encoder.transform(test_data['cluster_t+1'])

        # Map cluster labels to indices
        clusters = sorted(train_data['cluster_t'].unique().tolist())
        cluster_label_to_index = {label: idx for idx, label in enumerate(clusters)}
        cluster_index_to_label = {idx: label for idx, label in enumerate(clusters)}

        # Prepare transition probabilities for clusters
        self.transition_probs.fillna(0, inplace=True)
        # Ensure clusters are ordered consistently
        self.transition_probs = self.transition_probs.reindex(index=clusters, columns=clusters, fill_value=0)
        cluster_transition_matrix = self.transition_probs.values

        # Define the state transition function (dynamics_fn)
        def dynamics_fn(state):
            """
            Transition function for the Particle Filter.
            Args:
                state (np.ndarray): Current state particles, shape (n_particles, state_dim)
            Returns:
                np.ndarray: Next state particles, shape (n_particles, state_dim)
            """
            cluster_idx = state[:, 0].astype(int)
            # Transition clusters based on the transition matrix
            next_cluster_idx = []
            for idx in cluster_idx:
                next_cluster_probs = cluster_transition_matrix[idx]
                if next_cluster_probs.sum() == 0:
                    # If no transition probabilities defined, assume uniform transition
                    next_cluster_probs = np.ones(len(clusters)) / len(clusters)
                else:
                    next_cluster_probs = next_cluster_probs / next_cluster_probs.sum()
                next_idx = np.random.choice(len(clusters), p=next_cluster_probs)
                next_cluster_idx.append(next_idx)
            next_cluster_idx = np.array(next_cluster_idx)

            # Return the updated state without adding noise
            new_state = np.vstack((next_cluster_idx, state[:, 1], state[:, 2])).T
            return new_state

        # Define the noise function (noise_fn)
        def noise_fn(state):
            """
            Noise function for the Particle Filter.
            Args:
                state (np.ndarray): Current state particles, shape (n_particles, state_dim)
            Returns:
                np.ndarray: Noise to add, shape (n_particles, state_dim)
            """
            # No noise for cluster_idx (first state variable)
            # Gaussian noise for balance_mean and balance_std
            noise = np.zeros_like(state)
            noise[:, 1] = np.random.normal(0, 0.1, size=state.shape[0])  # noise for balance_mean
            noise[:, 2] = np.random.normal(0, 0.1, size=state.shape[0])  # noise for balance_std
            return noise

        # Define the observation function (observe_fn)
        def observe_fn(state):
            """
            Observation function for the Particle Filter.
            Args:
                state (np.ndarray): Current state particles, shape (n_particles, state_dim)
            Returns:
                np.ndarray: Observed values, shape (n_particles,)
            """
            return state[:, 0].astype(int)  # Observe only the cluster index

        # Define the weight function (weight_fn)
        def weight_fn(state, observation):
            """
            Weight function for the Particle Filter.
            Computes the likelihood of the observation given the state.
            Args:
                state (np.ndarray): Current state particles, shape (n_particles, state_dim)
                observation (int): Current observation (cluster index)
            Returns:
                np.ndarray: Weights for each particle, shape (n_particles,)
            """
            # Cluster likelihood: 1.0 if matches, 0.1 otherwise
            cluster_likelihood = np.where(state[:, 0].astype(int) == observation, 1.0, 0.1)
            return cluster_likelihood

        # Define a custom state estimation function
        def estimate_cluster(particles, weights):
            """
            Estimate the cluster index based on particles and weights.
            Args:
                particles (np.ndarray): Array of particles, shape (n_particles, state_dim)
                weights (np.ndarray): Array of weights, shape (n_particles,)
            Returns:
                int: Estimated cluster index
            """
            # Extract cluster indices
            cluster_idxs = particles[:, 0].astype(int)
            # Calculate weighted counts for each cluster
            unique_clusters = np.unique(cluster_idxs)
            weighted_counts = {u: np.sum(weights[cluster_idxs == u]) for u in unique_clusters}
            if weighted_counts:
                # Return the cluster with the highest weighted count
                return max(weighted_counts, key=weighted_counts.get)
            else:
                # Fallback to first cluster
                return 0

        # # Initialize particles
        # num_particles = 1000
        # initial_particles = np.empty((num_particles, 3))
        # # Randomly initialize clusters based on uniform distribution
        # initial_clusters = np.random.choice(len(clusters), size=num_particles)
        # # Initialize balance features from training data distributions
        # initial_balance_mean = np.random.normal(
        #     train_data['balance_mean_t'].mean(),
        #     train_data['balance_mean_t'].std(),
        #     size=num_particles
        # )
        # initial_balance_std = np.random.normal(
        #     train_data['balance_std_t'].mean(),
        #     train_data['balance_std_t'].std(),
        #     size=num_particles
        # )
        # initial_particles[:, 0] = initial_clusters
        # initial_particles[:, 1] = initial_balance_mean
        # initial_particles[:, 2] = initial_balance_std

        # # Define the prior function
        # def prior_fn(n_particles):
        #     return initial_particles

        # # Create the Particle Filter
        # pf = ParticleFilter(
        #     prior_fn=prior_fn,
        #     dynamics_fn=dynamics_fn,     # Correct keyword argument
        #     observe_fn=observe_fn,
        #     noise_fn=noise_fn,
        #     weight_fn=weight_fn,
        #     n_particles=num_particles,
        #     resample_proportion=0.1
        # )

        # y_test_pf = []
        # y_pred_pf = []

        # # Run the Particle Filter over the test set
        # for idx, row in test_data.iterrows():
        #     # Prepare observation
        #     observed_cluster_label = row['cluster_t']
        #     if observed_cluster_label not in cluster_label_to_index:
        #         print(f"Skipping index {idx} due to unknown cluster label: {observed_cluster_label}")
        #         continue  # Skip if cluster label not found
        #     observed_cluster_idx = cluster_label_to_index[observed_cluster_label]
        #     observation = observed_cluster_idx  # Scalar observation

        #     # Update the Particle Filter with the observation
        #     try:
        #         pf.update(observation)
        #     except RuntimeError as e:
        #         print(f"RuntimeError at index {idx}: {e}")
        #         continue

        #     # Predict the next state
        #     pf.predict()

        #     # Estimate the next cluster as the weighted mode of cluster indices
        #     estimated_cluster_idx = estimate_cluster(pf.particles, pf.weights)
        #     predicted_cluster_label = cluster_index_to_label[estimated_cluster_idx]

        #     y_pred_pf.append(predicted_cluster_label)
        #     y_test_pf.append(row['cluster_t+1'])

        # # Encode labels for consistent reporting
        # y_test_pf_encoded = label_encoder.transform(y_test_pf)
        # y_pred_pf_encoded = label_encoder.transform(y_pred_pf)

        # # Evaluate Particle Filter Performance
        # print("Particle Filter Model Performance:")
        # print(classification_report(y_test_pf_encoded, y_pred_pf_encoded, target_names=label_encoder.classes_))

        # # Store results
        # self.model_results['ParticleFilter'] = {
        #     'y_test': y_test_pf_encoded,
        #     'y_pred': y_pred_pf_encoded
        # }

        # Implement UKF (same as before)
        print("Training Unscented Kalman Filter (UKF)...")

        # Define state transition function for UKF
        def fx(x, dt):
            balance_mean = x[0] + np.random.normal(0, 0.1)
            balance_std = x[1] + np.random.normal(0, 0.1)
            return np.array([balance_mean, balance_std])

        # Define measurement function for UKF
        def hx(x):
            return x

        # Initialize the UKF
        dim_x = 2  # balance_mean, balance_std
        dim_z = 2  # balance_mean, balance_std
        points = MerweScaledSigmaPoints(n=dim_x, alpha=0.1, beta=2.0, kappa=0)
        ukf = UnscentedKalmanFilter(dim_x=dim_x, dim_z=dim_z, fx=fx, hx=hx, dt=1.0, points=points)
        ukf.x = np.array([train_data['balance_mean_t'].mean(), train_data['balance_std_t'].mean()])
        ukf.P *= 1.0
        ukf.R *= 0.1  # Measurement noise
        ukf.Q *= 0.1  # Process noise

        # Train a classifier to predict cluster from balance features
        knn = KNeighborsClassifier(n_neighbors=5)
        X_train_features = train_data[['balance_mean_t', 'balance_std_t']].values
        y_train_clusters = train_data['cluster_t'].values
        knn.fit(X_train_features, y_train_clusters)

        y_test_ukf = []
        y_pred_ukf = []

        for idx, row in test_data.iterrows():
            # Measurement
            z = np.array([row['balance_mean_t'], row['balance_std_t']])
            # Update UKF with measurement
            ukf.predict()
            ukf.update(z)
            # Predict next state
            ukf.predict()
            predicted_state = ukf.x.copy()
            # Predict cluster
            predicted_cluster_label = knn.predict([predicted_state])[0]
            y_pred_ukf.append(predicted_cluster_label)
            y_test_ukf.append(row['cluster_t+1'])

        # Encode labels for UKF
        y_test_ukf_encoded = label_encoder.transform(y_test_ukf)
        y_pred_ukf_encoded = label_encoder.transform(y_pred_ukf)

        # Evaluate UKF Performance
        print("UKF Model Performance:")
        print(classification_report(y_test_ukf_encoded, y_pred_ukf_encoded, target_names=label_encoder.classes_))

        # Store results
        self.model_results['UKF'] = {
            'y_test': y_test_ukf_encoded,
            'y_pred': y_pred_ukf_encoded
        }
    def select_best_model(self):
            """
            Select the best model based on test accuracy.
            """
            best_model_name = None
            best_accuracy = 0
            for model_name, results in self.model_results.items():
                y_test = results['y_test']
                y_pred = results['y_pred']
                accuracy = accuracy_score(y_test, y_pred)
                print(f"{model_name} Test Accuracy: {accuracy:.4f}")
                if accuracy > best_accuracy:
                    best_accuracy = accuracy
                    best_model_name = model_name

            self.best_model_name = best_model_name
            self.best_model = self.models.get(best_model_name)
            print(f"Selected Best Model: {self.best_model_name}")

    def run_full_analysis(self):
        """
        Run the full analysis pipeline.
        """
        self.preprocess_data()
       
        self.calculate_annual_stability_scores()
        self.calculate_cluster_persistence()
        self.construct_confusion_matrices()
        self.identify_instability_periods()
        self.analyze_transition_patterns()
        self.detect_seasonality()
        self.detect_client_cluster_seasonality()
        self.analyze_seasonality_distribution()
        self.distribution_of_stability_scores()
        self.annual_cluster_distribution()
        self.timeline_plots_individual_clients(num_clients=5)
        self.heatmap_cluster_assignments()
        self.feature_engineering()
        self.train_models()
        self.select_best_model()
        self.compile_report()




# Import necessary libraries
import pandas as pd
import numpy as np

# Ensure that the StabilityAnalyser class is already defined or imported before running this script.
# from stability_analyser import StabilityAnalyser

def generate_sample_data(num_clients=400, num_years=3):
    """
    Generate sample data for a specified number of clients and years.
    
    Parameters:
    - num_clients (int): Number of clients to simulate.
    - num_years (int): Number of years to simulate data for.
    
    Returns:
    - data (pd.DataFrame): Generated data with columns ['date', 'client_id', 'cluster', 'average_monthly_balance', 'monthly_std']
    """
    # Generate date range
    date_range = pd.date_range(start='2018-01-01', periods=num_years*12, freq='MS')  # 'MS' is month start frequency

    # Generate client IDs
    client_ids = [f'Client_{i+1}' for i in range(num_clients)]
    
    # Define possible clusters
    clusters = ['A', 'B', 'C', 'D']

    # Initialize list to store data
    data_list = []

    for client_id in client_ids:
        # Initialize previous cluster randomly for each client
        prev_cluster = np.random.choice(clusters)
        for date in date_range:
            # Simulate cluster transitions
            # 80% chance to stay in the same cluster, 20% chance to change
            if np.random.rand() < 0.8:
                cluster = prev_cluster
            else:
                cluster = np.random.choice([c for c in clusters if c != prev_cluster])
            prev_cluster = cluster

            # Simulate average monthly balance based on cluster
            base_balance = {
                'A': 10000,
                'B': 5000,
                'C': 2000,
                'D': 1000
            }[cluster]
            balance = base_balance + np.random.normal(0, 500)
            balance_std = np.abs(np.random.normal(100, 50))

            # Append to data list
            data_list.append({
                'date': date,
                'client_id': client_id,
                'cluster': cluster,
                'average_monthly_balance': balance,
                'monthly_std': balance_std
            })

    # Create DataFrame
    data = pd.DataFrame(data_list)
    return data

def main():
    # Generate sample data
    print("Generating sample data...")
    data = generate_sample_data(num_clients=400, num_years=3)
    print(f"Sample data generated with {len(data)} records.")

    # Initialize the StabilityAnalyser with the generated data
    print("Initializing StabilityAnalyser...")
    stability_analyser = StabilityAnalyser(data)
    
    # Run the full analysis
    print("Running full analysis...")
    stability_analyser.run_full_analysis()
    
    # Access and print the stability scores
    stability_scores = stability_analyser.stability_scores
    print("Stability Scores (first 5 clients):")
    print(stability_scores.head())
    
    # Access and print the best model
    best_model_name = stability_analyser.best_model_name
    print(f"Best model selected: {best_model_name}")
    
    # Access and print the report
    report = stability_analyser.report
    print("\nStability Summary:")
    print(report['stability_summary'])
    print("\nClassification Counts:")
    print(report['classification_counts'])
    
    # If you want to access the best model object
    # best_model = stability_analyser.best_model

if __name__ == "__main__":
    main()