import numpy as np
import networkx as nx
from chinese_whispers import chinese_whispers, aggregate_clusters
from sklearn.decomposition import PCA
from sklearn.base import BaseEstimator, ClusterMixin
import matplotlib.pyplot as plt
import seaborn as sns
class ChineseWhispersClustering(BaseEstimator, ClusterMixin):
    def __init__(self, k=5, iterations=20, weighting='top', affinity='precomputed',
                 outlier_percentile=95):
        """
        Initialize the Chinese Whispers Clustering model.

        Parameters:
        - k: int
            Number of nearest neighbors for graph construction. If k = -1, all nodes are connected.
        - iterations: int
            Number of iterations for the Chinese Whispers algorithm.
        - weighting: str
            Weighting scheme for the Chinese Whispers algorithm ('top', 'lin', 'log').
        - affinity: str
            Distance metric to use ('precomputed' for distance matrix).
        - outlier_percentile: float
            Percentile to use for outlier detection threshold (e.g., 95 for 95th percentile).
        """
        self.k = k
        self.iterations = iterations
        self.weighting = weighting
        self.distance_metric = affinity
        self.outlier_percentile = outlier_percentile

    # def fit(self, distance_matrix):
    #     """
    #     Fit the model using the provided distance matrix.

    #     Parameters:
    #     - distance_matrix: np.ndarray
    #         Precomputed distance matrix of shape (n_samples, n_samples).
    #     """
    #     n_samples = distance_matrix.shape[0]
    #     self.n_samples_ = n_samples
    #     G = nx.Graph()
    #     G.clear()
    #     G.add_nodes_from(range(n_samples))  # Ensure all nodes are added

    #     ##########
    #     possible_attributes = ['label', 'cluster', 'community']

    #     for attr in possible_attributes:
    #         try:
    #             labels = np.array([G.nodes[node][attr] for node in range(n_samples)])
    #             print(f"Successfully accessed labels using attribute '{attr}'")
    #             break
    #         except KeyError:
    #             continue
    #     else:
    #         raise KeyError("None of the expected label attributes are found in the nodes.")
    #     ###########
    #     # Convert distances to similarities
    #     # epsilon = 1e-8  # Small constant to prevent division by zero
    #     # similarity_matrix = 1 / (distance_matrix + epsilon)
    #      # Convert distances to similarities using a Gaussian kernel
    #     sigma = np.median(distance_matrix)
    #     similarity_matrix = np.exp(-distance_matrix ** 2 / (2 * sigma ** 2))
    #     # Build the graph

    #     if self.k == -1:
    #         # Fully connected graph; process only i < j to leverage symmetry
    #         for i in range(n_samples):
    #             for j in range(i + 1, n_samples):
    #                 weight = similarity_matrix[i, j]
    #                 if weight > 0.01:
    #                     G.add_edge(i, j, weight=weight)
    #     else:
    #         # k-Nearest Neighbors graph
    #         for i in range(n_samples):
    #             # Get indices of the k most similar neighbors (excluding self)
    #             neighbor_indices = np.argsort(similarity_matrix[i])[::-1][1:self.k+1]
    #             for j in neighbor_indices:
    #                 if i < j:
    #                     weight = similarity_matrix[i, j]
    #                     if weight > 0:
    #                         G.add_edge(i, j, weight=weight)
    #                 else:
    #                     # Edge will be added when i > j is processed
    #                     continue
    #     for edge in G.edges(data=True):
    #         print(f"Edge {edge[0]}-{edge[1]}: weight={edge[2]['weight']}")
    #             # Perform Chinese Whispers clustering
    #     chinese_whispers(G, weighting=self.weighting, iterations=self.iterations)
    #     self.G_ = G  # Store the graph

    #     # Extract labels in the order corresponding to the input data
    #     labels = np.array([G.nodes[node]['label'] for node in range(n_samples)])
    #     unique_labels = np.unique(labels)
    #     label_mapping = {label: idx for idx, label in enumerate(unique_labels)}
    #     labels_mapped = np.array([label_mapping[label] for label in labels])
    #     self.labels_ = labels_mapped

    #     # Aggregate clusters
    #     clusters = aggregate_clusters(G)
    #     print(f"Number of clusters from aggregate_clusters(G): {len(clusters)}")
    #     print("Clusters:", clusters)
    #     self.clusters_ = {label_mapping[label]: nodes for label, nodes in clusters.items()}

    #     # Compute cluster centers (medoids)
    #     self.cluster_centers_indices_ = {}
    #     for label, nodes in self.clusters_.items():
    #         center_node = self._find_medoid(nodes, distance_matrix)
    #         self.cluster_centers_indices_[label] = center_node

    #     # Calculate outlier thresholds based on distances within clusters
    #     self._calculate_outlier_thresholds(distance_matrix)

    #     self.is_fitted_ = True
    #     return self
    def fit(self, distance_matrix):
        n_samples = distance_matrix.shape[0]
        self.n_samples_ = n_samples

        # Normalize distances and compute similarities
        max_distance = np.max(distance_matrix)
        normalized_distances = distance_matrix / max_distance
        similarity_matrix = 1 - normalized_distances  # Similarities range from 0 to 1
        sigma = np.median(distance_matrix)
        similarity_matrix  = np.exp(-distance_matrix ** 2 / (2 * sigma ** 2))
        # Build the graph
        G = nx.Graph()
        G.add_nodes_from(range(n_samples))

        # Add edges based on similarities
        if self.k == -1:
            for i in range(n_samples):
                for j in range(i + 1, n_samples):
                    weight = similarity_matrix[i, j]
                    if weight > 0:
                        G.add_edge(i, j, weight=weight)
        else:
            for i in range(n_samples):
                neighbor_indices = np.argsort(similarity_matrix[i])[::-1][1:self.k+1]
                for j in neighbor_indices:
                    weight = similarity_matrix[i, j]
                    if weight > 0:
                        G.add_edge(i, j, weight=weight)
        
        print(f"Number of nodes: {G.number_of_nodes()}")
        print(f"Number of edges: {G.number_of_edges()}")
        # for edge in G.edges(data=True):
        #     print(f"Edge {edge[0]}-{edge[1]}: weight={edge[2]['weight']}")

        # Run the Chinese Whispers algorithm
        chinese_whispers(G, weighting=self.weighting, iterations=self.iterations)

        # # Determine the correct label attribute
        # possible_attributes = ['label', 'cluster', 'community']

        # for attr in possible_attributes:
        #     if all(attr in data for _, data in G.nodes(data=True)):
        #         labels = np.array([G.nodes[node][attr] for node in range(n_samples)])
        #         print(f"Successfully accessed labels using attribute '{attr}'")
        #         break
        # else:
        #     raise KeyError("None of the expected label attributes are found in the nodes.")

        # Map labels to consecutive integers
        attr = 'label'
        labels = np.array([G.nodes[node][attr] for node in range(n_samples)])
        unique_labels = np.unique(labels)
        label_mapping = {label: idx for idx, label in enumerate(unique_labels)}
        labels_mapped = np.array([label_mapping[label] for label in labels])
        self.labels_ = labels_mapped

        # Aggregate clusters
        clusters = aggregate_clusters(G)
        print(f"Number of clusters from aggregate_clusters(G): {len(clusters)}")
        print("Clusters:", clusters)
        self.clusters_ = {label_mapping[label]: nodes for label, nodes in clusters.items()}

        # Compute cluster centers (medoids)
        self.cluster_centers_indices_ = {}
        for label, nodes in self.clusters_.items():
            center_node = self._find_medoid(nodes, distance_matrix)
            self.cluster_centers_indices_[label] = center_node

        # Calculate outlier thresholds based on distances within clusters
        self._calculate_outlier_thresholds(distance_matrix)

        self.is_fitted_ = True
        return self
    def fit_predict(self, distance_matrix):
        """
        Fit the model using the provided distance matrix and return cluster labels.

        Parameters:
        - distance_matrix: np.ndarray
            Precomputed distance matrix of shape (n_samples, n_samples).

        Returns:
        - labels: np.ndarray
            Cluster labels for each sample.
        """
        self.fit(distance_matrix)
        return self.labels_

    def _find_medoid(self, cluster_nodes, distance_matrix):
        """
        Find the medoid of a cluster.

        Parameters:
        - cluster_nodes: set of int
            Indices of nodes in the cluster.
        - distance_matrix: np.ndarray
            Precomputed distance matrix.

        Returns:
        - medoid_node: int
            Index of the medoid node in the cluster.
        """
        indices = np.array(list(cluster_nodes))
        sub_distances = distance_matrix[np.ix_(indices, indices)]
        total_distances = np.sum(sub_distances, axis=1)
        medoid_index = np.argmin(total_distances)
        medoid_node = indices[medoid_index]
        return medoid_node

    def _calculate_outlier_thresholds(self, distance_matrix):
        """
        Calculate outlier thresholds for each cluster based on distances to cluster centers.

        Parameters:
        - distance_matrix: np.ndarray
            Precomputed distance matrix of shape (n_samples, n_samples).
        """
        self.outlier_thresholds_ = {}
        for label, nodes in self.clusters_.items():
            center_node = self.cluster_centers_indices_[label]
            indices = np.array(list(nodes))
            distances = distance_matrix[indices, center_node]

            # Using percentile for outlier detection
            threshold = np.percentile(distances, self.outlier_percentile)
            self.outlier_thresholds_[f'cluster_{label}'] = threshold

    def predict(self, new_distance_matrix, outliers_check=True):
        """
        Predict the cluster labels for new, unseen data.

        Parameters:
        - new_distance_matrix: np.ndarray
            Distance matrix between new samples and the cluster centers.
            Shape should be (n_new_samples, n_clusters).
        - outliers_check: bool, default True
            Whether to check for outliers based on thresholds.

        Returns:
        - labels: np.ndarray
            Cluster labels for each sample, or -1 for outliers.
        """
        if not hasattr(self, 'is_fitted_'):
            raise ValueError("Model has not been fitted yet.")

        n_new_samples = new_distance_matrix.shape[0]
        labels = np.full(n_new_samples, -1)  # Initialize labels to -1 (outliers)

        # Assign to the nearest cluster center
        nearest_clusters = np.argmin(new_distance_matrix, axis=1)
        min_distances = np.min(new_distance_matrix, axis=1)

        for i in range(n_new_samples):
            cluster_label = nearest_clusters[i]
            distance = min_distances[i]
            if outliers_check:
                threshold = self.outlier_thresholds_.get(f'cluster_{cluster_label}', np.inf)
                if distance <= threshold:
                    labels[i] = cluster_label
                else:
                    labels[i] = -1  # Mark as outlier
            else:
                labels[i] = cluster_label

        return labels

    def plot_clusters(self, X, reduce_dims=False):
        """
        Plot the clusters. Optionally reduce dimensions for visualization.

        Parameters:
        - X: np.ndarray
            Original data array (time series).
        - reduce_dims: bool, default False
            Whether to reduce dimensions using PCA for plotting.
        """
        if not hasattr(self, 'is_fitted_'):
            raise ValueError("Model has not been fitted yet.")

        if reduce_dims:
            # Flatten time series data for PCA
            X_flat = X.reshape(X.shape[0], -1)
            pca = PCA(n_components=2)
            X_reduced = pca.fit_transform(X_flat)
        else:
            # Use the original data (ensure it's 2D)
            if X.shape[1] != 2:
                raise ValueError("Data must be 2D for plotting without dimensionality reduction.")
            X_reduced = X

        plt.figure(figsize=(10, 7))
        scatter = plt.scatter(X_reduced[:, 0], X_reduced[:, 1], c=self.labels_, cmap='tab20')
        plt.title('Chinese Whispers Clustering')
        plt.xlabel('Component 1')
        plt.ylabel('Component 2')
        plt.legend(*scatter.legend_elements(), title="Clusters")
        plt.show()

    @property
    def cluster_centers_indices_(self):
        """
        Get the indices of cluster centers (medoids).

        Returns:
        - centers: dict
            Dictionary mapping cluster labels to medoid indices.
        """
        if not hasattr(self, '_cluster_centers_indices_'):
            raise AttributeError("The cluster_centers_indices_ attribute is not set.")
        return list(self.cluster_centers_indices_.values()) 

    @cluster_centers_indices_.setter
    def cluster_centers_indices_(self, value):
        self._cluster_centers_indices_ = value




########## Sample of use ################

import numpy as np
import matplotlib.pyplot as plt
from tslearn.metrics import cdist_dtw
from tslearn.datasets import CachedDatasets
from sklearn.preprocessing import StandardScaler

# Import the ChineseWhispersClustering class
# Assume the class is defined in a file named chinese_whispers_clustering.py
# from chinese_whispers_clustering import ChineseWhispersClustering

# For this example, we'll define the class in the same script
# Please ensure the class definition provided earlier is available in your environment

# Generate synthetic time series data
def generate_synthetic_data(n_samples=90, n_features=100, n_clusters=3, random_state=42):
    np.random.seed(random_state)
    X = []
    labels = []
    t = np.linspace(0, 4 * np.pi, n_features)
    
    # Define distinct patterns for each cluster
    patterns = []
    for i in range(n_clusters):
        phase_shift = i * np.pi / 2  # Phase shift to separate clusters
        amplitude = 1 + i * 0.5      # Different amplitude for each cluster
        frequency = 1 + i * 0.2      # Different frequency for each cluster
        pattern = amplitude * np.sin(frequency * t + phase_shift)
        patterns.append(pattern)
    
    # Generate data for each cluster
    samples_per_cluster = n_samples // n_clusters
    for i in range(n_clusters):
        pattern = patterns[i]
        for _ in range(samples_per_cluster):
            noise = np.random.normal(0, 0.2, n_features)  # Adjusted noise level
            X.append(pattern + noise)
            labels.append(i)
    
    X = np.array(X)
    labels = np.array(labels)
    return X, labels

# Main function demonstrating the use of ChineseWhispersClustering
def main():
    # Step 1: Generate synthetic time series data
    X_train, labels_true = generate_synthetic_data(n_samples=90, n_features=100, n_clusters=3)
    X_test, y_test_true = generate_synthetic_data(n_samples=30, n_features=100, n_clusters=3, random_state=24)

    # for i in range(3):
    #     plt.figure(figsize=(10, 2))
    #     for j in range(3):  # Plot 3 samples from each cluster
    #         index = i * (len(X_train) // 3) + j
    #         plt.plot(X_train[index], label=f'Sample {index}, Cluster {labels_true[index]}')
    #     plt.title(f'Cluster {i} Samples')
    #     plt.legend()
    #     plt.show()


    # Optional: Standardize the data
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    # Step 2: Compute the distance matrix using DTW
    print("Computing distance matrix...")
    distance_matrix = cdist_dtw(X_train_scaled)
    

    # plt.figure(figsize=(10, 8))
    # sns.heatmap(distance_matrix)
    # plt.title("Distance Matrix Heatmap")
    # plt.show()
    # Step 3: Initialize and fit the ChineseWhispersClustering model
    cw_clustering = ChineseWhispersClustering(
        k=3,  # Number of nearest neighbors; set k=-1 for full graph
        iterations=10000,
        weighting='top',
        outlier_percentile=95  # Percentile for outlier detection threshold
    )
    print("Fitting the Chinese Whispers clustering model...")
    cw_clustering.fit(distance_matrix)

    # Step 4: Get the cluster labels
    labels = cw_clustering.labels_
    print("Cluster labels for training data:", labels)
    from sklearn.metrics import adjusted_rand_score
    ari_score = adjusted_rand_score(labels_true, labels)
    print(f"Adjusted Rand Index (ARI): {ari_score:.2f}")
    # Step 5: Plot the clusters (with dimensionality reduction)
    # print("Plotting clusters...")
    # cw_clustering.plot_clusters(X_train_scaled, reduce_dims=False)

    # Step 6: Prepare test data for prediction
    # Compute distance matrix between test samples and cluster centers
    cluster_centers_indices = list(cw_clustering.cluster_centers_indices_.values())
    X_centers = X_train_scaled[cluster_centers_indices]

    def compute_distance_matrix(new_X, X_centers):
        n_new = new_X.shape[0]
        n_centers = X_centers.shape[0]
        distance_matrix = np.zeros((n_new, n_centers))
        for i in range(n_new):
            for j in range(n_centers):
                # Compute DTW distance
                distance = cdist_dtw(new_X[i].reshape(1, -1), X_centers[j].reshape(1, -1))[0, 0]
                distance_matrix[i, j] = distance
        return distance_matrix

    print("Computing distance matrix for test data...")
    new_distance_matrix = compute_distance_matrix(X_test_scaled, X_centers)

    # Step 7: Predict clusters for new data
    print("Predicting clusters for new data...")
    new_labels = cw_clustering.predict(new_distance_matrix, outliers_check=True)
    print("Predicted labels for test data:", new_labels)

    # Step 8: Evaluate the clustering results (if true labels are known)
    from sklearn.metrics import adjusted_rand_score
    ari = adjusted_rand_score(y_test_true, new_labels)
    print(f"Adjusted Rand Index for test data: {ari:.2f}")

    # Step 9: Plot the test data clusters (with dimensionality reduction)
    print("Plotting clusters for test data...")
    plt.figure(figsize=(10, 7))
    X_test_flat = X_test_scaled.reshape(X_test_scaled.shape[0], -1)
    pca = PCA(n_components=2)
    X_test_reduced = pca.fit_transform(X_test_flat)
    scatter = plt.scatter(X_test_reduced[:, 0], X_test_reduced[:, 1], c=new_labels, cmap='tab20')
    plt.title('Chinese Whispers Clustering - Test Data')
    plt.xlabel('Component 1')
    plt.ylabel('Component 2')
    plt.legend(*scatter.legend_elements(), title="Clusters")
    plt.show()

if __name__ == "__main__":
    main()