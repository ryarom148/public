
import numpy as np
import joblib
from joblib import Parallel, delayed
from sklearn.base import BaseEstimator, ClusterMixin
from sklearn.metrics import silhouette_score, calinski_harabasz_score, davies_bouldin_score
from tslearn.metrics import cdist_dtw, cdist_soft_dtw
import aeon
from aeon.distances import (dtw_distance, lcss_distance, erp_distance,
                            edr_distance, msm_distance, twe_distance)
from aeon.clustering import TimeSeriesKMeans, TimeSeriesKMedoids
from sklearn.cluster import AgglomerativeClustering, DBSCAN, OPTICS, AffinityPropagation
from typing import Dict, List, Union, Optional, Callable
import os
import hashlib
import logging
import time
from sklearn.utils.validation import check_is_fitted
from chi_whisper import ChineseWhispersClustering

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)
aeon.AEON_DEPRECATION_WARNING = False
os.environ['AEON_DEPRECATION_WARNING'] = 'False'

class TimeSeriesClusterPredictor(BaseEstimator, ClusterMixin):
    def __init__(
        self,
        n_jobs: int = -1,
        random_state: Optional[int] = None,
        distance: Union[str, Callable] = 'dtw',
        distance_params: Optional[Dict] = None,
        algorithm: str = 'kmeans',
        algo_params: Optional[Dict] = None,
        optimization_metric: str = 'combined'
    ):
        self.n_jobs = n_jobs
        self.random_state = random_state
        self.distance = distance
        self.distance_params = distance_params if distance_params is not None else {}
        self.algorithm = algorithm
        self.algo_params = algo_params if algo_params is not None else {}
        self.optimization_metric = optimization_metric

        self.distance_metrics = {
            'dtw': dtw_distance,
            'softdtw': cdist_soft_dtw,
            'euclidean': 'euclidean',
            'lcss': lcss_distance,
            'erp': erp_distance,
            'edr': edr_distance,
            'msm': msm_distance,
            'twe': twe_distance,
        }

        self.clustering_algorithms = {
            'kmeans': TimeSeriesKMeans,
            'kmedoids': TimeSeriesKMedoids,
            'agglomerative': AgglomerativeClustering,
            'dbscan': DBSCAN,
            'optics': OPTICS,
            'affinity_propagation': AffinityPropagation,
            'chinese_whispers': ChineseWhispersClustering
        }

        # Validate inputs
        if isinstance(self.distance, str) and self.distance not in self.distance_metrics:
            raise ValueError(f"Unsupported distance metric: {self.distance}")
        if self.algorithm not in self.clustering_algorithms:
            raise ValueError(f"Unsupported clustering algorithm: {self.algorithm}")

        # Initialize state
        self.labels_ = None
        self.cluster_centers_ = None
        self.distance_matrix_ = None
        self.best_model_ = None

    def get_params(self, deep=True):
        """Get parameters following scikit-learn's convention."""
        params = {
            'n_jobs': self.n_jobs,
            'random_state': self.random_state,
            'distance': self.distance,
            'algorithm': self.algorithm,
            'optimization_metric': self.optimization_metric
        }
        
        if self.distance_params:
            for key, value in self.distance_params.items():
                params[f'distance_params__{key}'] = value
        
        if self.algo_params:
            for key, value in self.algo_params.items():
                params[f'algo_params__{key}'] = value
                
        return params

    def set_params(self, **params):
        """Set parameters following scikit-learn's convention."""
        distance_params = {}
        algo_params = {}
        
        for key, value in params.items():
            if key.startswith('distance_params__'):
                param_name = key.split('__')[1]
                distance_params[param_name] = value
            elif key.startswith('algo_params__'):
                param_name = key.split('__')[1]
                algo_params[param_name] = value
            else:
                setattr(self, key, value)
        
        if distance_params:
            self.distance_params = distance_params
        if algo_params:
            self.algo_params = algo_params
        
        return self

    def _cdist_generic(self, dist_fun, dataset1, dataset2=None) -> np.ndarray:
        """Generic parallel distance computation."""
        if dataset2 is None:
            matrix = np.zeros((len(dataset1), len(dataset1)))
            indices = np.triu_indices(len(dataset1), k=0)
            
            matrix[indices] = Parallel(n_jobs=self.n_jobs, prefer="threads")(
                delayed(dist_fun)(dataset1[i], dataset1[j], **self.distance_params)
                for i in range(len(dataset1))
                for j in range(i, len(dataset1))
            )
            
            indices_lower = np.tril_indices(len(dataset1), k=-1)
            matrix[indices_lower] = matrix.T[indices_lower]
            return matrix
        else:
            distances = Parallel(n_jobs=self.n_jobs, prefer="threads")(
                delayed(dist_fun)(dataset1[i], dataset2[j], **self.distance_params)
                for i in range(len(dataset1))
                for j in range(len(dataset2))
            )
            return np.reshape(distances, (len(dataset1), len(dataset2)))

    def compute_distance_matrix(self, X: np.ndarray) -> np.ndarray:
        """Compute distance matrix with caching."""
        params_str = '_'.join(f"{k}:{v}" for k, v in sorted(self.distance_params.items()))
        params_hash = hashlib.md5(params_str.encode()).hexdigest()
        cache_path = os.path.join('distance_matrices', f"{self.distance}_{params_hash}.pkl")
        os.makedirs(os.path.dirname(cache_path), exist_ok=True)

        if os.path.exists(cache_path):
            logger.info(f"Loading cached distance matrix")
            return joblib.load(cache_path)

        logger.info(f"Computing distance matrix using {self.distance}")
        start_time = time.time()

        if self.distance == 'dtw':
            matrix = cdist_dtw(X, n_jobs=self.n_jobs, **self.distance_params)
        elif self.distance == 'softdtw':
            matrix = cdist_soft_dtw(X, **self.distance_params)
        else:
            dist_func = self.distance_metrics[self.distance]
            matrix = self._cdist_generic(dist_func, X)

        logger.info(f"Distance matrix computed in {time.time() - start_time:.2f} seconds")
        joblib.dump(matrix, cache_path)
        
        self.distance_matrix_ = matrix
        return matrix

    def _compute_distances_to_centers(self, X: np.ndarray) -> np.ndarray:
        """Compute distances between samples and cluster centers."""
        if self.distance == 'dtw':
            return cdist_dtw(X, self.cluster_centers_, n_jobs=self.n_jobs, **self.distance_params)
        elif self.distance == 'softdtw':
            return cdist_soft_dtw(X, self.cluster_centers_, **self.distance_params)
        else:
            dist_func = self.distance_metrics[self.distance]
            return self._cdist_generic(dist_func, X, self.cluster_centers_)

    def fit(self, X, y=None):
        """Fit the clustering model."""
        distance_matrix = self.compute_distance_matrix(X)
        
        # Fit the clustering model
        if self.algorithm == 'chinese_whispers':
            self.best_model_ = self.clustering_algorithms[self.algorithm](**self.algo_params)
            self.labels_ = self.best_model_.fit_predict(distance_matrix)
            self.cluster_centers_ = X[self.best_model_.cluster_centers_indices_]
            self.outlier_thresholds_ = self.best_model_.outlier_thresholds_
            return self
        
        # Initialize the appropriate model
        if self.algorithm in ['agglomerative', 'dbscan', 'affinity_propagation']:
            self.best_model_ = self.clustering_algorithms[self.algorithm](
                metric='precomputed',
                **self.algo_params
            )
        else:
            self.best_model_ = self.clustering_algorithms[self.algorithm](**self.algo_params)

        # Fit and get labels
        self.labels_ = self.best_model_.fit_predict(distance_matrix if self.algorithm in ['agglomerative', 'dbscan', 'affinity_propagation','optics'] else X)
        
        # Get or compute cluster centers
        self._set_cluster_centers(X, distance_matrix)
        
        # Compute outlier thresholds
        self._compute_outlier_thresholds(X)
        
        return self

    def _set_cluster_centers(self, X, distance_matrix):
        """Set cluster centers based on algorithm type."""
        if hasattr(self.best_model_, 'cluster_centers_'):
            self.cluster_centers_ = self.best_model_.cluster_centers_.reshape(self.best_model_.cluster_centers_.shape[0],-1)
        elif hasattr(self.best_model_, 'cluster_centers_indices_'):
            self.cluster_centers_ = X[self.best_model_.cluster_centers_indices_]
        else:
            # Compute medoids for clusters using distance matrix
            unique_labels = np.unique(self.labels_[self.labels_ >= 0])
            centers = []
            for label in unique_labels:
                mask = self.labels_ == label
                cluster_distances = distance_matrix[np.ix_(mask, mask)]
                medoid_idx = np.argmin(cluster_distances.sum(axis=1))
                centers.append(X[mask][medoid_idx])
            self.cluster_centers_ = np.array(centers)

    def _compute_outlier_thresholds(self, X):
        """Compute outlier thresholds for each cluster."""
        if self.algorithm == 'chinese_whispers':
            return  # Already set in fit

        self.outlier_thresholds_ = {}
        distances = self._compute_distances_to_centers(X)
        
        unique_labels = np.unique(self.labels_[self.labels_ >= 0])
        for label in unique_labels:
            cluster_mask = self.labels_ == label
            if np.any(cluster_mask):
                cluster_distances = distances[cluster_mask, label]
                self.outlier_thresholds_[f'cluster_{label}'] = np.percentile(cluster_distances, 95)

    def predict(self, X, check_outliers=True):
        """
        Predict clusters for X.
        
        Parameters:
        -----------
        X : array-like
            New samples to predict
        check_outliers : bool, default=True
            Whether to check for outliers based on thresholds
        """
        check_is_fitted(self)
        
        # Handle chinese whispers separately
        if self.algorithm == 'chinese_whispers':
            distances_to_centers = self._compute_distances_to_centers(X)
            return self.best_model_.predict(distances_to_centers, check_outliers)
        
        # Use native predict if available
        if self.algorithm in ['kmeans', 'kmedoids'] and hasattr(self.best_model_, 'predict'):
            labels = self.best_model_.predict(X)
        else:
            # Assign to nearest center
            distances = self._compute_distances_to_centers(X)
            labels = distances.argmin(axis=1)
        
        # Check for outliers if requested
        if check_outliers and hasattr(self, 'outlier_thresholds_'):
            distances = self._compute_distances_to_centers(X)
            labels = self._mark_outliers(labels, distances)
        
        return labels

    def _mark_outliers(self, labels, distances):
        """Mark samples as outliers based on thresholds."""
        min_distances = distances.min(axis=1)
        for i in range(len(self.cluster_centers_)):
            mask = labels == i
            threshold = self.outlier_thresholds_.get(f'cluster_{i}', np.inf)
            labels[mask & (min_distances > threshold)] = -1
        return labels
    
    def fit_predict(self, X, y=None):
            """Compute cluster centers and predict cluster index for each sample."""
            return self.fit(X).predict(X)

    def score(self, X: np.ndarray, X_test: Optional[np.ndarray] = None) -> float:
        """Compute optimization score."""
        logger.info("Computing optimization score")
        start_time = time.time()
        
        silhouette = silhouette_score(X, self.labels_)
        calinski_harabasz = calinski_harabasz_score(X, self.labels_)
        davies_bouldin = davies_bouldin_score(X, self.labels_)
        
        davies_bouldin_normalized = 1 / (1 + davies_bouldin)
        combined_score = (silhouette + calinski_harabasz / 1000 + davies_bouldin_normalized) / 3
        
        if X_test is not None:
            test_labels = self.predict(X_test)
            outlier_ratio = np.sum(test_labels == -1) / len(test_labels)
            combined_score *= (1 - outlier_ratio)
        
        logger.info(f"Computed optimization score in {time.time() - start_time:.2f} seconds")
        
        if self.optimization_metric == 'combined':
            return combined_score
        elif self.optimization_metric == 'silhouette':
            return silhouette
        elif self.optimization_metric == 'calinski_harabasz':
            return calinski_harabasz
        elif self.optimization_metric == 'davies_bouldin':
            return davies_bouldin_normalized
        else:
            raise ValueError(f"Unsupported optimization metric: {self.optimization_metric}")

    def score(self, X, y=None):
        """Returns the score defined by optimization_metric."""
        return self._compute_optimization_score(X)
    

import numpy as np
from sklearn.datasets import make_blobs
from sklearn.preprocessing import StandardScaler
import time
import pandas as pd
from sklearn.metrics import adjusted_rand_score, adjusted_mutual_info_score
import matplotlib.pyplot as plt
import seaborn as sns


def main():
    # Generate synthetic dataset with known clustersn_samples = 1000
    n_features = 20
    n_clusters = 5
    random_state = 42
    n_samples =50
    X, true_labels = make_blobs(
        n_samples=n_samples,
        n_features=n_features,
        centers=n_clusters,
        random_state=random_state
    )
    
    # Standardize the data
    scaler = StandardScaler()
    X = scaler.fit_transform(X)
    
    # Define clustering configurations
    clustering_configs = {
        # 'kmeans': {
        #     'algo_params__n_clusters': n_clusters,
        #     'algo_params__max_iter': 300
        # },
        # 'kmedoids': {
        #     'algo_params__n_clusters': n_clusters,
        #     'algo_params__max_iter': 300
        # },
        'agglomerative': {
            #'algo_params__n_clusters': n_clusters,
            'algo_params__linkage': 'ward'
        },
        'dbscan': {
            'algo_params__eps': 0.5,
            'algo_params__min_samples': 5
        },
        'optics': {
            'algo_params__min_samples': 5,
            'algo_params__xi': 0.05
        },
        'affinity_propagation': {
            'algo_params__damping': 0.5,
            'algo_params__preference': -50
        },
        'chinese_whispers': {
            'algo_params__k': n_clusters,
            'algo_params__iterations': 20,
            'algo_params__weighting': 'top'
        }
    }
    
    # Results storage
    results = []
    
    # Test each clustering algorithm
    for algorithm, params in clustering_configs.items():
        print(f"\nTesting {algorithm}")
        try:
            # Initialize predictor with DTW distance
            predictor = TimeSeriesClusterPredictor(
                distance='dtw',
                distance_params={'global_constraint': 'sakoe_chiba', 'sakoe_chiba_radius': 3},
                algorithm=algorithm,
                n_jobs=-1,
                random_state=random_state
            )
            predictor.set_params(**params)
            
            # Measure fitting time
            start_time = time.time()
            predictor.fit(X)
            fit_time = time.time() - start_time
            
            # Get predictions
            labels = predictor.labels_
            
            # Calculate metrics
            metrics = {
                'algorithm': algorithm,
                'fit_time': fit_time,
                'n_clusters': len(np.unique(labels[labels >= 0])),
                'silhouette': predictor.score(X),
                'ari': adjusted_rand_score(true_labels, labels),
                'ami': adjusted_mutual_info_score(true_labels, labels),
                'outliers': np.sum(labels == -1) / len(labels) if -1 in labels else 0
            }
            
            results.append(metrics)
            print(f"Success: {algorithm}")
            print(f"  Fit time: {fit_time:.2f} seconds")
            print(f"  Number of clusters: {metrics['n_clusters']}")
            print(f"  Silhouette score: {metrics['silhouette']:.3f}")
            print(f"  ARI: {metrics['ari']:.3f}")
            print(f"  AMI: {metrics['ami']:.3f}")
            print(f"  Outlier ratio: {metrics['outliers']:.3f}")
            
        except Exception as e:
            print(f"Error testing {algorithm}: {str(e)}")
    
    # Convert results to DataFrame
    results_df = pd.DataFrame(results)
    
    # Plot results
    plt.figure(figsize=(15, 10))
    
    # Performance comparison
    plt.subplot(2, 2, 1)
    sns.barplot(data=results_df, x='algorithm', y='fit_time')
    plt.xticks(rotation=45)
    plt.title('Fitting Time by Algorithm')
    
    # Clustering quality
    plt.subplot(2, 2, 2)
    quality_metrics = results_df.melt(
        id_vars=['algorithm'],
        value_vars=['silhouette', 'ari', 'ami'],
        var_name='metric',
        value_name='score'
    )
    sns.barplot(data=quality_metrics, x='algorithm', y='score', hue='metric')
    plt.xticks(rotation=45)
    plt.title('Clustering Quality Metrics')
    
    # Number of clusters
    plt.subplot(2, 2, 3)
    sns.barplot(data=results_df, x='algorithm', y='n_clusters')
    plt.xticks(rotation=45)
    plt.axhline(y=n_clusters, color='r', linestyle='--', label='True clusters')
    plt.title('Number of Clusters')
    
    # Outlier ratio
    plt.subplot(2, 2, 4)
    sns.barplot(data=results_df, x='algorithm', y='outliers')
    plt.xticks(rotation=45)
    plt.title('Outlier Ratio')
    
    plt.tight_layout()
    plt.show()
    
    # Print summary table
    print("\nSummary of Results:")
    summary = results_df.set_index('algorithm').round(3)
    print(summary)

if __name__ == "__main__":
    main()