import numpy as np
def calculate_sigma_from_distances(distance_matrix, percentiles=[50], show_plot=False):
    """
    Calculate sigma for Gaussian kernel to convert distance to similarity.
    
    Parameters:
    - distance_matrix (np.ndarray): Distance matrix (n x n).
    - percentiles (list): Percentiles to calculate sigma, typically around 50th.
    - show_plot (bool): If True, plot sorted distances.
    
    Returns:
    - sigma (float): Calculated sigma for Gaussian kernel.
    """
    # Extract the upper triangle to avoid redundant values
    upper_tri_indices = np.triu_indices_from(distance_matrix, k=1)
    upper_tri_distances = distance_matrix[upper_tri_indices]
    
    # Sort distances
    sorted_distances = np.sort(upper_tri_distances)
    
    # Calculate sigma as the median or a chosen percentile
    sigma = np.percentile(sorted_distances, percentiles[0])
    
   
    return sigma


def distance_to_similarity_matrix(distance_matrix):
    """
    Convert a distance matrix to a similarity matrix using Gaussian kernel.
    
    Parameters:
    - distance_matrix (np.ndarray): Distance matrix (n x n).
    - sigma (float): Gaussian kernel sigma.
    - show_plot (bool): If True, display histogram of similarities.
    
    Returns:
    - similarity_matrix (np.ndarray): Converted similarity matrix.
    """
    sigma = calculate_sigma_from_distances(distance_matrix)
    similarity_matrix = np.exp(-np.square(distance_matrix) / (2 * sigma ** 2))
    
    similarity_matrix = np.exp(-np.square(distance_matrix) / (2 * sigma ** 2))
   

    return similarity_matrix