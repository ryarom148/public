import numpy as np
import matplotlib.pyplot as plt
from joblib import Parallel, delayed, dump, load
from sklearn.base import BaseEstimator, ClusterMixin
from sklearn.metrics import pairwise_distances, silhouette_score, calinski_harabasz_score, davies_bouldin_score
from tslearn.metrics import cdist_dtw, cdist_soft_dtw
from aeon.distances import (dtw_distance, lcss_distance, erp_distance,
                            edr_distance, msm_distance, twe_distance)
from aeon.clustering import TimeSeriesKMeans, TimeSeriesKMedoids
from sklearn.cluster import AgglomerativeClustering, DBSCAN, AffinityPropagation
from chinese_whispers import chinese_whispers, aggregate_clusters
import networkx as nx
from typing import Dict, List, Union, Optional, Callable
from scipy.sparse import csr_matrix
from sklearn.neighbors import NearestNeighbors
from sklearn.model_selection import BaseCrossValidator, KFold
from sklearn.base import clone
from skopt import BayesSearchCV
from skopt.space import Real, Categorical, Integer
from sklearn.model_selection import GridSearchCV
from sklearn.experimental import enable_halving_search_cv
from sklearn.model_selection import HalvingGridSearchCV
from sklearn.metrics import make_scorer
import os
import hashlib
import logging
import time

# Set up logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

class TimeSeriesClusterPredictor(BaseEstimator, ClusterMixin):
    def __init__(
        self,
        distance: Union[str, Callable] = 'dtw',
        distance_params: Optional[Dict] = None,
        algorithm: str = 'kmeans',
        algo_params: Optional[Dict] = None,
        memory_efficient: bool = False,
        n_jobs: int = -1,
        random_state: Optional[int] = None,
        optimization_metric: str = 'combined'
    ):
        logger.debug(f"Initializing TimeSeriesClusterPredictor with distance={distance}, distance_params={distance_params}, algorithm={algorithm}, algo_params={algo_params}")
        # Initialize class attributes
        self.distance = distance
        self.distance_params = distance_params if distance_params is not None else {}
        self.algorithm = algorithm
        self.algo_params = algo_params if algo_params is not None else {}
        self.memory_efficient = memory_efficient
        self.n_jobs = n_jobs
        self.random_state = random_state
        self.optimization_metric = optimization_metric
        
        # Define available distance metrics and corresponding functions
        self.distance_metrics = {
            'dtw': dtw_distance,
            'softdtw': cdist_soft_dtw,
            'euclidean': 'euclidean',
            'lcss': lcss_distance,
            'erp': erp_distance,
            'edr': edr_distance,
            'msm': msm_distance,
            'twe': twe_distance,
        }
        
        # Define available clustering algorithms
        self.clustering_algorithms = {
            'kmeans': TimeSeriesKMeans,
            'kmedoids': TimeSeriesKMedoids,
            'agglomerative': AgglomerativeClustering,
            'dbscan': DBSCAN,
            'affinity_propagation': AffinityPropagation,
            'chinese_whispers': self.chinese_whispers_clustering
        }
        
        # Initialize attributes for the fitted model
        self.best_model = None
        self.cluster_centers_ = None
        self.outlier_threshold = None
        self.labels_ = None
        self.distance_matrix_cache = None

    def get_params(self, deep=True) -> Dict:
        # Override to return parameters for compatibility with scikit-learn
        return {
            'distance': self.distance,
            'distance_params': self.distance_params,
            'algorithm': self.algorithm,
            'algo_params': self.algo_params,
            'memory_efficient': self.memory_efficient,
            'n_jobs': self.n_jobs,
            'random_state': self.random_state,
            'optimization_metric': self.optimization_metric
        }

    def set_params(self, **params) -> 'TimeSeriesClusterPredictor':
        # Override to set parameters for compatibility with scikit-learn
        for key, value in params.items():
            if hasattr(self, key):
                setattr(self, key, value)
            elif key.startswith('distance_params__'):
                param_name = key.split('__', 1)[1]
                self.distance_params[param_name] = value
            elif key.startswith('algo_params__'):
                param_name = key.split('__', 1)[1]
                self.algo_params[param_name] = value
            else:
                raise ValueError(f"Invalid parameter: {key}")
        return self

    def compute_distance_matrix(self, X: np.ndarray, cache_path: Optional[str] = None) -> np.ndarray:
        logger.debug(f"Computing distance matrix using distance={self.distance} with params={self.distance_params}")
        start_time = time.time()
        # Compute the distance matrix for the given data
        if cache_path and os.path.exists(cache_path):
            # Load cached distance matrix if available
            logger.debug(f"Loading distance matrix from cache: {cache_path}")
            self.distance_matrix_cache = load(cache_path)
            logger.debug(f"Loaded cached distance matrix in {time.time() - start_time:.2f} seconds")
            return self.distance_matrix_cache
        
        if self.distance_matrix_cache is not None:
            return self.distance_matrix_cache
        
        self.distance_matrix_cache = self._compute_full_distance_matrix(X)  # Cache the computed distance matrix
        
        if cache_path:
            # Save the computed distance matrix to a file
            logger.debug(f"Saving distance matrix to cache: {cache_path}")
            dump(self.distance_matrix_cache, cache_path)
        logger.debug(f"Computed distance matrix in {time.time() - start_time:.2f} seconds")
        return self.distance_matrix_cache

    def _compute_full_distance_matrix(self, X: np.ndarray) -> np.ndarray:
        logger.debug(f"Computing full distance matrix using distance={self.distance} with params={self.distance_params}")
        start_time = time.time()
        # Compute the full distance matrix for the dataset
        n_samples = len(X)
        distances = np.zeros((n_samples, n_samples))

        if isinstance(self.distance, str):
            metric = self.distance_metrics[self.distance]
            if self.distance == 'dtw':
                distances = cdist_dtw(X, n_jobs=self.n_jobs, **self.distance_params)
            elif self.distance == 'softdtw':
                distances = cdist_soft_dtw(X, **self.distance_params)
            elif self.distance == 'euclidean':
                X_flat = X.reshape((len(X), -1))
                distances = pairwise_distances(X_flat, metric='euclidean', n_jobs=self.n_jobs)
            elif callable(metric):
                distances = self._parallel_distance_computation(X, metric)
        elif callable(self.distance):
            distances = self._parallel_distance_computation(X, self.distance)
        else:
            raise ValueError("Distance must be either a string or a callable")
        
        logger.debug(f"Computed full distance matrix in {time.time() - start_time:.2f} seconds")
        return distances

    def _parallel_distance_computation(self, X: np.ndarray, metric: Callable) -> np.ndarray:
        logger.debug(f"Computing distances in parallel using metric={metric} with params={self.distance_params}")
        start_time = time.time()
        # Compute distances in parallel to handle large datasets efficiently
        n_samples = len(X)
        
        def compute_distances(start, end):
            sub_matrix = np.zeros((end - start, n_samples))
            for i in range(start, end):
                for j in range(n_samples):
                    sub_matrix[i - start, j] = metric(X[i], X[j], **self.distance_params)
            return sub_matrix

        # Divide the dataset into chunks for parallel processing
        chunk_size = max(1, n_samples // (4 * max(1, self.n_jobs)))
        chunks = [(i, min(i + chunk_size, n_samples)) for i in range(0, n_samples, chunk_size)]
        logger.debug(f"Dividing data into {len(chunks)} chunks for parallel processing")
        
        # Use joblib to parallelize the computation
        results = Parallel(n_jobs=self.n_jobs)(
            delayed(compute_distances)(start, end) for start, end in chunks
        )
        
        logger.debug(f"Computed distances in parallel in {time.time() - start_time:.2f} seconds")
        return np.vstack(results)

    def fit(self, X: np.ndarray, y=None, cache_path: Optional[str] = None):
        logger.debug(f"Fitting the clustering model using algorithm={self.algorithm} with params={self.algo_params}")
        start_time = time.time()
        # Fit the clustering model to the dataset
        self.X_ = X
        distance_cache_key = hashlib.md5(f"{self.distance}_{self.distance_params}".encode()).hexdigest()
        cache_path = f"{cache_path}_{distance_cache_key}.pkl" if cache_path else None
        distance_matrix = self.compute_distance_matrix(X, cache_path)

        if self.algorithm in self.clustering_algorithms:
            if self.algorithm == 'chinese_whispers':
                # Special case for Chinese Whispers algorithm
                logger.debug("Using Chinese Whispers clustering algorithm")
                self.labels_ = self.chinese_whispers_clustering(X, distance_matrix)
            else:
                # Initialize the clustering algorithm
                logger.debug(f"Initializing clustering algorithm: {self.algorithm}")
                clusterer = self.clustering_algorithms[self.algorithm](
                    **{k: v for k, v in self.algo_params.items() if k != 'linkage' or self.algorithm == 'agglomerative'},
                    random_state=self.random_state if 'random_state' in self.clustering_algorithms[self.algorithm].__init__.__code__.co_varnames else None
                )
                # Fit the model to the distance matrix or raw data
                if hasattr(clusterer, 'fit_predict'):
                    if self.algorithm in ['kmeans', 'kmedoids']:
                        logger.debug(f"Fitting and predicting labels using raw data with algorithm={self.algorithm}")
                        self.labels_ = clusterer.fit_predict(X)
                    else:
                        logger.debug(f"Fitting and predicting labels using distance matrix with algorithm={self.algorithm}")
                        self.labels_ = clusterer.fit_predict(distance_matrix)
                else:
                    logger.debug(f"Fitting the clustering model using distance matrix with algorithm={self.algorithm}")
                    clusterer.fit(distance_matrix)
                    self.labels_ = clusterer.labels_
        else:
            raise ValueError(f"Unsupported clustering algorithm: {self.algorithm}")

        # Store the fitted model
        self.best_model = clusterer

        # Compute cluster centers and outlier threshold after fitting
        self._compute_cluster_centers(X)
        self._compute_outlier_threshold(X)

        logger.debug(f"Fitted the clustering model in {time.time() - start_time:.2f} seconds")
        return self

    def _compute_cluster_centers(self, X: np.ndarray):
        logger.debug("Computing cluster centers")
        start_time = time.time()
        # Compute the cluster centers for the fitted model
        if hasattr(self.best_model, 'cluster_centers_'):
            self.cluster_centers_ = self.best_model.cluster_centers_
        else:
            # Calculate the mean of each cluster for non-convex clusters
            unique_labels = np.unique(self.labels_)
            self.cluster_centers_ = np.array([
                X[self.labels_ == label].mean(axis=0) for label in unique_labels if label != -1
            ])
        logger.debug(f"Computed cluster centers in {time.time() - start_time:.2f} seconds")

    def _compute_outlier_threshold(self, X: np.ndarray):
        logger.debug("Computing outlier threshold")
        start_time = time.time()
        # Compute the threshold to identify outliers based on distance to cluster centers
        if self.cluster_centers_ is not None:
            distances = self._compute_distances_to_centers(X)
            self.outlier_threshold = np.percentile(distances.min(axis=1), 95)
        logger.debug(f"Computed outlier threshold in {time.time() - start_time:.2f} seconds")

    def _compute_distances_to_centers(self, X: np.ndarray) -> np.ndarray:
        logger.debug("Computing distances to cluster centers")
        start_time = time.time()
        # Compute distances from each point to the cluster centers
        distances = pairwise_distances(X, self.cluster_centers_, metric=self.distance,
                                       n_jobs=self.n_jobs, **self.distance_params)
        logger.debug(f"Computed distances to cluster centers in {time.time() - start_time:.2f} seconds")
        return distances

    def predict(self, X: np.ndarray) -> np.ndarray:
        logger.debug("Predicting cluster labels for new data points")
        start_time = time.time()
        # Predict the cluster labels for new data points and identify outliers based on thresholds set during fitting
        if not hasattr(self.best_model, 'predict') and self.cluster_centers_ is None:
            raise ValueError("Model is not fitted yet. Call 'fit' before using this method.")

        if hasattr(self.best_model, 'predict'):
            # Use the model's predict method if available (e.g., KMeans, AffinityPropagation)
            labels = self.best_model.predict(X)
        else:
            # For models without a predict method, use distance to cluster centers to predict
            distances = self._compute_distances_to_centers(X)
            labels = distances.argmin(axis=1)

        # Detect outliers by comparing distances to the threshold
        if self.outlier_threshold is not None:
            distances = self._compute_distances_to_centers(X)
            outliers = distances.min(axis=1) > self.outlier_threshold
            labels[outliers] = -1

        logger.debug(f"Predicted cluster labels in {time.time() - start_time:.2f} seconds")
        return labels

    def score(self, X: np.ndarray, y=None) -> float:
        logger.debug("Scoring the clustering performance")
        # Compute a score for the clustering performance based on the chosen optimization metric
        if self.optimization_metric == 'silhouette':
            return silhouette_score(X, self.labels_)
        elif self.optimization_metric == 'calinski_harabasz':
            return calinski_harabasz_score(X, self.labels_)
        elif self.optimization_metric == 'davies_bouldin':
            return -davies_bouldin_score(X, self.labels_)  # Negative because lower is better
        elif self.optimization_metric == 'combined':
            silhouette = silhouette_score(X, self.labels_)
            calinski_harabasz = calinski_harabasz_score(X, self.labels_)
            davies_bouldin = davies_bouldin_score(X, self.labels_)
            davies_bouldin_normalized = 1 / (1 + davies_bouldin)
            return (silhouette + calinski_harabasz / 1000 + davies_bouldin_normalized) / 3
        else:
            raise ValueError(f"Unsupported optimization metric: {self.optimization_metric}")

    def chinese_whispers_clustering(self, X: np.ndarray, distance_matrix: np.ndarray) -> np.ndarray:
        logger.debug("Running Chinese Whispers clustering")
        start_time = time.time()
        # Convert distances to similarities
        sigma = np.std(distance_matrix)
        similarity_matrix = np.exp(-distance_matrix ** 2 / (2 * sigma ** 2))

        # Build graph
        G = nx.Graph()
        n_samples = distance_matrix.shape[0]
        for i in range(n_samples):
            for j in range(i + 1, n_samples):
                weight = similarity_matrix[i, j]
                if weight > 0:
                    G.add_edge(i, j, weight=weight)

        # Apply Chinese Whispers clustering
        iterations = self.algo_params.get('iterations', 20)
        weighting = self.algo_params.get('weighting', 'top')
        chinese_whispers(G, weighting=weighting, iterations=iterations)

        # Extract labels
        labels = np.array([G.nodes[node]['label'] for node in G.nodes()])
        unique_labels = np.unique(labels)
        label_mapping = {label: idx for idx, label in enumerate(unique_labels)}
        labels_mapped = np.array([label_mapping[label] for label in labels])

        logger.debug(f"Chinese Whispers clustering completed in {time.time() - start_time:.2f} seconds")
        return labels_mapped

def optimize_clustering(X: np.ndarray, search_method: str = 'grid', n_iter: int = 50, cv: int = 3):
    # Define comprehensive parameter grid
    param_grid = {
        'distance': ['dtw', 'softdtw', 'euclidean', 'lcss', 'erp', 'edr', 'msm', 'twe'],
        'algorithm': ['kmeans', 'kmedoids', 'agglomerative', 'dbscan', 'affinity_propagation', 'chinese_whispers'],
        'algo_params__n_clusters': range(2, 11),
        'distance_params__sakoe_chiba_radius': [None, 1, 5, 10],
        'distance_params__gamma': [0.1, 1.0, 10.0],
        'algo_params__max_iter': [100, 300, 500],
        'algo_params__linkage': ['ward', 'complete', 'average', 'single'],
    }

    estimator = TimeSeriesClusterPredictor()

    if search_method == 'grid':
        search = GridSearchCV(
            estimator,
            param_grid,
            cv=cv,
            n_jobs=-1,
            verbose=2
        )
    elif search_method == 'halving_grid':
        search = HalvingGridSearchCV(
            estimator,
            param_grid,
            cv=cv,
            n_jobs=-1,
            verbose=2
        )
    elif search_method == 'bayes':
        search_spaces = {
            'distance': Categorical(['dtw', 'softdtw', 'euclidean', 'lcss', 'erp', 'edr', 'msm', 'twe']),
            'algorithm': Categorical(['kmeans', 'kmedoids', 'agglomerative', 'dbscan', 'affinity_propagation', 'chinese_whispers']),
            'algo_params__n_clusters': Integer(2, 10),
            'distance_params__sakoe_chiba_radius': Categorical([None, 1, 5, 10]),
            'distance_params__gamma': Real(0.1, 10.0, prior='log-uniform'),
            'algo_params__max_iter': Integer(100, 500),
            'algo_params__linkage': Categorical(['ward', 'complete', 'average', 'single']),
        }
        search = BayesSearchCV(
            estimator,
            search_spaces,
            n_iter=n_iter,
            cv=cv,
            n_jobs=-1,
            verbose=2
        )
    else:
        raise ValueError(f"Unsupported search method: {search_method}")

    search.fit(X)

    best_model = search.best_estimator_
    best_params = search.best_params_
    best_score = search.best_score_

    logger.debug(f"Best parameters: {best_params}")
    logger.debug(f"Best score: {best_score}")

    return best_model, best_params, best_score

if __name__ == "__main__":
    from sklearn.model_selection import train_test_split
    from sklearn.preprocessing import StandardScaler
    
    # Generate synthetic time series data
    n_samples = 1000
    n_features = 10
    n_timesteps = 50
    X = np.random.randn(n_samples, n_timesteps, n_features)
    
    # Split the data into training and testing sets
    X_train, X_test = train_test_split(X, test_size=0.2, random_state=42)
    
    # Normalize the data
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train.reshape(-1, n_features)).reshape(X_train.shape)
    X_test_scaled = scaler.transform(X_test.reshape(-1, n_features)).reshape(X_test.shape)
    
    # Set up parameters for distance and clustering
    distance_params = {'sakoe_chiba_radius': 5}
    algo_params = {'n_clusters': 5, 'max_iter': 300}
    
    # Initialize the TimeSeriesClusterPredictor
    cluster_predictor = TimeSeriesClusterPredictor(
        distance='dtw',
        distance_params=distance_params,
        algorithm='kmeans',
        algo_params=algo_params,
        n_jobs=-1,
        random_state=42
    )
    
    # Fit the model to the training data
    cluster_predictor.fit(X_train_scaled)
    
    # Predict the cluster labels for the test data
    test_labels = cluster_predictor.predict(X_test_scaled)
    
    # Visualize the clustering results for a subset of the time series
    plt.figure(figsize=(10, 6))
    for label in np.unique(test_labels):
        plt.plot(X_test_scaled[test_labels == label].mean(axis=0).T, label=f'Cluster {label}')
    plt.title('Clustering Results')
    plt.legend()
    plt.show()
    
    # Evaluate clustering performance
    silhouette_avg = silhouette_score(X_test_scaled.reshape(len(X_test_scaled), -1), test_labels)
    calinski_harabasz = calinski_harabasz_score(X_test_scaled.reshape(len(X_test_scaled), -1), test_labels)
    davies_bouldin = davies_bouldin_score(X_test_scaled.reshape(len(X_test_scaled), -1), test_labels)
    
    logger.info(f"Silhouette Score: {silhouette_avg}")
    logger.info(f"Calinski-Harabasz Score: {calinski_harabasz}")
    logger.info(f"Davies-Bouldin Score: {davies_bouldin}")
