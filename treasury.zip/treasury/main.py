import yaml
from src.data.data_loader import load_data
from src.data.data_preprocessor import preprocess_data
from src.features.feature_engineering import engineer_features
from src.models.clustering import perform_clustering
from src.models.balance_predictor import predict_balance
from src.evaluation.model_evaluation import evaluate_model
from src.utils.azure_utils import init_azure_resources, setup_compute, log_metrics
from src.utils.local_utils import save_model_locally, load_model_locally

def main():
    # Load configuration
    with open('config/config.yaml', 'r') as config_file:
        config = yaml.safe_load(config_file)

    execution_mode = config['execution_mode']
    
    if execution_mode == 'local':
        # Local execution
        raw_data = load_data(config['local']['data_path'])
    else:  # Azure mode
        # Initialize Azure resources
        storage_account_name, container_name, ml_client = init_azure_resources(config['azure'])
        
        # Setup compute
        compute_target = setup_compute(ml_client, config['azure']['compute'])
        
        # Load data from Azure
        azure_config = config['azure']
        azure_config['storage_account_name'] = storage_account_name
        azure_config['data_container'] = container_name
        raw_data = load_data(azure_config)

    # Preprocess data
    preprocessed_data = preprocess_data(raw_data)

    # Feature engineering
    features = engineer_features(preprocessed_data)

    # Perform clustering
    clusters = perform_clustering(features, config['model']['n_clusters'])

    # Predict balance levels
    predictions = predict_balance(features, clusters, config['model']['prediction_horizon'])

    # Evaluate model
    evaluation_results = evaluate_model(predictions, preprocessed_data)

    # Save or log results
    if execution_mode == 'local':
        save_model_locally(predictions, config['local']['model_save_path'])
        print(f"Model saved locally. Evaluation results: {evaluation_results}")
    else:  # Azure mode
        run = ml_client.runs.get(ml_client.runs.create().name)
        log_metrics(ml_client, run.id, evaluation_results)
        print("Model results logged to Azure ML workspace.")

    print("Balance prediction process completed successfully.")

if __name__ == "__main__":
    main()