/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ChevronLeft, 
  ChevronRight, 
  Cpu, 
  Zap, 
  ShieldCheck, 
  BarChart3, 
  Scale, 
  Database, 
  Globe, 
  Layers,
  ArrowRight,
  Lock,
  Settings2,
  GitBranch,
  Search,
  CheckCircle2,
  AlertCircle,
  Terminal,
  RefreshCw,
  TrendingUp,
  Bot,
  XCircle,
  Check
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  Cell,
  LineChart,
  Line
} from 'recharts';
import { cn } from './lib/utils';

// --- Types ---

interface SlideProps {
  isActive: boolean;
}

// --- Components ---

const Slide1 = ({ isActive }: SlideProps) => (
  <div className="flex flex-col items-center justify-center h-full text-center px-8">
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={isActive ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.8 }}
      className="mb-8"
    >
      <span className="px-6 py-2 rounded-full glass text-brand-primary text-base font-medium tracking-wider uppercase">
        Autonomous Engineering Framework
      </span>
    </motion.div>
    
    <motion.h1 
      initial={{ opacity: 0, scale: 0.9 }}
      animate={isActive ? { opacity: 1, scale: 1 } : {}}
      transition={{ duration: 0.8, delay: 0.2 }}
      className="text-7xl md:text-9xl font-bold mb-10 tracking-tighter"
    >
      AUTORESEARCH
    </motion.h1>
    
    <motion.p 
      initial={{ opacity: 0 }}
      animate={isActive ? { opacity: 1 } : {}}
      transition={{ duration: 0.8, delay: 0.4 }}
      className="text-2xl md:text-3xl text-slate-400 max-w-4xl mb-16 font-light"
    >
      Eliminating the Human Bottleneck through Recursive Self-Improvement
    </motion.p>

    <div className="relative w-full max-w-3xl h-80 flex items-center justify-center">
      <motion.div 
        initial={{ height: 0 }}
        animate={isActive ? { height: '100%' } : {}}
        transition={{ duration: 1.5, delay: 0.6 }}
        className="absolute w-full bg-linear-to-b from-brand-primary/20 via-brand-secondary/20 to-transparent rounded-t-[120px] rounded-b-lg border-x border-t border-white/10"
      />
      
      <div className="relative z-10 flex flex-col items-center gap-6 w-full px-16">
        <div className="flex justify-between w-full text-sm font-mono text-slate-500 uppercase tracking-widest">
          <span>Infinite Compute</span>
          <span>Token Capacity</span>
        </div>
        
        <div className="w-full h-px bg-white/10" />
        
        <motion.div 
          animate={isActive ? { scale: [1, 1.05, 1] } : {}}
          transition={{ repeat: Infinity, duration: 3 }}
          className="glass p-8 rounded-3xl flex items-center gap-6 border-brand-accent/30"
        >
          <div className="p-4 bg-brand-accent/20 rounded-2xl">
            <Zap className="w-8 h-8 text-brand-accent" />
          </div>
          <div className="text-left">
            <div className="font-bold text-xl">Human Developer</div>
            <div className="text-sm text-slate-400 font-mono italic">"Vibe Coding" Latency</div>
          </div>
        </motion.div>
        
        <ArrowRight className="w-8 h-8 text-slate-600 rotate-90" />
        
        <div className="glass px-10 py-6 rounded-2xl border-brand-primary/50 bg-brand-primary/5">
          <div className="font-bold text-brand-primary text-lg tracking-widest uppercase">Optimized Output</div>
        </div>
      </div>
    </div>
  </div>
);

const SlideThreeFileArchitecture = ({ isActive }: SlideProps) => (
  <div className="flex flex-col h-full px-4 lg:px-8 py-8 items-center justify-center bg-slate-950 text-slate-300 font-mono relative overflow-hidden">
    {/* Blueprint Grid Background */}
    <div className="absolute inset-0 opacity-10 pointer-events-none" 
         style={{ backgroundImage: 'linear-gradient(#444 1px, transparent 1px), linear-gradient(90deg, #444 1px, transparent 1px)', backgroundSize: '40px 40px' }} />
    
    <div className="relative z-10 w-full max-w-7xl">
      <div className="text-center mb-12">
        <h2 className="text-2xl lg:text-4xl font-bold tracking-[0.2em] uppercase text-white">
          The Three-File Architecture
        </h2>
      </div>

      <div className="relative grid grid-cols-1 lg:grid-cols-2 gap-y-16 lg:gap-x-24 items-center">
        {/* Top Center Box: program.md */}
        <div className="lg:col-span-2 flex justify-center mb-8">
          <motion.div
            initial={{ opacity: 0, y: -50 }}
            animate={isActive ? { opacity: 1, y: 0 } : {}}
            className="w-full max-w-2xl border border-slate-700 p-6 rounded-sm bg-slate-900/80 backdrop-blur-md relative"
          >
            <div className="flex gap-6 items-start">
              <div className="bg-slate-800 p-4 rounded-lg border border-slate-700">
                <Terminal className="w-12 h-12 text-slate-400" />
              </div>
              <div className="flex-1">
                <div className="flex justify-between items-center mb-2">
                  <h3 className="text-xl lg:text-2xl font-bold text-white">program.md <span className="text-slate-500 font-normal">(The Rules)</span></h3>
                  <span className="text-[10px] bg-slate-800 px-2 py-1 rounded border border-slate-700 text-slate-500">Logic Domain: The Boss</span>
                </div>
                <p className="text-sm text-slate-400 leading-relaxed">
                  The overarching instruction manual written by a human. Defines the system's goals and strict constraints.
                </p>
              </div>
            </div>
            {/* Connecting Arrows Down */}
            <div className="absolute -bottom-16 left-1/4 w-px h-16 bg-slate-700 hidden lg:block" />
            <div className="absolute -bottom-16 right-1/4 w-px h-16 bg-slate-700 hidden lg:block" />
          </motion.div>
        </div>

        {/* Bottom Left: train.py */}
        <motion.div
          initial={{ opacity: 0, x: -50 }}
          animate={isActive ? { opacity: 1, x: 0 } : {}}
          transition={{ delay: 0.2 }}
          className="border-2 border-brand-primary/30 p-6 rounded-sm bg-brand-primary/5 backdrop-blur-sm relative"
        >
          <div className="flex flex-col gap-4">
            <div className="flex gap-4 items-center">
              <div className="bg-brand-primary/10 p-3 rounded-lg border border-brand-primary/20">
                <Cpu className="w-10 h-10 text-brand-primary" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-brand-primary">train.py <span className="text-slate-500 font-normal">(The Playground)</span></h3>
                <span className="text-[10px] text-slate-500">Logic Domain: The Worker</span>
              </div>
            </div>
            <p className="text-xs lg:text-sm text-slate-400 leading-relaxed">
              The only file the agent is permitted to edit. Contains the asset being optimized (code, prompts, parameters). The agent continuously mutates this file to test hypotheses.
            </p>
          </div>
        </motion.div>

        {/* Bottom Right: prepare.py */}
        <motion.div
          initial={{ opacity: 0, x: 50 }}
          animate={isActive ? { opacity: 1, x: 0 } : {}}
          transition={{ delay: 0.4 }}
          className="border-2 border-brand-accent/30 p-6 rounded-sm bg-brand-accent/5 backdrop-blur-sm relative"
        >
          <div className="flex flex-col gap-4">
            <div className="flex gap-4 items-center">
              <div className="bg-brand-accent/10 p-3 rounded-lg border border-brand-accent/20">
                <Lock className="w-10 h-10 text-brand-accent" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-brand-accent">prepare.py <span className="text-slate-500 font-normal">(The Judge)</span></h3>
                <span className="text-[10px] text-slate-500">Logic Domain: The Law</span>
              </div>
            </div>
            <p className="text-xs lg:text-sm text-slate-400 leading-relaxed">
              The evaluation script and scoring metric. The AI agent is strictly forbidden from touching this file. If the agent could edit the Judge, it could rewrite the scoring function to cheat.
            </p>
          </div>
        </motion.div>

        {/* Center Connection: Evaluates Against */}
        <div className="lg:absolute lg:left-1/2 lg:top-[70%] lg:-translate-x-1/2 lg:-translate-y-1/2 flex flex-col items-center gap-2 z-20">
          <div className="flex items-center gap-4">
            <div className="h-px w-12 bg-brand-primary/50 hidden lg:block" />
            <div className="bg-slate-900 border-2 border-rose-500/50 p-3 rounded-full">
              <Lock className="w-6 h-6 text-rose-500" />
            </div>
            <div className="h-px w-12 bg-brand-accent/50 hidden lg:block" />
          </div>
          <span className="text-[10px] font-bold uppercase tracking-widest text-slate-500">Evaluates Against</span>
        </div>
      </div>
    </div>
  </div>
);

const Slide4 = ({ isActive }: SlideProps) => (
  <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center h-full px-16">
    <div>
      <motion.h2 
        initial={{ opacity: 0, x: -20 }}
        animate={isActive ? { opacity: 1, x: 0 } : {}}
        className="text-2xl lg:text-4xl font-bold text-white tracking-[0.2em] uppercase mb-10"
      >
        Lever Control
      </motion.h2>
      <p className="text-slate-400 text-xl mb-10">
        The agent pulls specific architectural levers to find the global maximum of performance.
      </p>
      
      <div className="space-y-10">
        {[
          { label: "Vector Dynamics", value: 85, desc: "Embedding models & top_k retrieval" },
          { label: "Granularity", value: 42, desc: "Chunk size & overlap optimization" },
          { label: "Temperature Control", value: 68, desc: "Precision vs. Creativity threshold" },
          { label: "Structural Optimization", value: 94, desc: "CSS/JS execution speed" }
        ].map((lever, i) => (
          <div key={i} className="space-y-3">
            <div className="flex justify-between text-base">
              <span className="font-bold text-lg">{lever.label}</span>
              <span className="text-slate-500 font-mono">{lever.desc}</span>
            </div>
            <div className="h-3 bg-white/5 rounded-full overflow-hidden">
              <motion.div 
                initial={{ width: 0 }}
                animate={isActive ? { width: `${lever.value}%` } : {}}
                transition={{ duration: 1.5, delay: 0.5 + (i * 0.1) }}
                className="h-full bg-linear-to-r from-brand-primary to-brand-secondary"
              />
            </div>
          </div>
        ))}
      </div>
    </div>
    
    <div className="glass rounded-[40px] p-12 aspect-square flex items-center justify-center relative overflow-hidden">
       <div className="absolute inset-0 bg-linear-to-br from-brand-primary/5 to-transparent" />
       <div className="grid grid-cols-4 gap-6 w-full h-full relative z-10">
          {Array.from({ length: 16 }).map((_, i) => (
            <motion.div 
              key={i}
              animate={isActive ? { 
                height: [ "20%", "80%", "40%", "90%", "30%" ],
                opacity: [ 0.3, 0.8, 0.5, 1, 0.4 ]
              } : {}}
              transition={{ 
                repeat: Infinity, 
                duration: 2 + Math.random() * 2, 
                delay: Math.random() * 2 
              }}
              className="w-full bg-white/10 rounded-xl self-end"
            />
          ))}
       </div>
       <div className="absolute inset-0 flex items-center justify-center">
          <div className="glass p-8 rounded-3xl shadow-2xl border-white/20">
             <Settings2 className="w-16 h-16 text-brand-primary animate-pulse" />
          </div>
       </div>
    </div>
  </div>
);

const Slide5 = ({ isActive }: SlideProps) => (
  <div className="flex flex-col items-center justify-center h-full px-16 text-center">
    <motion.h2 
      initial={{ opacity: 0, y: -20 }}
      animate={isActive ? { opacity: 1, y: 0 } : {}}
      className="text-2xl lg:text-4xl font-bold text-white tracking-[0.2em] uppercase mb-20"
    >
      The Dual-Metric Guardrail
    </motion.h2>
    
    <div className="flex flex-col md:flex-row items-center gap-16 w-full max-w-6xl">
      <motion.div 
        initial={{ opacity: 0, x: -50 }}
        animate={isActive ? { opacity: 1, x: 0 } : {}}
        transition={{ delay: 0.3 }}
        className="flex-1 glass p-10 rounded-[40px] border-brand-primary/30"
      >
        <div className="p-6 bg-brand-primary/10 rounded-3xl w-fit mx-auto mb-8">
          <BarChart3 className="w-12 h-12 text-brand-primary" />
        </div>
        <h3 className="text-3xl font-bold mb-6">Objective Metric</h3>
        <p className="text-slate-400 text-lg mb-8">Load time (ms), Accuracy %, or Execution Cost.</p>
        <div className="text-5xl font-bold text-brand-primary">99.8%</div>
      </motion.div>
      
      <div className="relative">
        <Scale className="w-20 h-20 text-slate-700" />
        <motion.div 
          animate={isActive ? { rotate: [-5, 5, -5] } : {}}
          transition={{ repeat: Infinity, duration: 4 }}
          className="absolute top-0 left-0 w-full h-full flex items-center justify-center pointer-events-none"
        >
          <div className="w-40 h-1.5 bg-white/10 rounded-full" />
        </motion.div>
      </div>
      
      <motion.div 
        initial={{ opacity: 0, x: 50 }}
        animate={isActive ? { opacity: 1, x: 0 } : {}}
        transition={{ delay: 0.5 }}
        className="flex-1 glass p-10 rounded-[40px] border-brand-accent/30"
      >
        <div className="p-6 bg-brand-accent/10 rounded-3xl w-fit mx-auto mb-8">
          <ShieldCheck className="w-12 h-12 text-brand-accent" />
        </div>
        <h3 className="text-3xl font-bold mb-6">Integrity Penalty</h3>
        <p className="text-slate-400 text-lg mb-8">UI breakage, Hallucination, or Logic errors.</p>
        <div className="text-5xl font-bold text-brand-accent">0 Errors</div>
      </motion.div>
    </div>
    
    <motion.div 
      initial={{ opacity: 0, y: 30 }}
      animate={isActive ? { opacity: 1, y: 0 } : {}}
      transition={{ delay: 0.8 }}
      className="mt-20 glass px-10 py-6 rounded-full border-brand-secondary/50"
    >
      <span className="text-slate-300 text-lg">Result: </span>
      <span className="font-bold text-brand-secondary text-xl">Performance without Sacrifice</span>
    </motion.div>
  </div>
);

const Slide6 = ({ isActive }: SlideProps) => {
  const data = [
    { id: '001', param: 'Baseline', time: 1090, score: 0.88, decision: 'Baseline' },
    { id: '022', param: 'chunk: 512', time: 840, score: 0.92, decision: 'KEEP' },
    { id: '045', param: 'minify: agg', time: 210, score: 0.45, decision: 'DISCARD' },
    { id: '066', param: 'inline: true', time: 67, score: 0.95, decision: 'KEEP' },
  ];

  return (
    <div className="flex flex-col h-full px-16 py-12">
      <motion.h2 
        initial={{ opacity: 0 }}
        animate={isActive ? { opacity: 1 } : {}}
        className="text-2xl lg:text-4xl font-bold text-white tracking-[0.2em] uppercase mb-6"
      >
        Quantitative Selection Logic
      </motion.h2>
      <p className="text-slate-400 text-xl mb-12">Evidence-Based Engineering vs. "Vibe Coding"</p>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 flex-1">
        <div className="glass rounded-3xl p-8 overflow-hidden">
          <h3 className="text-base font-mono uppercase tracking-widest text-slate-500 mb-8">Internal Evidence Log (results.csv)</h3>
          <table className="w-full text-left text-base">
            <thead>
              <tr className="border-b border-white/10 text-slate-500">
                <th className="pb-6 font-medium">Run ID</th>
                <th className="pb-6 font-medium">Parameter</th>
                <th className="pb-6 font-medium">Load (ms)</th>
                <th className="pb-6 font-medium">Faithfulness</th>
                <th className="pb-6 font-medium">Decision</th>
              </tr>
            </thead>
            <tbody>
              {data.map((row, i) => (
                <motion.tr 
                  key={i}
                  initial={{ opacity: 0, x: -10 }}
                  animate={isActive ? { opacity: 1, x: 0 } : {}}
                  transition={{ delay: 0.5 + (i * 0.1) }}
                  className="border-b border-white/5 last:border-0"
                >
                  <td className="py-6 font-mono text-sm">{row.id}</td>
                  <td className="py-6 font-bold text-lg">{row.param}</td>
                  <td className="py-6 text-brand-primary font-bold">{row.time}ms</td>
                  <td className="py-6 text-brand-secondary font-bold">{row.score}</td>
                  <td className="py-6">
                    <span className={cn(
                      "px-3 py-1.5 rounded-lg text-xs font-bold",
                      row.decision === 'KEEP' ? "bg-brand-primary/20 text-brand-primary" : 
                      row.decision === 'DISCARD' ? "bg-brand-accent/20 text-brand-accent" : "bg-white/10 text-slate-400"
                    )}>
                      {row.decision}
                    </span>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
        
        <div className="glass rounded-3xl p-8 flex flex-col">
          <h3 className="text-base font-mono uppercase tracking-widest text-slate-500 mb-8">Optimization Curve</h3>
          <div className="flex-1 min-h-[350px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={data}>
                <CartesianGrid strokeDasharray="3 3" stroke="#222" />
                <XAxis dataKey="id" stroke="#555" fontSize={14} />
                <YAxis yAxisId="left" stroke="#00f2ff" fontSize={14} />
                <YAxis yAxisId="right" orientation="right" stroke="#7000ff" fontSize={14} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #334155', borderRadius: '12px' }}
                  itemStyle={{ fontSize: '14px' }}
                />
                <Line yAxisId="left" type="monotone" dataKey="time" stroke="#00f2ff" strokeWidth={4} dot={{ fill: '#00f2ff', r: 8 }} />
                <Line yAxisId="right" type="monotone" dataKey="score" stroke="#7000ff" strokeWidth={4} dot={{ fill: '#7000ff', r: 8 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
          <p className="text-sm text-slate-500 mt-6 italic">
            AI identifies non-obvious breakthroughs that human patience would never reach.
          </p>
        </div>
      </div>
    </div>
  );
};

const Slide7 = ({ isActive }: SlideProps) => (
  <div className="flex flex-col h-full px-16 py-12">
    <motion.h2 
      initial={{ opacity: 0, y: -20 }}
      animate={isActive ? { opacity: 1, y: 0 } : {}}
      className="text-2xl lg:text-4xl font-bold text-white tracking-[0.2em] uppercase mb-16 text-center"
    >
      Practical Industrial Use-Cases
    </motion.h2>
    
    <div className="grid grid-cols-1 md:grid-cols-2 gap-10 flex-1">
      {[
        { 
          title: "Infrastructure", 
          desc: "Optimizing website assets & delivery.", 
          result: "-80% Load Time Reduction",
          icon: Globe,
          color: "text-brand-primary"
        },
        { 
          title: "Knowledge Retrieval", 
          desc: "Finding best chunking for technical PDFs.", 
          result: "99% RAG Accuracy",
          icon: Database,
          color: "text-brand-secondary"
        },
        { 
          title: "Skill Engineering", 
          desc: "Iterating on LLM instructions for reliability.", 
          result: "99.9% Logic Reliability",
          icon: Zap,
          color: "text-brand-accent"
        },
        { 
          title: "Quant Analysis", 
          desc: "Testing 1,000+ buy/sell variations.", 
          result: "Optimized Sharpe Ratio",
          icon: BarChart3,
          color: "text-white"
        }
      ].map((item, i) => (
        <motion.div 
          key={i}
          initial={{ opacity: 0, scale: 0.95 }}
          animate={isActive ? { opacity: 1, scale: 1 } : {}}
          transition={{ delay: 0.2 * i }}
          className="glass rounded-[40px] p-10 flex items-center gap-10 border-white/5"
        >
          <div className="p-8 bg-white/5 rounded-3xl">
            <item.icon className={cn("w-16 h-16", item.color)} />
          </div>
          <div>
            <h3 className="text-3xl font-bold mb-3">{item.title}</h3>
            <p className="text-slate-400 text-lg mb-6">{item.desc}</p>
            <div className={cn("font-mono text-sm font-bold uppercase tracking-widest", item.color)}>
              {item.result}
            </div>
          </div>
        </motion.div>
      ))}
    </div>
  </div>
);

const Slide8 = ({ isActive }: SlideProps) => (
  <div className="flex flex-col items-center justify-center h-full text-center px-16 relative overflow-hidden">
    {/* Background world map effect */}
    <div className="absolute inset-0 opacity-10 pointer-events-none">
       <Globe className="w-[120%] h-[120%] absolute -top-[10%] -left-[10%] text-brand-primary animate-pulse" />
    </div>

    <motion.div
      initial={{ opacity: 0, scale: 0.8 }}
      animate={isActive ? { opacity: 1, scale: 1 } : {}}
      transition={{ duration: 1 }}
      className="relative z-10"
    >
      <h2 className="text-2xl lg:text-4xl font-bold text-white tracking-[0.2em] uppercase mb-10">The Scaled Vision</h2>
      <p className="text-2xl md:text-3xl text-slate-400 max-w-5xl mb-20 font-light leading-relaxed">
        Engineering will no longer be about writing code, but about <span className="text-brand-primary font-medium italic">designing the loops</span> that write the code.
      </p>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-16 text-left max-w-5xl mx-auto">
        <div className="glass p-10 rounded-[40px] border-brand-primary/20">
          <h3 className="text-2xl font-bold mb-6 flex items-center gap-4">
            <CheckCircle2 className="w-8 h-8 text-brand-primary" />
            24/7 Innovation
          </h3>
          <p className="text-slate-400 text-lg leading-relaxed">
            While the team is offline, the "Agent Swarm" performs thousands of research steps, ensuring continuous improvement.
          </p>
        </div>
        <div className="glass p-10 rounded-[40px] border-brand-secondary/20">
          <h3 className="text-2xl font-bold mb-6 flex items-center gap-4">
            <Layers className="w-8 h-8 text-brand-secondary" />
            Evaluation First
          </h3>
          <p className="text-slate-400 text-lg leading-relaxed">
            The future belongs to those who write the best Evaluation Suites. The loop handles the rest.
          </p>
        </div>
      </div>
    </motion.div>
  </div>
);

const Slide9 = ({ isActive }: SlideProps) => (
  <div className="flex flex-col h-full px-12 py-8 items-center overflow-y-auto justify-center">
    <div className="w-full max-w-4xl">
      <div className="glass rounded-[40px] p-8 lg:p-12 border-white/10 shadow-2xl flex flex-col">
        <h3 className="text-2xl lg:text-4xl font-bold mb-12 text-center uppercase tracking-widest">
          Human-led Optimization <br />
          <span className="text-slate-500 text-lg lg:text-xl font-normal lowercase">vs.</span> <br />
          <span className="gradient-text">Auto Research Loop</span>
        </h3>

        <div className="space-y-6">
          {[
            { 
              label: "Metric", 
              human: "Human Manual Testing", 
              auto: "Auto Research Loop",
              icon: Search
            },
            { 
              label: "Testing Volume", 
              human: "~30 experiments / year", 
              auto: "~30 experiments / day",
              icon: Zap
            },
            { 
              label: "Selection Logic", 
              human: "Intuition / Vibes", 
              auto: "Binary / Objective Metrics",
              icon: Scale
            },
            { 
              label: "Primary Tool", 
              human: "Manual File Editing", 
              auto: "Automated Git Commit/Reset",
              icon: Terminal
            }
          ].map((row, i) => (
            <motion.div 
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={isActive ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 0.2 + (i * 0.1) }}
              className="glass p-6 rounded-2xl border-white/5 space-y-4"
            >
              <div className="flex items-center gap-3 text-slate-500 font-bold uppercase tracking-widest text-xs">
                <row.icon className="w-4 h-4" />
                {row.label}
              </div>
              <div className="grid grid-cols-2 gap-8">
                <div className="space-y-1">
                  <div className="text-[10px] text-slate-600 uppercase font-bold">Human</div>
                  <div className="text-base text-slate-400 font-medium">{row.human}</div>
                </div>
                <div className="space-y-1">
                  <div className="text-[10px] text-brand-primary uppercase font-bold">Autonomous</div>
                  <div className="text-base text-slate-100 font-bold">{row.auto}</div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="mt-12 pt-8 border-t border-white/5 text-center">
          <p className="text-sm lg:text-base text-slate-500 italic">
            "The human becomes the designer of constraints, not the writer of code."
          </p>
        </div>
      </div>
    </div>
  </div>
);

const SlideKarpathy = ({ isActive }: SlideProps) => (
  <div className="flex flex-col h-full overflow-y-auto px-8 lg:px-16 py-12 font-mono bg-slate-950 relative">
    {/* Blueprint Grid Background */}
    <div className="absolute inset-0 opacity-10 pointer-events-none" 
         style={{ backgroundImage: 'linear-gradient(#444 1px, transparent 1px), linear-gradient(90deg, #444 1px, transparent 1px)', backgroundSize: '40px 40px' }} />
    
    <div className="max-w-7xl mx-auto w-full relative z-10">
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={isActive ? { opacity: 1, y: 0 } : {}}
        className="text-center mb-16"
      >
        <h2 className="text-2xl lg:text-4xl font-bold text-white tracking-[0.2em] uppercase">
          The Architect of <span className="text-brand-primary">Autonomous Research</span>
        </h2>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={isActive ? { opacity: 1, scale: 1 } : {}}
        transition={{ duration: 0.8 }}
        className="relative"
      >
        <div className="relative z-10 glass rounded-[40px] overflow-hidden border-white/20 shadow-2xl aspect-square w-full max-w-md mx-auto">
          <img 
            src="https://github.com/karpathy.png" 
            alt="Andrej Karpathy" 
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
            onError={(e) => {
              // Fallback to his personal site portrait if GitHub fails
              (e.target as HTMLImageElement).src = "https://karpathy.ai/portrait.jpg";
            }}
          />
          <div className="absolute inset-0 bg-linear-to-t from-slate-950/90 via-slate-950/20 to-transparent" />
          <div className="absolute bottom-8 left-8">
            <div className="text-3xl font-bold">Andrej Karpathy</div>
            <div className="text-base text-brand-primary font-mono uppercase tracking-widest mt-1">AI Visionary</div>
          </div>
        </div>
        {/* Decorative elements */}
        <div className="absolute -top-10 -left-10 w-48 h-48 bg-brand-primary/20 blur-3xl rounded-full" />
        <div className="absolute -bottom-10 -right-10 w-48 h-48 bg-brand-secondary/20 blur-3xl rounded-full" />
      </motion.div>

      <div className="space-y-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isActive ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.3 }}
        >
          <p className="text-xl text-slate-400 leading-relaxed">
            Andrej Karpathy is a world-renowned AI researcher and engineer whose work at Tesla and OpenAI laid the foundation for the autonomous loops we use today.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 gap-6">
          {[
            { icon: Cpu, title: "Director of AI @ Tesla", desc: "Led the Autopilot Computer Vision team, building the data engine for FSD." },
            { icon: Globe, title: "Founding Member @ OpenAI", desc: "Pioneered early deep learning research and large-scale model training." },
            { icon: Zap, title: "AI Educator", desc: "Creator of nanoGPT, LLM101n, and the most influential AI deep-dives on the web." },
            { icon: Layers, title: "Stanford Ph.D.", desc: "Studied under Fei-Fei Li, focusing on the intersection of NLP and Computer Vision." }
          ].map((item, i) => (
            <motion.div 
              key={i}
              initial={{ opacity: 0, x: 20 }}
              animate={isActive ? { opacity: 1, x: 0 } : {}}
              transition={{ delay: 0.4 + i * 0.1 }}
              className="flex items-start gap-6 p-6 glass rounded-2xl border-white/5 hover:border-brand-primary/30 transition-colors group"
            >
              <div className="p-4 bg-white/5 rounded-xl group-hover:bg-brand-primary/10 transition-colors">
                <item.icon className="w-7 h-7 text-brand-primary" />
              </div>
              <div>
                <h3 className="font-bold text-xl mb-1">{item.title}</h3>
                <p className="text-lg text-slate-400">{item.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  </div>
</div>
);

const Slide11 = ({ isActive }: SlideProps) => (
  <div className="relative h-full w-full overflow-hidden rounded-[40px]">
    {/* Background Image with Overlay */}
    <div className="absolute inset-0">
      <img 
        src="https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&q=80&w=2070" 
        alt="Engineering Blueprint" 
        className="w-full h-full object-cover opacity-30 grayscale hover:grayscale-0 transition-all duration-1000"
        referrerPolicy="no-referrer"
      />
      <div className="absolute inset-0 bg-linear-to-r from-slate-950 via-slate-950/80 to-transparent" />
    </div>

    <div className="relative z-10 h-full flex flex-col justify-center px-16 max-w-4xl space-y-12">
      <motion.div
        initial={{ opacity: 0, x: -100 }}
        animate={isActive ? { opacity: 1, x: 0 } : {}}
        transition={{ duration: 0.8 }}
      >
        <h2 className="text-2xl lg:text-4xl font-bold text-white tracking-[0.2em] uppercase leading-tight">
          The Blueprint <br />
          <span className="text-brand-primary">of Autonomy</span>
        </h2>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {[
          { 
            title: "Recursive Logic", 
            desc: "The system doesn't just solve problems; it refines its own problem-solving methodology.",
            icon: RefreshCw
          },
          { 
            title: "Deterministic Growth", 
            desc: "Every iteration is backed by binary success/failure metrics, eliminating 'vibe-based' drift.",
            icon: TrendingUp
          }
        ].map((item, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 20 }}
            animate={isActive ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.5 + i * 0.2 }}
            className="glass p-8 rounded-3xl border-white/10"
          >
            <item.icon className="w-10 h-10 text-brand-secondary mb-4" />
            <h3 className="text-2xl font-bold mb-2">{item.title}</h3>
            <p className="text-slate-400 text-lg leading-relaxed">{item.desc}</p>
          </motion.div>
        ))}
      </div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={isActive ? { opacity: 1 } : {}}
        transition={{ delay: 1 }}
        className="flex items-center gap-8 pt-8"
      >
        <div className="flex -space-x-4">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="w-12 h-12 rounded-full border-2 border-slate-950 bg-slate-800 flex items-center justify-center overflow-hidden">
              <img src={`https://picsum.photos/seed/user${i}/100/100`} alt="User" referrerPolicy="no-referrer" />
            </div>
          ))}
          <div className="w-12 h-12 rounded-full border-2 border-slate-950 bg-brand-primary flex items-center justify-center text-xs font-bold">
            +12k
          </div>
        </div>
        <div className="text-slate-400 text-sm">
          Trusted by <span className="text-white font-bold">12,000+</span> autonomous agents <br />
          running <span className="text-brand-primary font-bold">1.2M</span> daily experiments.
        </div>
      </motion.div>
    </div>

    {/* Floating Data Points */}
    <div className="absolute right-20 top-1/2 -translate-y-1/2 space-y-6 hidden xl:block">
      {[
        { label: "Latency", value: "14ms", color: "text-brand-primary" },
        { label: "Throughput", value: "850 req/s", color: "text-brand-secondary" },
        { label: "Cost/Run", value: "$0.002", color: "text-brand-accent" }
      ].map((stat, i) => (
        <motion.div
          key={i}
          initial={{ opacity: 0, x: 50 }}
          animate={isActive ? { opacity: 1, x: 0 } : {}}
          transition={{ delay: 0.8 + i * 0.1 }}
          className="glass p-6 rounded-2xl border-white/5 w-48 text-right"
        >
          <div className="text-xs text-slate-500 uppercase font-bold">{stat.label}</div>
          <div className={cn("text-2xl font-bold", stat.color)}>{stat.value}</div>
        </motion.div>
      ))}
    </div>
  </div>
);

const SlideIntro = ({ isActive }: SlideProps) => (
  <div className="flex flex-col h-full px-4 lg:px-8 py-8 items-center justify-start lg:justify-center bg-slate-950 text-slate-300 font-mono relative overflow-y-auto">
    {/* Blueprint Grid Background */}
    <div className="absolute inset-0 opacity-10 pointer-events-none" 
         style={{ backgroundImage: 'linear-gradient(#444 1px, transparent 1px), linear-gradient(90deg, #444 1px, transparent 1px)', backgroundSize: '40px 40px' }} />
    
    <div className="relative z-10 w-full max-w-7xl border border-slate-700 p-6 lg:p-8 rounded-sm bg-slate-900/50 backdrop-blur-sm my-auto">
      {/* Header */}
      <div className="text-center mb-8 lg:mb-12 border-b border-slate-700 pb-6">
        <h1 className="text-2xl lg:text-4xl font-bold tracking-[0.2em] uppercase text-white">
          The Engine: Auto Research
        </h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12">
        {/* Left Column: Technical Illustration */}
        <div className="lg:col-span-5 flex items-center justify-center">
          <div className="relative w-full aspect-square max-w-[300px] lg:max-w-md">
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={isActive ? { opacity: 1, scale: 1 } : {}}
              className="absolute inset-0 flex items-center justify-center"
            >
              <div className="relative w-full h-full">
                {/* Abstract Head/Code Illustration using Icons and Shapes */}
                <div className="absolute inset-0 border-2 border-brand-primary/20 rounded-full animate-pulse" />
                <div className="absolute inset-4 border border-brand-secondary/20 rounded-full" />
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="glass p-6 lg:p-8 rounded-2xl border-brand-primary/30 bg-brand-primary/5">
                    <Terminal className="w-20 h-20 lg:w-32 lg:h-32 text-brand-primary" />
                  </div>
                </div>
                <div className="absolute top-0 right-0 p-4">
                  <Cpu className="w-10 h-10 lg:w-16 lg:h-16 text-brand-secondary opacity-50" />
                </div>
                <div className="absolute bottom-0 left-0 p-4">
                  <Database className="w-10 h-10 lg:w-16 lg:h-16 text-brand-accent opacity-50" />
                </div>
              </div>
            </motion.div>
          </div>
        </div>

        {/* Right Column: Content Blocks */}
        <div className="lg:col-span-7 space-y-4 lg:space-y-6">
          {/* Origin */}
          <motion.div 
            initial={{ opacity: 0, x: 50 }}
            animate={isActive ? { opacity: 1, x: 0 } : {}}
            transition={{ delay: 0.2 }}
            className="border border-slate-700 p-4 lg:p-6 rounded-sm bg-slate-800/30"
          >
            <h3 className="text-brand-secondary font-bold uppercase mb-2 tracking-widest text-xs lg:text-sm">Origin</h3>
            <p className="text-xs lg:text-sm leading-relaxed text-slate-400">
              Open-source architecture developed by <span className="text-white">Andrej Karpathy</span> (former Head of AI at Tesla, OpenAI co-founder).
            </p>
          </motion.div>

          {/* Core Mechanism */}
          <motion.div 
            initial={{ opacity: 0, x: 50 }}
            animate={isActive ? { opacity: 1, x: 0 } : {}}
            transition={{ delay: 0.4 }}
            className="border border-slate-700 p-4 lg:p-6 rounded-sm bg-slate-800/30 flex gap-4 lg:gap-6 items-start"
          >
            <div className="flex-1">
              <h3 className="text-brand-primary font-bold uppercase mb-2 tracking-widest text-xs lg:text-sm">Core Mechanism</h3>
              <p className="text-xs lg:text-sm leading-relaxed text-slate-400">
                An autonomous, recursive loop that allows AI agents to systematically improve their own code, skills, and prompts with zero human intervention.
              </p>
            </div>
            <div className="hidden sm:block">
              <RefreshCw className="w-10 h-10 lg:w-12 lg:h-12 text-brand-primary animate-spin-slow" />
            </div>
          </motion.div>

          {/* The Shift */}
          <motion.div 
            initial={{ opacity: 0, x: 50 }}
            animate={isActive ? { opacity: 1, x: 0 } : {}}
            transition={{ delay: 0.6 }}
            className="border border-slate-700 p-4 lg:p-6 rounded-sm bg-slate-800/30"
          >
            <h3 className="text-brand-accent font-bold uppercase mb-2 tracking-widest text-xs lg:text-sm">The Shift</h3>
            <p className="text-xs lg:text-sm leading-relaxed text-slate-400 mb-6">
              Replaces months of manual human trial-and-error with rapid, automated hypothesis testing. The AI agent generates an idea, runs an automated experiment, keeps the modifications that work, and discards the failures.
            </p>
            
            {/* Flowchart */}
            <div className="flex flex-wrap items-center gap-3 text-[9px] lg:text-[10px] font-bold uppercase">
              <div className="border border-slate-600 px-2 lg:px-3 py-1 lg:py-2 bg-slate-900">Idea Generation</div>
              <ArrowRight className="w-3 h-3 text-slate-600 shrink-0" />
              <div className="border border-slate-600 px-2 lg:px-3 py-1 lg:py-2 bg-slate-900">Automated Experiment</div>
              <ArrowRight className="w-3 h-3 text-slate-600 shrink-0" />
              <div className="border border-slate-600 px-2 lg:px-3 py-1 lg:py-2 bg-slate-900">Performance Evaluation</div>
              
              {/* Diverging Arrows SVG */}
              <div className="flex items-center gap-2">
                <svg width="30" height="30" viewBox="0 0 40 40" fill="none" className="text-slate-600 shrink-0 hidden sm:block">
                  <path d="M0 20H15M15 20L25 10M15 20L25 30M25 10H40M25 30H40" stroke="currentColor" strokeWidth="2" />
                  <path d="M35 5L40 10L35 15" stroke="currentColor" strokeWidth="2" />
                  <path d="M35 25L40 30L35 35" stroke="currentColor" strokeWidth="2" />
                </svg>
                <div className="flex flex-col gap-1">
                  <div className="border border-brand-primary/50 px-3 py-1 bg-brand-primary/10 text-brand-primary">Keep</div>
                  <div className="border border-rose-500/50 px-3 py-1 bg-rose-500/10 text-rose-500">Discard</div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Footer Info */}
      <div className="mt-8 pt-4 border-t border-slate-700 flex justify-between text-[8px] lg:text-[10px] text-slate-500 uppercase tracking-widest">
        <span>Document ID: OPT-AUTO-2024</span>
        <span>System Status: Operational</span>
        <span>Date: 2024.10.27</span>
      </div>
    </div>
  </div>
);

const SlideTheLoop = ({ isActive }: SlideProps) => {
  const steps = [
    { id: "hypothesis", title: "Hypothesis", color: "border-blue-500/50 text-blue-400 bg-blue-500/10", angle: -90 },
    { id: "modify", title: "Modify Code", color: "border-teal-500/50 text-teal-400 bg-teal-500/10", angle: -30 },
    { id: "train", title: "Train (5 min)", color: "border-orange-500/50 text-orange-400 bg-orange-500/10", angle: 30 },
    { id: "evaluate", title: "Evaluate", color: "border-purple-500/50 text-purple-400 bg-purple-500/10", angle: 90 },
    { id: "keep", title: "Keep or Discard", color: "border-emerald-500/50 text-emerald-400 bg-emerald-500/10", angle: 150 },
    { id: "repeat", title: "Repeat", color: "border-slate-500/50 text-slate-400 bg-slate-500/10", angle: 210 },
  ];

  // Radius as percentage of the container (50 is center)
  const radius = 35; 

  return (
    <div className="flex flex-col h-full w-full bg-slate-950 p-8 lg:p-12 font-mono relative overflow-hidden items-center justify-center">
      {/* Blueprint Grid Background */}
      <div className="absolute inset-0 opacity-10 pointer-events-none" 
           style={{ backgroundImage: 'linear-gradient(#444 1px, transparent 1px), linear-gradient(90deg, #444 1px, transparent 1px)', backgroundSize: '40px 40px' }} />
      
      <motion.h2 
        initial={{ opacity: 0, x: -20 }}
        animate={isActive ? { opacity: 1, x: 0 } : {}}
        className="absolute top-8 left-8 lg:top-12 lg:left-12 text-2xl lg:text-4xl font-bold text-white tracking-[0.2em] uppercase z-10"
      >
        The Autonomous Git-Driven Loop
      </motion.h2>

      {/* The Loop Container - Fixed Aspect Ratio to ensure alignment */}
      <div className="relative w-full max-w-[800px] aspect-square flex items-center justify-center scale-90 lg:scale-100">
        
        {/* Central Robot */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.8 }}
          animate={isActive ? { opacity: 1, scale: 1 } : {}}
          className="z-10"
        >
          <div className="w-24 h-24 lg:w-32 lg:h-32 flex items-center justify-center text-brand-primary">
            <Bot size={80} strokeWidth={1.5} className="animate-pulse" />
          </div>
        </motion.div>

        {/* SVG for Arrows and Paths - Using 100x100 coordinate system */}
        <svg viewBox="0 0 100 100" className="absolute inset-0 w-full h-full pointer-events-none overflow-visible">
          <defs>
            {steps.map((step, i) => (
              <marker 
                key={`marker-${i}`}
                id={`arrow-${step.id}`} 
                viewBox="0 0 10 10" 
                refX="8" 
                refY="5" 
                markerWidth="4" 
                markerHeight="4" 
                orient="auto"
              >
                <path d="M 0 0 L 10 5 L 0 10 z" fill="currentColor" className={step.color.split(' ')[1]} />
              </marker>
            ))}
            <marker id="arrow-red" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="4" markerHeight="4" orient="auto">
              <path d="M 0 0 L 10 5 L 0 10 z" fill="#f87171" />
            </marker>
          </defs>

          {/* Circular Arrows */}
          {steps.map((step, i) => {
            const nextStep = steps[(i + 1) % steps.length];
            // Adjust angles to start/end at the edge of the boxes
            const startAngle = (step.angle + 20) * (Math.PI / 180);
            const endAngle = (nextStep.angle - 20) * (Math.PI / 180);
            
            const startX = 50 + Math.cos(startAngle) * radius;
            const startY = 50 + Math.sin(startAngle) * radius;
            const endX = 50 + Math.cos(endAngle) * radius;
            const endY = 50 + Math.sin(endAngle) * radius;

            const colors = ["#60a5fa", "#2dd4bf", "#fb923c", "#c084fc", "#34d399", "#94a3b8"];

            return (
              <motion.path
                key={`arrow-${i}`}
                d={`M ${startX} ${startY} A ${radius} ${radius} 0 0 1 ${endX} ${endY}`}
                fill="none"
                stroke={colors[i]}
                strokeWidth="0.5"
                markerEnd={`url(#arrow-${steps[(i + 1) % steps.length].id})`}
                initial={{ pathLength: 0, opacity: 0 }}
                animate={isActive ? { pathLength: 1, opacity: 0.4 } : {}}
                transition={{ delay: 1 + i * 0.2, duration: 0.8 }}
              />
            );
          })}

          {/* Branching Arrows from Keep or Discard (Angle 150) */}
          {isActive && (
            <>
              {/* Git Commit Branch */}
              <motion.path
                d={`M ${50 + Math.cos(150 * Math.PI / 180) * radius - 10} ${50 + Math.sin(150 * Math.PI / 180) * radius} Q 10 65 5 50`}
                fill="none"
                stroke="#10b981"
                strokeWidth="0.8"
                markerEnd="url(#arrow-keep)"
                initial={{ pathLength: 0 }}
                animate={{ pathLength: 1 }}
                transition={{ delay: 2.5, duration: 1 }}
              />
              {/* Git Reset Branch */}
              <motion.path
                d={`M ${50 + Math.cos(150 * Math.PI / 180) * radius - 10} ${50 + Math.sin(150 * Math.PI / 180) * radius} Q 10 65 5 80`}
                fill="none"
                stroke="#f43f5e"
                strokeWidth="0.8"
                markerEnd="url(#arrow-red)"
                initial={{ pathLength: 0 }}
                animate={{ pathLength: 1 }}
                transition={{ delay: 2.8, duration: 1 }}
              />
            </>
          )}
        </svg>

        {/* Step Boxes */}
        {steps.map((step, i) => {
          const rad = (step.angle * Math.PI) / 180;
          const x = Math.cos(rad) * radius;
          const y = Math.sin(rad) * radius;

          return (
            <motion.div
              key={step.id}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={isActive ? { opacity: 1, scale: 1 } : {}}
              transition={{ delay: 0.5 + i * 0.1 }}
              className={cn(
                "absolute px-4 py-2 lg:px-6 lg:py-3 rounded-xl border-2 font-bold text-sm lg:text-xl shadow-2xl flex items-center justify-center min-w-[120px] lg:min-w-[180px] backdrop-blur-md z-20 transition-all duration-300 hover:scale-110",
                step.color
              )}
              style={{ 
                left: `${50 + x}%`, 
                top: `${50 + y}%`,
                transform: 'translate(-50%, -50%)'
              }}
            >
              {step.title}
            </motion.div>
          );
        })}

        {/* Branch Labels - Positioned relative to the container */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={isActive ? { opacity: 1 } : {}}
          transition={{ delay: 3.5 }}
          className="absolute left-[-15%] lg:left-[-25%] top-[40%] lg:top-[45%] flex flex-col gap-12 lg:gap-24 z-30"
        >
          <div className="flex items-center gap-2 lg:gap-4 bg-emerald-500/10 border border-emerald-500/20 px-3 py-2 lg:px-6 lg:py-4 rounded-xl backdrop-blur-md">
            <CheckCircle2 className="text-emerald-500 w-5 h-5 lg:w-8 lg:h-8" />
            <span className="text-sm lg:text-2xl font-bold text-emerald-400 font-mono uppercase tracking-tighter">git commit</span>
          </div>
          <div className="flex items-center gap-2 lg:gap-4 bg-rose-500/10 border border-rose-500/20 px-3 py-2 lg:px-6 lg:py-4 rounded-xl backdrop-blur-md">
            <XCircle className="text-rose-500 w-5 h-5 lg:w-8 lg:h-8" />
            <span className="text-sm lg:text-2xl font-bold text-rose-400 font-mono uppercase tracking-tighter">git reset</span>
          </div>
        </motion.div>

      </div>
    </div>
  );
};

const SlideBottleneckShift = ({ isActive }: SlideProps) => (
  <div className="flex flex-col h-full px-8 lg:px-24 py-16 justify-center bg-slate-950 text-slate-300 font-mono relative overflow-hidden">
    {/* Blueprint Grid Background */}
    <div className="absolute inset-0 opacity-10 pointer-events-none" 
         style={{ backgroundImage: 'linear-gradient(#444 1px, transparent 1px), linear-gradient(90deg, #444 1px, transparent 1px)', backgroundSize: '40px 40px' }} />
    
    <div className="max-w-5xl mx-auto relative z-10">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={isActive ? { opacity: 1, y: 0 } : {}}
        className="mb-12"
      >
        <h2 className="text-2xl lg:text-4xl font-bold text-white leading-tight tracking-[0.2em] uppercase">
          The Bottleneck <span className="text-brand-primary italic">Shifts</span>
        </h2>
      </motion.div>

      <div className="grid lg:grid-cols-2 gap-12 items-start">
        <motion.div
          initial={{ opacity: 0, x: -30 }}
          animate={isActive ? { opacity: 1, x: 0 } : {}}
          transition={{ delay: 0.3 }}
          className="space-y-8"
        >
          <div className="glass p-8 border-l-4 border-brand-primary">
            <p className="text-xl lg:text-2xl leading-relaxed text-slate-200 italic font-serif">
              "The bottleneck isn't compute. It's your <span className="text-brand-primary font-mono not-italic font-bold">program.md</span>"
            </p>
            <div className="mt-4 flex items-center gap-3">
              <div className="w-8 h-px bg-slate-500" />
              <span className="text-sm uppercase tracking-widest text-slate-500">Garry Tan</span>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-brand-secondary font-bold uppercase tracking-widest text-sm">The New Reality</h3>
            <p className="text-lg lg:text-xl text-slate-400 leading-relaxed">
              Execution becomes free. The scarce skill is now <span className="text-white font-bold underline decoration-brand-primary underline-offset-8">knowing what to measure</span> — picking the right metric, setting the right constraints.
            </p>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 30 }}
          animate={isActive ? { opacity: 1, x: 0 } : {}}
          transition={{ delay: 0.6 }}
          className="bg-slate-900/50 border border-white/5 p-8 rounded-2xl backdrop-blur-xl relative group"
        >
          <div className="absolute -top-4 -right-4 w-24 h-24 bg-brand-primary/10 blur-3xl rounded-full group-hover:bg-brand-primary/20 transition-colors" />
          
          <div className="relative z-10 space-y-8">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-brand-secondary/20 rounded-lg">
                <Zap className="w-6 h-6 text-brand-secondary" />
              </div>
              <h4 className="text-xl font-bold text-white uppercase tracking-tight">Practical Definition</h4>
            </div>

            <p className="text-lg lg:text-2xl text-slate-300 leading-snug">
              This is the clearest example yet of what <span className="text-brand-secondary font-bold">AI agents</span> actually look like in practice:
            </p>

            <div className="flex flex-col gap-4">
              <div className="flex items-center gap-4 text-slate-500 line-through opacity-50">
                <div className="w-2 h-2 rounded-full bg-slate-500" />
                <span>Chatbots & LLM Wrappers</span>
              </div>
              <div className="flex items-center gap-4 text-brand-primary font-bold text-xl lg:text-2xl">
                <div className="w-3 h-3 rounded-full bg-brand-primary animate-pulse" />
                <span>Autonomous loops that do real work</span>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  </div>
);

const SlidePillars = ({ isActive }: SlideProps) => (
  <div className="flex flex-col h-full w-full bg-slate-950 font-mono relative overflow-y-auto overflow-x-hidden">
    {/* Blueprint Grid Background - Lighter */}
    <div className="fixed inset-0 opacity-[0.05] pointer-events-none z-0" 
         style={{ backgroundImage: 'linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)', backgroundSize: '60px 60px' }} />
    
    <div className="relative z-10 max-w-7xl mx-auto px-8 lg:px-24 py-16 lg:py-24 w-full">
      {/* Header Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={isActive ? { opacity: 1, y: 0 } : {}}
        className="mb-16 lg:mb-20 text-center lg:text-left"
      >
        <h2 className="text-2xl lg:text-4xl font-bold text-white tracking-[0.2em] uppercase mb-8">
          The Three Shifts <span className="text-brand-primary">of AutoResearch</span>
        </h2>
        <p className="text-xl lg:text-2xl text-slate-400 max-w-3xl font-light tracking-wide mx-auto lg:mx-0">
          How we redefine engineering by moving from manual building to autonomous system design.
        </p>
      </motion.div>

      <div className="grid lg:grid-cols-12 gap-12 lg:gap-16 items-center">
        {/* Left Side: Detailed Copy */}
        <div className="lg:col-span-7 space-y-12">
          {[
            { 
              title: "The Paradigm Shift", 
              subtitle: "Moving the human role from \"Writer of Code\" to \"Designer of Constraints.\"",
              desc: "We no longer solve the problem; we design the loop that solves the problem.",
              color: "text-blue-400"
            },
            { 
              title: "Recursive Self-Improvement", 
              subtitle: "A system that doesn't just execute tasks, but learns from every failure to refine its own methodology in real-time.",
              desc: "Each result becomes input for the next cycle, enabling continuous refinement through repeated experimentation.",
              color: "text-teal-400"
            },
            { 
              title: "Objective Precision", 
              subtitle: "Replacing \"Vibe Coding\" (intuition-based trial and error) with deterministic, binary success/failure metrics.",
              desc: "Solutions are judged through benchmarks, tests, cost, speed, and quality metrics.",
              color: "text-purple-400"
            }
          ].map((shift, i) => (
            <motion.div
              key={shift.title}
              initial={{ opacity: 0, x: -30 }}
              animate={isActive ? { opacity: 1, x: 0 } : {}}
              transition={{ delay: 0.4 + i * 0.2 }}
              className="space-y-3"
            >
              <h4 className={cn("text-2xl lg:text-3xl font-black uppercase tracking-tighter", shift.color)}>
                {shift.title}
              </h4>
              <div className="space-y-3">
                <p className="text-lg lg:text-xl text-white font-bold leading-snug">
                  {shift.subtitle}
                </p>
                <p className="text-base lg:text-lg text-white leading-relaxed font-light">
                  {shift.desc}
                </p>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Right Side: Vertical Stack Visual */}
        <div className="lg:col-span-5 relative flex flex-col items-center gap-6 py-8">
          {/* Connection Line */}
          <div className="absolute top-0 bottom-0 w-px bg-linear-to-b from-brand-primary/0 via-brand-primary/50 to-brand-secondary/0" />

          {[
            { label: "Human Intent", type: "input", icon: Bot },
            { label: "Paradigm Shift", type: "process", color: "border-blue-500/50 text-blue-400" },
            { label: "Recursive Improvement", type: "process", color: "border-teal-500/50 text-teal-400" },
            { label: "Objective Precision", type: "process", color: "border-purple-500/50 text-purple-400" },
            { label: "Optimized Outcome", type: "output", icon: Zap }
          ].map((node, i) => (
            <React.Fragment key={node.label}>
              <motion.div
                initial={{ opacity: 0, scale: 0.8, y: 20 }}
                animate={isActive ? { opacity: 1, scale: 1, y: 0 } : {}}
                transition={{ delay: 0.6 + i * 0.15 }}
                className={cn(
                  "relative z-10 px-6 py-3 rounded-xl border-2 backdrop-blur-xl shadow-2xl flex items-center gap-4 min-w-[240px] lg:min-w-[280px] justify-center transition-all duration-500 hover:scale-105",
                  node.type === 'input' ? "bg-white/5 border-white/20 text-white" : 
                  node.type === 'output' ? "bg-brand-primary/10 border-brand-primary/50 text-brand-primary" :
                  `bg-slate-900/80 ${node.color}`
                )}
              >
                {node.icon && <node.icon size={20} />}
                <span className="font-bold uppercase tracking-widest text-xs lg:text-sm">{node.label}</span>
                
                {/* Glow effect for process nodes */}
                {node.type === 'process' && (
                  <div className="absolute inset-0 bg-current opacity-5 blur-xl rounded-xl" />
                )}
              </motion.div>
              
              {/* Arrow between nodes */}
              {i < 4 && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={isActive ? { opacity: 0.5 } : {}}
                  transition={{ delay: 0.7 + i * 0.15 }}
                  className="text-slate-600"
                >
                  <ArrowRight className="rotate-90 w-5 h-5" />
                </motion.div>
              )}
            </React.Fragment>
          ))}

          {/* Background Glow */}
          <div className="absolute inset-0 bg-brand-primary/5 blur-[100px] rounded-full -z-10" />
        </div>
      </div>
      
      {/* Bottom Spacing */}
      <div className="h-24" />
    </div>
  </div>
);

const SlideEndGoal = ({ isActive }: SlideProps) => (
  <div className="flex flex-col h-full px-8 lg:px-24 py-16 justify-center bg-slate-950 text-slate-300 font-mono relative overflow-hidden">
    {/* Blueprint Grid Background */}
    <div className="absolute inset-0 opacity-10 pointer-events-none" 
         style={{ backgroundImage: 'linear-gradient(#444 1px, transparent 1px), linear-gradient(90deg, #444 1px, transparent 1px)', backgroundSize: '40px 40px' }} />
    
    <div className="max-w-6xl mx-auto relative z-10 grid lg:grid-cols-2 gap-16 items-center">
      <motion.div
        initial={{ opacity: 0, x: -30 }}
        animate={isActive ? { opacity: 1, x: 0 } : {}}
        className="space-y-12"
      >
        <h2 className="text-2xl lg:text-4xl font-bold text-white tracking-[0.2em] uppercase">
          This is the <span className="text-brand-primary">end goal.</span>
        </h2>

        <div className="space-y-8">
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={isActive ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.3 }}
            className="flex gap-4"
          >
            <div className="mt-1.5 w-2 h-2 rounded-full bg-brand-secondary shrink-0" />
            <p className="text-xl lg:text-2xl text-slate-300 leading-relaxed">
              Karpathy predicts that: <span className="text-white italic">"All LLM frontier labs will do this. It's the final boss battle."</span>
            </p>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={isActive ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.5 }}
            className="flex gap-4"
          >
            <div className="mt-1.5 w-2 h-2 rounded-full bg-brand-secondary shrink-0" />
            <p className="text-xl lg:text-2xl text-slate-300 leading-relaxed">
              If you think about it, this is what <span className="text-brand-primary font-bold">recursive self-improvement</span> will look like.
            </p>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={isActive ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.7 }}
            className="flex gap-4"
          >
            <div className="mt-1.5 w-2 h-2 rounded-full bg-brand-secondary shrink-0" />
            <p className="text-xl lg:text-2xl text-slate-300 leading-relaxed">
              The funny thing is that AI labs are spending millions on researchers trying to build this... and <span className="text-brand-secondary font-bold underline decoration-brand-secondary underline-offset-4">Karpathy made it open-source</span> 😎
            </p>
          </motion.div>
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, scale: 0.9, rotate: 2 }}
        animate={isActive ? { opacity: 1, scale: 1, rotate: 0 } : {}}
        transition={{ delay: 0.4, type: "spring" }}
        className="relative"
      >
        <div className="absolute inset-0 bg-brand-primary/20 blur-3xl rounded-full" />
        <div className="relative glass p-8 lg:p-12 rounded-3xl border border-white/10 shadow-2xl overflow-hidden">
          <div className="grid grid-cols-3 gap-6 lg:gap-10">
            {[
              { name: "ChatGPT", color: "bg-emerald-500/20 text-emerald-400 border-emerald-500/30" },
              { name: "Gemini", color: "bg-blue-500/20 text-blue-400 border-blue-500/30" },
              { name: "Claude", color: "bg-orange-500/20 text-orange-400 border-orange-500/30" }
            ].map((lab, i) => (
              <motion.div
                key={lab.name}
                initial={{ opacity: 0, y: 20 }}
                animate={isActive ? { opacity: 1, y: 0 } : {}}
                transition={{ delay: 0.8 + i * 0.1 }}
                className={cn(
                  "aspect-square rounded-2xl border-2 flex flex-col items-center justify-center gap-3 lg:gap-4 backdrop-blur-md",
                  lab.color
                )}
              >
                <div className="w-10 h-10 lg:w-16 lg:h-16 rounded-full bg-white/10 flex items-center justify-center">
                  <Bot className="w-6 h-6 lg:w-10 lg:h-10" />
                </div>
                <span className="text-[10px] lg:text-sm font-bold uppercase tracking-widest">{lab.name}</span>
              </motion.div>
            ))}
          </div>
          
          <div className="mt-12 p-6 bg-white/5 rounded-2xl border border-white/5 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-full bg-brand-primary/20 flex items-center justify-center">
                <RefreshCw className="w-6 h-6 text-brand-primary animate-spin-slow" />
              </div>
              <div>
                <div className="text-white font-bold">Recursive Loop</div>
                <div className="text-slate-500 text-sm">Self-Improvement Active</div>
              </div>
            </div>
            <div className="px-4 py-1 bg-brand-primary/20 text-brand-primary rounded-full text-xs font-bold uppercase tracking-widest">
              Open Source
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  </div>
);

const SlideNotJustML = ({ isActive }: SlideProps) => (
  <div className="flex flex-col h-full px-8 lg:px-24 py-16 justify-center bg-slate-950 text-slate-300 font-mono relative overflow-hidden">
    {/* Blueprint Grid Background */}
    <div className="absolute inset-0 opacity-10 pointer-events-none" 
         style={{ backgroundImage: 'linear-gradient(#444 1px, transparent 1px), linear-gradient(90deg, #444 1px, transparent 1px)', backgroundSize: '40px 40px' }} />
    
    <div className="max-w-6xl mx-auto relative z-10 grid lg:grid-cols-2 gap-16 items-center">
      <motion.div
        initial={{ opacity: 0, x: -30 }}
        animate={isActive ? { opacity: 1, x: 0 } : {}}
        className="space-y-12"
      >
        <h2 className="text-2xl lg:text-4xl font-bold text-white tracking-[0.2em] uppercase">
          Not just <span className="text-brand-primary">ML.</span>
        </h2>

        <div className="space-y-8">
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={isActive ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.3 }}
            className="flex gap-4"
          >
            <div className="mt-1.5 w-2 h-2 rounded-full bg-brand-secondary shrink-0" />
            <p className="text-xl lg:text-2xl text-slate-300 leading-relaxed">
              But this pattern works <span className="text-blue-400 font-bold underline decoration-blue-400 underline-offset-4">anywhere</span> you can measure an outcome, <span className="text-white font-bold">not only in ML.</span>
            </p>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={isActive ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.5 }}
            className="flex gap-4"
          >
            <div className="mt-1.5 w-2 h-2 rounded-full bg-brand-secondary shrink-0" />
            <p className="text-xl lg:text-2xl text-slate-300 leading-relaxed italic">
              Karpathy said it himself: <span className="text-white">"any metric you care about that is reasonably efficient to evaluate can be autoresearched"</span>
            </p>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={isActive ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.7 }}
            className="flex gap-4"
          >
            <div className="mt-1.5 w-2 h-2 rounded-full bg-brand-secondary shrink-0" />
            <p className="text-xl lg:text-2xl text-slate-300 leading-relaxed">
              One file to edit + one scalar metric + a time-boxed loop. <span className="bg-brand-primary/20 px-2 py-1 rounded text-brand-primary font-bold italic">If you can score it, you can autoresearch it.</span>
            </p>
          </motion.div>
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={isActive ? { opacity: 1, scale: 1 } : {}}
        transition={{ delay: 0.4, type: "spring" }}
        className="relative flex items-center justify-center"
      >
        <div className="absolute inset-0 bg-brand-primary/20 blur-3xl rounded-full" />
        
        {/* Diamond Layout Visual */}
        <div className="relative w-full max-w-md aspect-square">
          {/* Central Loop Icon */}
          <div className="absolute inset-0 flex items-center justify-center z-20">
            <div className="w-24 h-24 rounded-full bg-slate-950 border-2 border-brand-primary/50 flex items-center justify-center backdrop-blur-xl shadow-[0_0_50px_rgba(0,242,255,0.3)]">
              <RefreshCw className="w-12 h-12 text-brand-primary animate-spin-slow" />
            </div>
          </div>

          {/* Diamond Nodes */}
          {[
            { label: "ML Training", icon: Database, color: "text-blue-400", pos: "top-0 left-1/2 -translate-x-1/2" },
            { label: "Code Perf", icon: Cpu, color: "text-emerald-400", pos: "bottom-0 left-1/2 -translate-x-1/2" },
            { label: "Trading", icon: TrendingUp, color: "text-orange-400", pos: "left-0 top-1/2 -translate-y-1/2" },
            { label: "Marketing", icon: Globe, color: "text-purple-400", pos: "right-0 top-1/2 -translate-y-1/2" },
            { label: "Prompts", icon: Terminal, color: "text-teal-400", pos: "top-1/4 left-1/4 -translate-x-1/2 -translate-y-1/2" }
          ].map((domain, i) => (
            <motion.div
              key={domain.label}
              initial={{ opacity: 0, scale: 0 }}
              animate={isActive ? { opacity: 1, scale: 1 } : {}}
              transition={{ delay: 0.8 + i * 0.1, type: "spring" }}
              className={cn(
                "absolute glass p-4 rounded-2xl border border-white/10 flex flex-col items-center gap-2 hover:border-brand-primary/50 transition-colors group z-10",
                domain.pos
              )}
            >
              <div className={cn("p-3 rounded-xl bg-white/5 group-hover:bg-white/10 transition-colors", domain.color)}>
                <domain.icon size={24} />
              </div>
              <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400 group-hover:text-white transition-colors">{domain.label}</span>
            </motion.div>
          ))}

          {/* Connecting Lines (Abstract) */}
          <svg className="absolute inset-0 w-full h-full opacity-20" viewBox="0 0 100 100">
            <path d="M50 15 L50 85 M15 50 L85 50 M25 25 L50 50" stroke="white" strokeWidth="0.5" strokeDasharray="2 2" />
          </svg>
        </div>
      </motion.div>
    </div>
  </div>
);

const SlideBusinessApplications = ({ isActive }: SlideProps) => {
  const applications = [
    {
      title: "CODE OPTIMIZATION",
      desc: "Deploying the loop against a codebase to optimize speed. Case Study: Autonomously reduced a website's load time from 50ms to 25ms in under four minutes.",
      highlight: ["50ms to 25ms"]
    },
    {
      title: "ALGORITHMIC TRADING",
      desc: "Autonomously tweaking buy/sell rules and backtesting them against market data, scoring experiments based strictly on Sharpe ratios.",
      highlight: ["Sharpe ratios"]
    },
    {
      title: "PERFORMANCE MARKETING",
      desc: "Scaling from 30 manual A/B tests a year to 36,000 automated tests. Continuously mutating landing page copy or email text to maximize conversion rates.",
      highlight: ["36,000 automated tests"]
    },
    {
      title: "PROMPT OPTIMIZATION",
      desc: "Systematically mutating system instructions and few-shot examples to maximize accuracy and minimize hallucinations. Scoring based on deterministic benchmarks.",
      highlight: ["deterministic benchmarks"]
    }
  ];

  return (
    <div className="flex flex-col h-full w-full bg-slate-950 p-8 lg:p-12 font-mono relative overflow-hidden">
      {/* Blueprint Grid Background */}
      <div className="absolute inset-0 opacity-10 pointer-events-none" 
           style={{ backgroundImage: 'linear-gradient(#444 1px, transparent 1px), linear-gradient(90deg, #444 1px, transparent 1px)', backgroundSize: '40px 40px' }} />
      
      {/* Header Info */}
      <div className="absolute top-4 right-8 text-[10px] text-slate-500 uppercase tracking-widest hidden md:block">
        DOCUMENT ID: OPT-AUTO-2024 | SYSTEM STATUS: OPERATIONAL | DATE: 2024-10-27
      </div>

      <motion.h2 
        initial={{ opacity: 0, y: -20 }}
        animate={isActive ? { opacity: 1, y: 0 } : {}}
        className="text-2xl lg:text-4xl font-bold text-white tracking-[0.2em] uppercase mb-12"
      >
        Broader Business Applications
      </motion.h2>

      <div className="flex-1 flex items-center justify-center">
        <div className="relative w-full max-w-7xl grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Side: The Loop Circle */}
          <div className="lg:col-span-5 flex justify-center relative">
             <div className="relative w-64 h-64 lg:w-80 lg:h-80 flex items-center justify-center">
                {/* Concentric Circles */}
                <div className="absolute inset-0 border-4 border-blue-500/10 rounded-full" />
                <div className="absolute inset-6 border-2 border-blue-500/20 rounded-full" />
                <div className="absolute inset-12 border border-blue-500/30 rounded-full" />
                
                {/* Target Lines */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-full h-px bg-blue-500/20" />
                  <div className="h-full w-px bg-blue-500/20" />
                </div>

                <motion.div 
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={isActive ? { opacity: 1, scale: 1 } : {}}
                  className="relative z-10 text-center bg-slate-950 p-4 rounded-full border border-blue-500/50 shadow-[0_0_30px_rgba(59,130,246,0.2)]"
                >
                  <div className="text-lg lg:text-xl font-bold text-white leading-tight tracking-[0.2em]">
                    AUTO<br />RESEARCH<br />LOOP
                  </div>
                </motion.div>

                {/* Rotating Accents */}
                <motion.div 
                  animate={{ rotate: 360 }}
                  transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
                  className="absolute inset-4 border-t-2 border-blue-500/40 rounded-full"
                />
                <motion.div 
                  animate={{ rotate: -360 }}
                  transition={{ duration: 25, repeat: Infinity, ease: "linear" }}
                  className="absolute inset-10 border-b-2 border-blue-400/30 rounded-full"
                />
             </div>

             {/* SVG Arrows (Visual only, simplified) */}
             <svg className="absolute inset-0 w-full h-full pointer-events-none overflow-visible hidden lg:block" viewBox="0 0 100 100">
                <defs>
                  <marker id="arrowhead-blue" markerWidth="10" markerHeight="7" refX="0" refY="3.5" orient="auto">
                    <polygon points="0 0, 10 3.5, 0 7" fill="#3b82f6" />
                  </marker>
                </defs>
                {/* Top Arrow */}
                <motion.path 
                  d="M 65 30 Q 80 30 85 20" 
                  fill="none" stroke="#3b82f6" strokeWidth="0.5" opacity="0.3"
                  initial={{ pathLength: 0 }} animate={isActive ? { pathLength: 1 } : {}}
                />
                {/* Middle Arrow */}
                <motion.path 
                  d="M 75 50 L 85 50" 
                  fill="none" stroke="#3b82f6" strokeWidth="0.5" opacity="0.3"
                  initial={{ pathLength: 0 }} animate={isActive ? { pathLength: 1 } : {}}
                />
                {/* Bottom Arrow */}
                <motion.path 
                  d="M 65 70 Q 80 70 85 80" 
                  fill="none" stroke="#3b82f6" strokeWidth="0.5" opacity="0.3"
                  initial={{ pathLength: 0 }} animate={isActive ? { pathLength: 1 } : {}}
                />
             </svg>
          </div>

          {/* Right Side: Application Boxes */}
          <div className="lg:col-span-7 space-y-4 lg:space-y-6">
            {applications.map((app, i) => (
              <motion.div
                key={app.title}
                initial={{ opacity: 0, x: 50 }}
                animate={isActive ? { opacity: 1, x: 0 } : {}}
                transition={{ delay: 0.2 + i * 0.1 }}
                className="relative group"
              >
                {/* Stacked Effect */}
                <div className="absolute inset-0 border border-blue-500/10 bg-slate-900/40 rounded-sm translate-x-1 translate-y-1" />
                <div className="absolute inset-0 border border-blue-500/10 bg-slate-900/40 rounded-sm translate-x-2 translate-y-2" />
                
                <div className="relative bg-slate-900/90 border border-slate-700 rounded-sm overflow-hidden shadow-2xl">
                  <div className="bg-blue-600/90 px-6 py-2 text-white font-bold text-xs lg:text-sm tracking-[0.2em]">
                    {app.title}
                  </div>
                  <div className="p-4 lg:p-6 text-slate-300 text-[10px] lg:text-xs leading-relaxed font-mono">
                    {app.desc.split(new RegExp(`(${app.highlight.join('|')})`, 'g')).map((part, j) => 
                      app.highlight.includes(part) ? <span key={j} className="text-orange-400 font-bold">{part}</span> : part
                    )}
                  </div>
                </div>

                {/* Arrow Connector */}
                <div className="absolute left-[-30px] top-1/2 w-[30px] h-px bg-blue-500/30 hidden lg:block" />
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

const SlideSuccessConditions = ({ isActive }: SlideProps) => (
  <div className="flex flex-col h-full px-8 lg:px-24 py-16 justify-center bg-slate-950 text-slate-300 font-mono relative overflow-hidden">
    {/* Blueprint Grid Background */}
    <div className="absolute inset-0 opacity-10 pointer-events-none" 
         style={{ backgroundImage: 'linear-gradient(#444 1px, transparent 1px), linear-gradient(90deg, #444 1px, transparent 1px)', backgroundSize: '40px 40px' }} />
    
    <div className="max-w-6xl mx-auto relative z-10 w-full">
      <motion.h2 
        initial={{ opacity: 0, y: -20 }}
        animate={isActive ? { opacity: 1, y: 0 } : {}}
        className="text-2xl lg:text-4xl font-bold text-white tracking-[0.2em] uppercase mb-16 text-center"
      >
        Success Conditions
      </motion.h2>

      <div className="grid lg:grid-cols-2 gap-16 items-center">
        <div className="space-y-12">
          {[
            { num: "#1", title: "A clear metric", desc: "(one number, clear direction)", color: "text-brand-secondary" },
            { num: "#2", title: "An automated evaluation", desc: "(no human in the loop)", color: "text-brand-primary" },
            { num: "#3", title: "One file the agent can change", desc: "-- all three true or it doesn't work", color: "text-brand-accent" }
          ].map((item, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: -30 }}
              animate={isActive ? { opacity: 1, x: 0 } : {}}
              transition={{ delay: i * 0.2 }}
              className="flex gap-6 items-start"
            >
              <span className="text-2xl font-bold text-slate-500">{item.num}</span>
              <div>
                <h3 className={cn("text-2xl lg:text-3xl font-bold mb-2", item.color)}>{item.title}</h3>
                <p className="text-lg text-slate-400">{item.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={isActive ? { opacity: 1, scale: 1 } : {}}
          transition={{ delay: 0.6 }}
          className="glass p-10 rounded-3xl border-white/10 space-y-10"
        >
          <div className="space-y-6">
            {["Clear Metric", "Automated Eval", "One Editable File"].map((text, i) => (
              <div key={i} className="flex items-center gap-4">
                <div className="w-8 h-8 rounded-lg bg-emerald-500/20 border border-emerald-500/50 flex items-center justify-center">
                  <Check className="text-emerald-400 w-5 h-5" />
                </div>
                <span className="text-xl font-bold text-white">{text}</span>
              </div>
            ))}
          </div>

          <div className="pt-10 border-t border-white/10 space-y-6">
            <div className="flex items-center gap-4 text-xl font-bold">
               <div className="flex gap-2">
                 <div className="w-6 h-6 rounded-full bg-emerald-500" />
                 <span>+</span>
                 <div className="w-6 h-6 rounded-full bg-emerald-500" />
                 <span>+</span>
                 <div className="w-6 h-6 rounded-full bg-emerald-500" />
               </div>
               <span>=</span>
               <span className="px-4 py-1 bg-emerald-500/20 text-emerald-400 rounded-lg uppercase tracking-widest text-sm">Works</span>
            </div>
            <div className="flex items-center gap-4 text-xl font-bold">
               <div className="flex gap-2">
                 <div className="w-6 h-6 rounded-full bg-emerald-500" />
                 <span>+</span>
                 <div className="w-6 h-6 rounded-full bg-brand-accent" />
                 <span>+</span>
                 <div className="w-6 h-6 rounded-full bg-emerald-500" />
               </div>
               <span>=</span>
               <span className="px-4 py-1 bg-brand-accent/20 text-brand-accent rounded-lg uppercase tracking-widest text-sm">Doesn't</span>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  </div>
);

const SlideFailureModes = ({ isActive }: SlideProps) => (
  <div className="flex flex-col h-full px-8 lg:px-24 py-16 justify-center bg-slate-950 text-slate-300 font-mono relative overflow-hidden">
    {/* Blueprint Grid Background */}
    <div className="absolute inset-0 opacity-10 pointer-events-none" 
         style={{ backgroundImage: 'linear-gradient(#444 1px, transparent 1px), linear-gradient(90deg, #444 1px, transparent 1px)', backgroundSize: '40px 40px' }} />
    
    <div className="max-w-6xl mx-auto relative z-10 w-full grid lg:grid-cols-2 gap-16 items-center">
      <div className="space-y-12">
        <motion.h2 
          initial={{ opacity: 0, y: -20 }}
          animate={isActive ? { opacity: 1, y: 0 } : {}}
          className="text-2xl lg:text-4xl font-bold text-white tracking-[0.2em] uppercase mb-8"
        >
          Where AutoResearch fails
        </motion.h2>

        <div className="space-y-6">
          {[
            { 
              title: "Subjective Domains", 
              desc: "Brand design, UX, pricing – anything where \"better\" is subjective.",
              highlight: "\"better\" is subjective",
              color: "text-yellow-400"
            },
            { 
              title: "Judgment Calls", 
              desc: "The loop needs objective metrics. If success is a judgment call, the agent can't tell what's working. It will optimize in random directions.",
              highlight: "objective metrics",
              color: "text-white"
            },
            { 
              title: "Metric Integrity", 
              desc: "Also, if you give it a bad metric, and it will confidently optimize the wrong thing.",
              highlight: "confidently optimize the wrong thing",
              color: "text-brand-accent"
            }
          ].map((item, i) => (
            <motion.div 
              key={i}
              initial={{ opacity: 0, x: -30 }}
              animate={isActive ? { opacity: 1, x: 0 } : {}}
              transition={{ delay: 0.2 + i * 0.2 }}
              className="border border-slate-700 p-4 lg:p-6 rounded-sm bg-slate-800/30"
            >
              <h3 className="text-brand-accent font-bold uppercase mb-2 tracking-widest text-xs lg:text-sm">{item.title}</h3>
              <p className="text-xs lg:text-sm leading-relaxed text-slate-400">
                {item.desc.split(new RegExp(`(${item.highlight})`, 'g')).map((part, j) => 
                  part === item.highlight ? <span key={j} className={cn("font-bold", item.color)}>{part}</span> : part
                )}
              </p>
            </motion.div>
          ))}
        </div>
      </div>

      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={isActive ? { opacity: 1, scale: 1 } : {}}
        transition={{ delay: 0.5 }}
        className="relative flex items-center justify-center"
      >
        <div className="absolute inset-0 bg-brand-accent/10 blur-3xl rounded-full" />
        <div className="relative glass p-12 rounded-[40px] border-brand-accent/30 bg-brand-accent/5 flex flex-col items-center text-center space-y-8">
          <div className="relative">
            <XCircle className="w-32 h-32 text-brand-accent" />
            <motion.div 
              animate={{ scale: [1, 1.2, 1] }}
              transition={{ duration: 2, repeat: Infinity }}
              className="absolute inset-0 border-4 border-brand-accent/20 rounded-full"
            />
          </div>
          <div className="space-y-4">
            <div className="text-3xl font-bold text-white uppercase tracking-tighter">Subjective Drift</div>
            <p className="text-slate-400 text-sm max-w-xs">
              Without a clear scalar metric, the autonomous engine loses its "North Star" and enters a state of high-entropy optimization.
            </p>
          </div>
          <div className="flex gap-4">
            <div className="px-4 py-2 rounded-full bg-white/5 border border-white/10 text-[10px] font-bold uppercase tracking-widest">No Feedback</div>
            <div className="px-4 py-2 rounded-full bg-white/5 border border-white/10 text-[10px] font-bold uppercase tracking-widest">Random Walk</div>
          </div>
        </div>
      </motion.div>
    </div>
  </div>
);

// --- Main App ---

export default function App() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const totalSlides = 16;

  const nextSlide = useCallback(() => {
    setCurrentSlide((prev) => (prev + 1) % totalSlides);
  }, []);

  const prevSlide = useCallback(() => {
    setCurrentSlide((prev) => (prev - 1 + totalSlides) % totalSlides);
  }, []);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight' || e.key === ' ') nextSlide();
      if (e.key === 'ArrowLeft') prevSlide();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [nextSlide, prevSlide]);

  const slides = [
    SlideIntro, SlidePillars, SlideTheLoop, SlideKarpathy, SlideBottleneckShift, SlideEndGoal, SlideThreeFileArchitecture, Slide6, SlideNotJustML, SlideBusinessApplications, Slide7, SlideSuccessConditions, SlideFailureModes, Slide8, Slide9, Slide11
  ];

  return (
    <div className="relative h-screen w-screen bg-slate-950 flex flex-col overflow-hidden font-mono">
      {/* Background elements */}
      <div className="absolute top-0 left-0 w-full h-full pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-brand-primary/10 blur-[120px] rounded-full" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-brand-secondary/10 blur-[120px] rounded-full" />
      </div>

      {/* Header */}
      <header className="relative z-50 px-8 py-6 flex justify-between items-center glass border-0 border-b border-white/5">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-linear-to-br from-brand-primary to-brand-secondary rounded-lg flex items-center justify-center">
            <Cpu className="w-5 h-5 text-slate-950" />
          </div>
          <span className="font-bold tracking-tighter text-xl">AUTORESEARCH</span>
        </div>
        <div className="flex items-center gap-6">
          <div className="hidden md:flex items-center gap-1">
            {Array.from({ length: totalSlides }).map((_, i) => (
              <div 
                key={i} 
                className={cn(
                  "h-1 transition-all duration-300 rounded-full",
                  i === currentSlide ? "w-8 bg-brand-primary" : "w-2 bg-white/10"
                )}
              />
            ))}
          </div>
          <span className="text-xs font-mono text-slate-500">
            {String(currentSlide + 1).padStart(2, '0')} / {String(totalSlides).padStart(2, '0')}
          </span>
        </div>
      </header>

      {/* Main Content */}
      <main className="relative flex-1 overflow-hidden">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentSlide}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.4, ease: "easeInOut" }}
            className="h-full w-full"
          >
            {React.createElement(slides[currentSlide], { isActive: true })}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Navigation Controls */}
      <div className="absolute bottom-8 right-8 z-50 flex gap-4">
        <button 
          onClick={prevSlide}
          className="p-4 glass rounded-full hover:bg-white/10 transition-colors group"
        >
          <ChevronLeft className="w-6 h-6 group-hover:text-brand-primary transition-colors" />
        </button>
        <button 
          onClick={nextSlide}
          className="p-4 glass rounded-full hover:bg-white/10 transition-colors group"
        >
          <ChevronRight className="w-6 h-6 group-hover:text-brand-primary transition-colors" />
        </button>
      </div>
    </div>
  );
}
